#pragma once
/*
 * AuroraUI.h - Aurora Weather V4 user interface.
 *
 * Pure rendering + layout. Depends only on AuroraGfx/AuroraIcons/AuroraTypes, so
 * it compiles unchanged on a PC (used to generate the preview renders).
 * Layout functions are shared with the sketch's touch handler so what you see is
 * exactly what you can tap.
 */
#include <stdio.h>
#include "AuroraTypes.h"
#include "AuroraIcons.h"

// ----------------------------------------------------------------------------
// Theme
// ----------------------------------------------------------------------------
static const Col T_BG_TOP   = mk(5, 11, 23),   T_BG_BOT   = mk(11, 27, 49);
static const Col T_HDR      = mk(8, 18, 34);
static const Col T_NAV      = mk(8, 18, 34);
static const Col T_PANEL_T  = mk(22, 42, 68),  T_PANEL_B  = mk(15, 31, 52);
static const Col T_PANEL2_T = mk(29, 54, 86),  T_PANEL2_B = mk(21, 41, 67);
static const Col T_EDGE_T   = mk(56, 92, 128), T_EDGE_B   = mk(30, 54, 82);
static const Col T_TEXT     = mk(240, 246, 252);
static const Col T_MUTED    = mk(143, 166, 190);
static const Col T_DIM      = mk(92, 114, 140);
static const Col T_CYAN     = mk(56, 213, 255);
static const Col T_TEAL     = mk(53, 214, 180);
static const Col T_VIOLET   = mk(158, 128, 255);
static const Col T_BLUE     = mk(78, 147, 255);
static const Col T_YELLOW   = mk(255, 209, 102);
static const Col T_ORANGE   = mk(255, 159, 67);
static const Col T_RED      = mk(255, 107, 107);
static const Col T_RAIN     = mk(96, 182, 255);
static const Col T_ACTIVE_T = mk(22, 92, 118),  T_ACTIVE_B = mk(14, 62, 88);

static constexpr int UI_HDR_H = 26;
static constexpr int UI_NAV_H = 30;

struct Rect { int x, y, w, h; };
static inline bool rectHit(const Rect &r, int px, int py, int pad = 0) {
  return px >= r.x - pad && px < r.x + r.w + pad && py >= r.y - pad && py < r.y + r.h + pad;
}
static inline bool uiLandscape(int W) { return W >= 300; }
static inline int uiNavTop(int H) { return H - UI_NAV_H; }
static inline int uiBodyTop() { return UI_HDR_H + 5; }
static inline int uiBodyBottom(int H) { return H - UI_NAV_H - 5; }

// Which settings sub-views show the bottom navigation bar.
static inline bool uiNavVisible(const UiModel &m) {
  return m.page != PAGE_SETTINGS || m.sview == SETTINGS_MAIN;
}

// ----------------------------------------------------------------------------
// Formatting helpers (no heap)
// ----------------------------------------------------------------------------
static inline int uiTemp(const UiModel &m, float c) { return (int)lroundf(m.fahrenheit ? c * 1.8f + 32.0f : c); }
static void fmtTemp(char *o, size_t n, const UiModel &m, float c) { snprintf(o, n, "%d" S_DEG, uiTemp(m, c)); }
static void fmtWind(char *o, size_t n, const UiModel &m, float kmh) {
  snprintf(o, n, "%d %s", (int)lroundf(m.mph ? kmh * 0.621371f : kmh), m.mph ? "mph" : "km/h");
}
static const char *compass(int deg) {
  static const char *n[] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
  return n[(((deg % 360) + 360) % 360 + 22) / 45 % 8];
}
// "07:42" -> "7:42 AM"
static void fmt12(char *o, size_t n, const char *hhmm) {
  int h = 0, mi = 0;
  if (!hhmm || strlen(hhmm) < 5) { snprintf(o, n, "--:--"); return; }
  h = (hhmm[0] - '0') * 10 + (hhmm[1] - '0'); mi = (hhmm[3] - '0') * 10 + (hhmm[4] - '0');
  const char *ap = h >= 12 ? "PM" : "AM"; int h12 = h % 12; if (h12 == 0) h12 = 12;
  snprintf(o, n, "%d:%02d %s", h12, mi, ap);
}
static const char *conditionText(int code) {
  switch (code) {
    case 0: return "Clear sky";       case 1: return "Mostly clear";   case 2: return "Partly cloudy";
    case 3: return "Overcast";        case 45: case 48: return "Fog";
    case 51: return "Light drizzle";  case 53: return "Drizzle";       case 55: return "Heavy drizzle";
    case 56: case 57: return "Freezing drizzle";
    case 61: return "Light rain";     case 63: return "Rain";          case 65: return "Heavy rain";
    case 66: case 67: return "Freezing rain";
    case 71: return "Light snow";     case 73: return "Snow";          case 75: return "Heavy snow";
    case 77: return "Snow grains";
    case 80: return "Light showers";  case 81: return "Showers";       case 82: return "Violent showers";
    case 85: case 86: return "Snow showers";
    case 95: return "Thunderstorm";   case 96: case 99: return "Thunderstorm, hail";
    default: return "Weather";
  }
}
static Col uvColor(float uv) {
  if (uv < 3) return T_TEAL;
  if (uv < 6) return T_YELLOW;
  if (uv < 8) return T_ORANGE;
  if (uv < 11) return T_RED;
  return T_VIOLET;
}
static const char *uvLabel(float uv) {
  if (uv < 3) return "LOW";
  if (uv < 6) return "MODERATE";
  if (uv < 8) return "HIGH";
  if (uv < 11) return "VERY HIGH";
  return "EXTREME";
}
// temperature (deg C) -> cool..warm colour used by charts and range bars
static Col tempColor(float c) {
  static const float T[5] = {0, 12, 21, 29, 38};
  static const Col C[5] = {mk(120, 170, 255), mk(56, 213, 255), mk(110, 232, 176), mk(255, 214, 102), mk(255, 122, 72)};
  if (c <= T[0]) return C[0];
  for (int i = 1; i < 5; ++i) if (c <= T[i]) return lerpCol(C[i - 1], C[i], (c - T[i - 1]) / (T[i] - T[i - 1]));
  return C[4];
}

// ----------------------------------------------------------------------------
// Common chrome
// ----------------------------------------------------------------------------
static const Col AURORA_L = mk(53, 214, 180), AURORA_M = mk(56, 213, 255), AURORA_R = mk(158, 128, 255);

static void uiBackground(Canvas &c) {
  gradV(c, 0, 0, c.W, c.H, T_BG_TOP, T_BG_BOT);
  // faint aurora wash in the upper-right corner
  glow(c, c.W - 10, 10, 20, 190, mk(40, 200, 190), 0.13f);
  glow(c, 0, c.H, 10, 150, mk(120, 90, 230), 0.08f);
}

static void uiHeader(Canvas &c, const UiModel &m, const char *title) {
  int W = c.W;
  if (!c.hitsY(0, UI_HDR_H + 1)) return;      // +1: the glow line is drawn on row UI_HDR_H
  gradV(c, 0, 0, W, UI_HDR_H - 1, mk(11, 24, 44), T_HDR);
  gradH(c, 0, UI_HDR_H - 1, W, 1, AURORA_L, AURORA_R);
  // thin glow under the aurora line
  gradH(c, 0, UI_HDR_H, W, 1, mk(14, 52, 70), mk(40, 34, 84));
  // connectivity icon + location
  iconWifi(c, 14, 8.5f, m.wifiOn ? T_TEAL : T_ORANGE, m.wifiOn ? 255 : 190);
  if (!m.wifiOn) capsule(c, 7.5f, 7, 20.5f, 20, 1.6f, T_ORANGE, 255);
  int tw = textWidthSp(FONT_XS, title, 1);
  textFit(c, FONT_SMB, 28, 17, m.location, T_TEXT, W - 28 - tw - 22);
  text(c, FONT_XS, W - 9, 16, title, T_CYAN, AL_RIGHT, 255, 1);
}

static void uiNav(Canvas &c, const UiModel &m) {
  int W = c.W, y = uiNavTop(c.H);
  if (!c.hitsY(y, c.H)) return;
  gradV(c, 0, y, W, UI_NAV_H, mk(9, 20, 38), mk(6, 13, 27));
  fillRect(c, 0, y, W, 1, mk(34, 62, 92));
  static const char *labels[7] = {"NOW", "24H", "7D", "SUN", "TIME", "PIC", "SET"};
  int bw = W / 7;
  int extra = W - bw * 7;
  for (int i = 0; i < 7; ++i) {
    int x = i * bw + (i < extra ? i : extra), w = bw + (i < extra ? 1 : 0);
    bool act = ((int)m.page == i);
    float cx = x + w * 0.5f;
    if (act) {
      rrect(c, x + 3, y + 3, w - 6, UI_NAV_H - 5, 7, RStyle{T_ACTIVE_T, T_ACTIVE_B, 255, mk(52, 150, 180), mk(26, 86, 112), 255, 1.0f});
      gradH(c, x + 9, y, w - 18, 2, AURORA_L, AURORA_M);
    }
    navIcon(c, i, cx, (float)(y + 11), act ? T_TEXT : T_DIM);
    text(c, FONT_XS, (int)cx, y + 26, labels[i], act ? T_TEXT : T_MUTED, AL_CENTER, 255, 0);
  }
}

static void panel(Canvas &c, int x, int y, int w, int h, bool raised = false, float r = 9) {
  if (raised) card(c, x, y, w, h, r, T_PANEL2_T, T_PANEL2_B, T_EDGE_T, T_EDGE_B);
  else        card(c, x, y, w, h, r, T_PANEL_T, T_PANEL_B, mk(44, 74, 106), T_EDGE_B);
}

static inline void textMid(Canvas &c, const AFont &f, int cx, int cy, const char *s, Col col) {
  int capHalf = f.ascent * 7 / 10 / 2;            // ~cap-height/2
  text(c, f, cx, cy + capHalf + 1, s, col, AL_CENTER);
}

enum BtnKind { BTN_NORMAL, BTN_ACTIVE, BTN_PRIMARY, BTN_GHOST };
static void uiButton(Canvas &c, const Rect &r, const char *label, BtnKind k = BTN_NORMAL, const AFont &f = FONT_SMB) {
  if (!c.hitsY(r.y, r.y + r.h)) return;
  float rad = r.h >= 28 ? 8.0f : 7.0f;
  Col tc = T_MUTED;
  switch (k) {
    case BTN_ACTIVE:
      rrect(c, r.x, r.y, r.w, r.h, rad, RStyle{T_ACTIVE_T, T_ACTIVE_B, 255, mk(70, 190, 225), mk(30, 110, 140), 255, 1.0f}); tc = T_TEXT; break;
    case BTN_PRIMARY:
      rrect(c, r.x, r.y, r.w, r.h, rad, RStyle{mk(40, 205, 214), mk(26, 134, 186), 255, mk(150, 240, 255), mk(40, 150, 200), 255, 1.0f}); tc = mk(3, 24, 40); break;
    case BTN_GHOST:
      rrect(c, r.x, r.y, r.w, r.h, rad, RStyle{T_PANEL_T, T_PANEL_B, 120, mk(54, 86, 118), mk(36, 60, 88), 255, 1.0f}); break;
    default:
      rrect(c, r.x, r.y, r.w, r.h, rad, RStyle{T_PANEL2_T, T_PANEL2_B, 255, mk(62, 98, 134), mk(38, 64, 94), 255, 1.0f}); break;
  }
  textMid(c, f, r.x + r.w / 2, r.y + r.h / 2, label, tc);
}

static void uiToggle(Canvas &c, const Rect &r, const char *label, bool on) {
  if (!c.hitsY(r.y, r.y + r.h)) return;
  rrect(c, r.x, r.y, r.w, r.h, 7, RStyle{T_PANEL2_T, T_PANEL2_B, 255, on ? mk(70, 190, 225) : mk(62, 98, 134), on ? mk(30, 110, 140) : mk(38, 64, 94), 255, 1.0f});
  // switch graphic on the left
  bool narrow = r.w < 90;
  float sw = narrow ? 14.0f : 20.0f, sh = narrow ? 8.0f : 10.0f, sx = r.x + (narrow ? 6.0f : 8.0f), sy = r.y + r.h * 0.5f - sh * 0.5f;
  fillRRect(c, sx, sy, sw, sh, sh * 0.5f, on ? T_TEAL : mk(52, 72, 98));
  disc(c, on ? sx + sw - sh * 0.5f : sx + sh * 0.5f, sy + sh * 0.5f, sh * 0.36f + 0.6f, on ? mk(240, 255, 250) : mk(150, 168, 188));
  int lx0 = (int)(sx + sw + 4);
  textMid(c, narrow ? FONT_SM : FONT_SMB, lx0 + (r.x + r.w - lx0) / 2, r.y + r.h / 2, label, on ? T_TEXT : T_MUTED);
}

static void uiStepper(Canvas &c, const Rect &minus, const Rect &plus, const Rect &val, const char *valueText) {
  uiButton(c, minus, "-", BTN_NORMAL, FONT_MD);
  uiButton(c, plus, "+", BTN_NORMAL, FONT_MD);
  textMid(c, FONT_SM, val.x + val.w / 2, val.y + val.h / 2, valueText, T_TEXT);
}

// horizontal slider; returns knob x
static void uiSlider(Canvas &c, int x, int cy, int w, float frac, Col a, Col b) {
  frac = clamp01(frac);
  fillRRect(c, x, cy - 3, w, 6, 3, mk(34, 56, 84));
  float kx = x + frac * (w - 1);
  if (kx > x + 2) rrect(c, x, cy - 3, kx - x, 6, 3, RStyle{a, b, 255, a, b, 0, 0});
  glow(c, kx, cy, 5, 15, a, 0.35f);
  disc(c, kx, cy, 7.5f, mk(14, 30, 48));
  discV(c, kx, cy, 6.5f, mk(255, 255, 255), mk(200, 220, 240));
}

static void uiLabel(Canvas &c, int x, int cy, const char *s) { text(c, FONT_SM, x, cy + 4, s, T_MUTED); }

// ----------------------------------------------------------------------------
// Layout (shared with touch handling)
// ----------------------------------------------------------------------------
struct SettingsLayout {
  Rect wifi, loc;
  Rect rotLabel, rot[4];
  Rect brTrack, brValue;
  Rect photos, rescan;
  Rect mouse, cal;
};
static SettingsLayout settingsLayout(int W, int H) {
  SettingsLayout L; (void)H;
  if (uiLandscape(W)) {
    L.wifi = {8, 31, 148, 26};  L.loc = {164, 31, 148, 26};
    L.rotLabel = {8, 67, 70, 24};
    for (int i = 0; i < 4; ++i) L.rot[i] = {84 + i * 57, 67, 57, 24};
    L.brTrack = {84, 102, 186, 26}; L.brValue = {276, 102, 36, 26};
    L.photos = {8, 138, 148, 26}; L.rescan = {164, 138, 148, 26};
    L.mouse = {8, 174, 148, 26}; L.cal = {164, 174, 148, 26};
  } else {
    int pw = (W - 24) / 2;
    L.wifi = {8, 32, pw, 28};  L.loc = {16 + pw, 32, pw, 28};
    L.rotLabel = {8, 70, 70, 26};
    int sw = (W - 8 - 76) / 4;
    for (int i = 0; i < 4; ++i) L.rot[i] = {76 + i * sw, 70, sw, 26};
    L.brTrack = {76, 108, W - 76 - 44, 26}; L.brValue = {W - 40, 108, 32, 26};
    L.photos = {8, 148, pw, 28}; L.rescan = {16 + pw, 148, pw, 28};
    L.mouse = {8, 188, pw, 28}; L.cal = {16 + pw, 188, pw, 28};
  }
  return L;
}

struct KbLayout {
  Rect cancel, field;
  int keyTop, rowH, cols, kw;
  Rect mode, shift, space, del, ok;
};
static KbLayout kbLayout(int W, int H) {
  KbLayout K; (void)H;
  bool land = uiLandscape(W);
  K.cancel = {W - 72, 0, 72, 30};
  K.field = {5, 46, W - 10, 24};
  K.keyTop = 74; K.rowH = land ? 30 : 38; K.cols = 8; K.kw = W / K.cols;
  int y = K.keyTop + 4 * K.rowH + 2, gap = 3, x = 3;
  int wm = land ? 48 : 40, ws = land ? 55 : 46;
  K.mode = {x, y, wm, K.rowH}; x += wm + gap;
  K.shift = {x, y, ws, K.rowH}; x += ws + gap;
  int sp = W - 3 - x - ws - 52 - 2 * gap; if (sp < 40) sp = 40;
  K.space = {x, y, sp, K.rowH}; x += sp + gap;
  K.del = {x, y, ws, K.rowH}; x += ws + gap;
  K.ok = {x, y, W - x - 3, K.rowH};
  return K;
}
static const char *kbRows(int row, bool upper, bool sym) {
  static const char *lo[] = {"qwertyui", "opasdfgh", "jklzxcvb", "nm.-_@!?"};
  static const char *up[] = {"QWERTYUI", "OPASDFGH", "JKLZXCVB", "NM.-_@!?"};
  static const char *sy[] = {"12345678", "90.-+*$#", "=/:;(),?", "[]{}<>\\|"};
  return sym ? sy[row] : (upper ? up[row] : lo[row]);
}

struct ListLayout { int top, pitch, rowH, maxRows; Rect back, rescan; };
static ListLayout wifiListLayout(int W, int H) {
  ListLayout L;
  L.top = 34; L.pitch = 28; L.rowH = 26;
  L.maxRows = (H - 34 - 34) / 28; if (L.maxRows > 8) L.maxRows = 8;
  L.back = {8, H - 34, 90, 28}; L.rescan = {W - 98, H - 34, 90, 28};
  return L;
}
static inline Rect wifiRowRect(const ListLayout &L, int W, int i) { return Rect{8, L.top + i * L.pitch, W - 16, L.rowH}; }

struct LocLayout { Rect name, lat, lon, back, save; };
static LocLayout locLayout(int W, int H) {
  LocLayout L; (void)H;
  int fx = 78, fw = W - fx - 8;
  L.name = {fx, 36, fw, 30}; L.lat = {fx, 76, fw, 30}; L.lon = {fx, 116, fw, 30};
  L.back = {8, 158, 84, 30}; L.save = {W - 98, 158, 90, 30};
  return L;
}

struct MouseLayout { Rect toggle; Rect minMinus, minPlus, maxMinus, maxPlus, movMinus, movPlus, back; int rowY[3]; };
static MouseLayout mouseLayout(int W, int H) {
  MouseLayout L; (void)H; (void)W;
  L.toggle = {10, 36, 128, 30};
  L.rowY[0] = 78; L.rowY[1] = 112; L.rowY[2] = 146;
  L.minMinus = {112, 78, 44, 28};  L.minPlus = {162, 78, 44, 28};
  L.maxMinus = {112, 112, 44, 28}; L.maxPlus = {162, 112, 44, 28};
  L.movMinus = {112, 146, 44, 28}; L.movPlus = {162, 146, 44, 28};
  L.back = {10, 184, 84, 28};
  return L;
}


// ----------------------------------------------------------------------------
// NOW
// ----------------------------------------------------------------------------
static void wxTheme(int code, bool day, Col &top, Col &bot, Col &gl) {
  if (!day) { top = mk(20, 32, 82); bot = mk(9, 15, 42); gl = mk(130, 150, 255); }
  else if (code <= 1)  { top = mk(24, 72, 140); bot = mk(13, 38, 84); gl = mk(255, 196, 90); }
  else if (code == 2)  { top = mk(30, 70, 120); bot = mk(16, 40, 82); gl = mk(255, 200, 110); }
  else if (code == 3 || code == 45 || code == 48) { top = mk(46, 62, 86); bot = mk(25, 35, 54); gl = mk(170, 190, 220); }
  else if ((code >= 71 && code <= 77) || code == 85 || code == 86) { top = mk(48, 76, 108); bot = mk(27, 44, 70); gl = mk(200, 225, 255); }
  else if (code >= 95) { top = mk(48, 38, 88); bot = mk(24, 18, 50); gl = mk(255, 210, 100); }
  else { top = mk(30, 52, 80); bot = mk(16, 29, 50); gl = mk(110, 170, 255); }
  if (!day && code >= 2) { top = lerpCol(top, mk(26, 34, 62), 0.5f); bot = lerpCol(bot, mk(10, 14, 34), 0.5f); }
}

struct NowGeo { Rect hero, tiles[5], icon; int iconCx, iconCy, iconSize; };
static NowGeo nowGeo(int W, int H) {
  NowGeo g; int top = uiBodyTop(), bot = uiBodyBottom(H);
  if (uiLandscape(W)) {
    g.hero = {8, top, W - 16, 110};
    int tw = (W - 16 - 24) / 5, ty = top + 116;
    for (int i = 0; i < 5; ++i) g.tiles[i] = {8 + i * (tw + 6), ty, tw, bot - ty};
    g.iconSize = 96; g.iconCx = W - 64; g.iconCy = top + 52;
  } else {
    g.hero = {8, top, W - 16, 130};
    int tw = (W - 16 - 12) / 3, th = 57, ty = top + 136;
    for (int i = 0; i < 5; ++i) g.tiles[i] = {8 + (i % 3) * (tw + 6), ty + (i / 3) * (th + 6), tw, th};
    g.iconSize = 68; g.iconCx = W - 50; g.iconCy = top + 46;
  }
  g.icon = {g.iconCx - 54, g.hero.y, 108, g.hero.h};
  return g;
}

static void miniTile(Canvas &c, const Rect &r, const char *value, const char *label, Col valCol) {
  panel(c, r.x, r.y, r.w, r.h, false, 8);
  text(c, FONT_MD, r.x + r.w / 2, r.y + 38, value, valCol, AL_CENTER);
  text(c, FONT_XXS, r.x + r.w / 2, r.y + r.h - 6, label, T_MUTED, AL_CENTER, 255, 0);
}

static void pageNow(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "NOW");
  int W = c.W, H = c.H;
  NowGeo g = nowGeo(W, H);
  if (!m.wx || !m.wx->valid) {
    panel(c, 8, uiBodyTop(), W - 16, uiBodyBottom(H) - uiBodyTop(), true, 12);
    int cy = (uiBodyTop() + uiBodyBottom(H)) / 2;
    arcStroke(c, W / 2, cy - 14, 13, 3.4f, -0.4f + 3.14159f * 0.0f, 2.6f, AURORA_L, AURORA_R, 255);
    text(c, FONT_MD, W / 2, cy + 24, "Waiting for weather", T_TEXT, AL_CENTER);
    text(c, FONT_SM, W / 2, cy + 42, m.wifiOn ? "Fetching forecast..." : "Connect Wi-Fi in Settings", T_MUTED, AL_CENTER);
    uiNav(c, m); return;
  }
  const Weather &w = *m.wx;
  Col tT, tB, tG; wxTheme(w.code, w.isDay != 0, tT, tB, tG);
  const Rect &hr = g.hero;
  rrect(c, hr.x, hr.y, hr.w, hr.h, 13, RStyle{tT, tB, 255, lerpCol(tT, mk(190, 220, 255), 0.35f), lerpCol(tB, mk(120, 160, 210), 0.25f), 255, 1.0f});
  {
    ClipScope cs(c, hr.x + 1, hr.y + 1, hr.w - 2, hr.h - 2);
    glow(c, g.iconCx, g.iconCy, 6, 86, tG, 0.30f);
  }
  strokeRRect(c, hr.x, hr.y, hr.w, hr.h, 13, lerpCol(tT, mk(190, 220, 255), 0.35f), 255, 1.0f);
  bool land = uiLandscape(W);
  int hx = hr.x + 14;
  char b[40], u[24];
  if (w.updated[0] && w.updated[0] != '-') { fmt12(u, sizeof(u), w.updated); snprintf(b, sizeof(b), "UPDATED %s", u); text(c, FONT_XXS, hx, hr.y + 15, b, mk(170, 196, 226), AL_LEFT, 255, 1); }
  snprintf(b, sizeof(b), "%d", uiTemp(m, w.temp));
  int tw = textWidth(FONT_HUGE, b);
  int tb = hr.y + (land ? 70 : 82);
  textGrad(c, FONT_HUGE, hx, tb, b, mk(255, 255, 255), mk(200, 226, 255));
  text(c, FONT_XL, hx + tw + 3, tb - 18, m.fahrenheit ? S_DEG "F" : S_DEG "C", mk(190, 224, 255));
  text(c, FONT_MD, hx, hr.y + (land ? 89 : 104), conditionText(w.code), T_TEXT);
  char f1[16], f2[16], f3[16];
  fmtTemp(f1, sizeof(f1), m, w.apparent);
  if (m.wx->dayMax[0] != 0 || m.wx->dayMin[0] != 0) {
    fmtTemp(f2, sizeof(f2), m, w.dayMax[0]); fmtTemp(f3, sizeof(f3), m, w.dayMin[0]);
    snprintf(b, sizeof(b), "Feels %s  " S_DOT "  H %s  L %s", f1, f2, f3);
  } else snprintf(b, sizeof(b), "Feels like %s", f1);
  text(c, FONT_SM, hx, hr.y + (land ? 105 : 121), b, mk(176, 200, 226));
  weatherIcon(c, w.code, w.isDay != 0, (float)g.iconCx, (float)g.iconCy, (float)g.iconSize, m.phase);

  // metric tiles
  char v[24];
  { // humidity - ring gauge
    const Rect &r = g.tiles[0]; snprintf(v, sizeof(v), "%d%%", (int)lroundf(w.humidity));
    miniTile(c, r, v, "HUMIDITY", T_TEXT);
    float cx = r.x + r.w * 0.5f, cy = r.y + 15;
    ring(c, cx, cy, 6.2f, mk(40, 70, 100), 255, 1.8f);
    float fr = clamp01(w.humidity / 100.0f);
    if (fr > 0.02f) arcStroke(c, cx, cy, 6.2f, 1.5708f, 1.5708f - 6.2832f * fr, 1.8f, T_CYAN, T_BLUE);
  }
  { // wind - arrow rotated downwind
    const Rect &r = g.tiles[1]; fmtWind(v, sizeof(v), m, w.wind);
    char lb[16]; snprintf(lb, sizeof(lb), "WIND %s", compass(w.windDir));
    miniTile(c, r, v, lb, T_TEXT);
    iconArrow(c, r.x + r.w * 0.5f, r.y + 15, (float)(w.windDir + 180), 6.0f, T_CYAN);
  }
  { // pressure
    const Rect &r = g.tiles[2]; snprintf(v, sizeof(v), "%d", (int)lroundf(w.pressure));
    miniTile(c, r, v, "PRESSURE", T_TEXT);
    iconGauge(c, r.x + r.w * 0.5f, r.y + 13, T_VIOLET);
  }
  { // UV
    const Rect &r = g.tiles[3]; snprintf(v, sizeof(v), "%.1f", w.uv);
    miniTile(c, r, v, "UV INDEX", uvColor(w.uv));
    iconSun(c, r.x + r.w * 0.5f, r.y + 15, uvColor(w.uv), 3.0f);
  }
  { // rain
    const Rect &r = g.tiles[4]; snprintf(v, sizeof(v), "%d%%", (int)lroundf(w.precipProb));
    miniTile(c, r, v, "RAIN", T_TEXT);
    iconDrop(c, r.x + r.w * 0.5f, r.y + 17, 4.6f, T_RAIN);
  }
  uiNav(c, m);
}

// ----------------------------------------------------------------------------
// 24 HOURS
// ----------------------------------------------------------------------------
static float catmull(float p0, float p1, float p2, float p3, float t) {
  return 0.5f * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);
}
static void niceAxis(float lo, float hi, float &aMin, float &aMax, float &step) {
  float span = hi - lo; if (span < 2) { lo -= (2 - span) * 0.5f; hi += (2 - span) * 0.5f; span = 2; }
  static const float steps[] = {1, 2, 5, 10, 20};
  step = 20;
  for (int i = 0; i < 5; ++i) if (span / steps[i] <= 4.0f) { step = steps[i]; break; }
  aMin = floorf(lo / step) * step; aMax = ceilf(hi / step) * step;
  if (aMax - aMin < step * 2) aMax = aMin + step * 2;
}

static void pageHourly(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "24H TEMP");
  int W = c.W, H = c.H, top = uiBodyTop(), bot = uiBodyBottom(H);
  panel(c, 6, top, W - 12, bot - top, false, 10);
  if (!m.wx || !m.wx->valid) { text(c, FONT_MD, W / 2, (top + bot) / 2, "No weather data", T_MUTED, AL_CENTER); uiNav(c, m); return; }
  const Weather &w = *m.wx;
  float tv[HOURS]; float lo = 1e9f, hi = -1e9f; int iMax = 0, iMin = 0;
  for (int i = 0; i < HOURS; ++i) {
    tv[i] = m.fahrenheit ? w.hourlyTemp[i] * 1.8f + 32.0f : w.hourlyTemp[i];
    if (tv[i] > hi) { hi = tv[i]; iMax = i; }
    if (tv[i] < lo) { lo = tv[i]; iMin = i; }
  }
  float aMin, aMax, step; niceAxis(lo, hi, aMin, aMax, step);
  const bool land = uiLandscape(W);
  const int left = 44, right = W - 18;
  const int ctop = top + (land ? 40 : 44), cbot = bot - (land ? 60 : 84);
  auto yOf = [&](float v) { return cbot - (v - aMin) / (aMax - aMin) * (cbot - ctop); };
  auto xOf = [&](float i) { return left + i * (right - left) / (float)(HOURS - 1); };

  char b[32];
  text(c, FONT_XS, 16, top + 18, land ? "NEXT 24 HOURS" : "24 HOURS", T_MUTED, AL_LEFT, 255, 1);
  { char h1[12], l1[12]; snprintf(h1, sizeof(h1), "%d" S_DEG, (int)lroundf(hi)); snprintf(l1, sizeof(l1), "%d" S_DEG, (int)lroundf(lo));
    int rx = W - 16;
    int lw = textWidth(FONT_SMB, l1); text(c, FONT_SMB, rx, top + 19, l1, T_CYAN, AL_RIGHT);
    int hx; 
    if (land) {
      text(c, FONT_XS, rx - lw - 4, top + 19, "LOW", T_DIM, AL_RIGHT, 255, 1);
      hx = rx - lw - 4 - textWidthSp(FONT_XS, "LOW", 1) - 12;
    } else hx = rx - lw - 12;
    int hw = textWidth(FONT_SMB, h1);
    text(c, FONT_SMB, hx, top + 19, h1, T_ORANGE, AL_RIGHT);
    if (land) text(c, FONT_XS, hx - hw - 4, top + 19, "HIGH", T_DIM, AL_RIGHT, 255, 1);
  }
  // grid + y labels
  for (float v = aMin; v <= aMax + 0.01f; v += step) {
    int y = (int)lroundf(yOf(v));
    for (int x = left; x < right; x += 6) fillRect(c, x, y, 3, 1, mk(70, 104, 140), 120);
    snprintf(b, sizeof(b), "%d", (int)lroundf(v));
    text(c, FONT_XS, left - 8, y + 4, b, T_MUTED, AL_RIGHT);
  }
  // smooth curve sampled per pixel column
  const int n = right - left + 1;
  float yc[320];                    // on the stack: freed on return, never counts against the heap
  for (int i = 0; i < n; ++i) {
    float fi = (float)i / (float)(n - 1) * (HOURS - 1);
    int k = (int)fi; if (k > HOURS - 2) k = HOURS - 2;
    float t = fi - k;
    float p0 = tv[k > 0 ? k - 1 : 0], p1 = tv[k], p2 = tv[k + 1], p3 = tv[k + 2 < HOURS ? k + 2 : HOURS - 1];
    float v = catmull(p0, p1, p2, p3, t);
    yc[i] = yOf(v);
  }
  // colour lookup from the sampled y (avoids a second 1 KB array)
  auto cOf = [&](int i) { float v = aMin + (cbot - yc[i]) / (float)(cbot - ctop) * (aMax - aMin); return tempColor(m.fahrenheit ? (v - 32.0f) / 1.8f : v); };
  curveFill(c, yc, left, n, (float)cbot, T_CYAN, (float)ctop, (float)cbot, 78, 0);
  for (int i = 0; i + 2 < n; i += 2) {                       // soft glow pass
    capsule(c, left + i, yc[i], left + i + 2, yc[i + 2], 6.0f, cOf(i), 34);
  }
  for (int i = 0; i + 1 < n; ++i) {
    int j = (i + 2 < n) ? i + 2 : i + 1;
    if ((i & 1) == 0 || j == n - 1) capsule(c, left + i, yc[i], left + j, yc[j], 2.3f, cOf(i), 255);
  }
  // baseline
  fillRect(c, left, cbot, right - left + 1, 1, mk(96, 130, 166), 180);
  // markers every 3 h
  for (int i = 3; i < HOURS; i += 3) { float x = xOf(i); float y = yc[(int)lroundf(x - left)]; disc(c, x, y, 2.6f, mk(12, 26, 44)); ring(c, x, y, 2.6f, cOf((int)lroundf(x - left)), 255, 1.3f); }
  // extremes
  auto labelPill = [&](float x, float y, const char *s, Col col, bool above) {
    int tw2 = textWidth(FONT_SMB, s) + 10;
    float px = x - tw2 * 0.5f; if (px < left - 4) px = left - 4; if (px + tw2 > right + 8) px = right + 8 - tw2;
    float py = above ? y - 24 : y + 8;
    fillRRect(c, px, py, tw2, 16, 8, mk(10, 22, 40), 230);
    strokeRRect(c, px, py, tw2, 16, 8, col, 200, 1.0f);
    text(c, FONT_SMB, (int)(px + tw2 * 0.5f), (int)py + 12, s, T_TEXT, AL_CENTER);
  };
  if (iMax > 1) { float x = xOf(iMax), y = yc[(int)lroundf(x - left)]; disc(c, x, y, 3.2f, T_ORANGE); snprintf(b, sizeof(b), "%d" S_DEG, (int)lroundf(hi)); labelPill(x, y, b, T_ORANGE, true); }
  if (iMin > 1 && iMin != iMax) { float x = xOf(iMin), y = yc[(int)lroundf(x - left)]; disc(c, x, y, 3.2f, T_CYAN); snprintf(b, sizeof(b), "%d" S_DEG, (int)lroundf(lo)); labelPill(x, y, b, T_CYAN, false); }
  // now marker
  { float x = (float)left, y = yc[0]; glow(c, x, y, 3, 14, T_CYAN, 0.5f); disc(c, x, y, 5.2f, mk(12, 26, 44)); disc(c, x, y, 3.8f, T_TEXT); }
  // time labels
  int ly = cbot + 16;
  for (int i = 0; i < HOURS; ++i) {
    bool now = (i == 0);
    if (!now && (w.hourlyHour[i] % 6 != 0 || i < 3)) continue;
    float x = xOf(i);
    if (now) text(c, FONT_XS, (int)x, ly, "NOW", T_CYAN, AL_CENTER, 255, 1);
    else { int h = w.hourlyHour[i]; int h12 = h % 12 == 0 ? 12 : h % 12; snprintf(b, sizeof(b), "%d%s", h12, h >= 12 ? "P" : "A"); text(c, FONT_XS, (int)x, ly, b, T_MUTED, AL_CENTER); }
  }
  // rain probability strip
  int sy = cbot + 26, sh = land ? 20 : 26;
  text(c, FONT_XS, 16, sy + sh / 2 + 4, "RAIN", T_DIM, AL_LEFT, 255, 1);
  float pitch = (float)(right - left) / (float)(HOURS - 1);
  int bw = (int)(pitch - 2.5f); if (bw < 3) bw = 3;
  for (int i = 0; i < HOURS; ++i) {
    float x = xOf(i);
    fillRRect(c, x - bw * 0.5f, sy + sh - 2, bw, 2, 1, mk(40, 66, 96));
    int p = w.hourlyRainProb[i]; if (p <= 0) continue;
    float hh = 2 + (sh - 2) * clamp01(p / 100.0f);
    fillRRectV(c, x - bw * 0.5f, sy + sh - hh, bw, hh, 1.5f, mk(130, 205, 255), mk(70, 140, 235), (uint8_t)(90 + p * 1.5f));
  }
  uiNav(c, m);
}

// ----------------------------------------------------------------------------
// 7 DAY
// ----------------------------------------------------------------------------
static void pageDaily(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "7-DAY");
  int W = c.W, H = c.H, top = UI_HDR_H + 5, bot = uiBodyBottom(H) + 3;
  int rowH = (bot - top) / DAYS;
  bool valid = m.wx && m.wx->valid;
  float wMin = 1e9f, wMax = -1e9f;
  if (valid) for (int i = 0; i < DAYS; ++i) { wMin = fminf(wMin, m.wx->dayMin[i]); wMax = fmaxf(wMax, m.wx->dayMax[i]); }
  if (wMax - wMin < 1) wMax = wMin + 1;
  bool land = uiLandscape(W);
  int dayX = 16, iconX = land ? 92 : 84, rainX = land ? 114 : 14;
  int loR = land ? 178 : 0, barL = land ? loR + 8 : 112, hiL = W - 12 - 34, barR = land ? hiL - 8 : W - 58;
  for (int i = 0; i < DAYS; ++i) {
    int y = top + i * rowH, h = rowH - 2, cy = y + h / 2;
    if (!c.hitsY(y, y + h)) continue;
    if (i == 0) {
      rrect(c, 6, y, W - 12, h, 8, RStyle{T_PANEL2_T, T_PANEL2_B, 255, mk(70, 150, 190), mk(36, 80, 112), 255, 1.0f});
      fillRRectV(c, 6, y + 4, 3, h - 8, 1.5f, AURORA_L, AURORA_M);
    } else panel(c, 6, y, W - 12, h, false, 8);
    if (!valid) { text(c, FONT_SMB, dayX, cy + 4, "---", T_DIM); continue; }
    const Weather &w = *m.wx;
    char b[16];
    int dayBase = land ? cy + 4 : cy - 1;
    text(c, FONT_SMB, dayX, dayBase, w.dayName[i], i == 0 ? T_CYAN : T_TEXT);
    { ClipScope cs(c, 8, y, W - 16, h);
      weatherIcon(c, w.dayCode[i], true, (float)iconX, (float)cy + 0.5f, (w.dayCode[i] >= 45 ? (land ? 21.0f : 30.0f) : (land ? 25.0f : 34.0f)), 0); }
    int rainBase = land ? cy + 4 : cy + 13;
    iconDrop(c, rainX + 3, rainBase - 3, 2.6f, w.dayRain[i] > 0 ? T_RAIN : T_DIM, w.dayRain[i] > 0 ? 255 : 150);
    snprintf(b, sizeof(b), "%d%%", w.dayRain[i]);
    text(c, land ? FONT_SM : FONT_XS, rainX + 10, rainBase, b, w.dayRain[i] > 0 ? T_RAIN : T_DIM);
    snprintf(b, sizeof(b), "%d" S_DEG, uiTemp(m, w.dayMin[i]));
    if (land) text(c, FONT_SM, loR, cy + 4, b, T_MUTED, AL_RIGHT);
    else text(c, FONT_SM, W - 14, cy + 13, b, T_MUTED, AL_RIGHT);
    // range bar
    float bw = (float)(barR - barL);
    fillRRect(c, barL, cy - 2.5f, bw, 5, 2.5f, mk(32, 54, 82));
    float x0 = barL + (w.dayMin[i] - wMin) / (wMax - wMin) * bw, x1 = barL + (w.dayMax[i] - wMin) / (wMax - wMin) * bw;
    if (x1 - x0 < 6) x1 = x0 + 6;
    { Col ca = tempColor(w.dayMin[i]), cb = tempColor(w.dayMax[i]);
      rrect(c, x0, cy - 2.5f, x1 - x0, 5, 2.5f, RStyle{ca, ca, 255, ca, ca, 0, 0});
      for (int px = (int)x0; px < (int)x1; px += 1) fillRect(c, px, (int)(cy - 1.5f), 1, 3, lerpCol(ca, cb, (px - x0) / (x1 - x0))); }
    if (i == 0) { float xn = barL + (w.temp - wMin) / (wMax - wMin) * bw; xn = fminf(fmaxf(xn, barL + 2), barR - 2); disc(c, xn, cy, 3.8f, mk(10, 22, 40)); disc(c, xn, cy, 2.6f, T_TEXT); }
    snprintf(b, sizeof(b), "%d" S_DEG, uiTemp(m, w.dayMax[i]));
    if (land) text(c, FONT_SMB, hiL, cy + 4, b, T_TEXT);
    else text(c, FONT_SMB, W - 14, cy - 1, b, T_TEXT, AL_RIGHT);
  }
  uiNav(c, m);
}

// ----------------------------------------------------------------------------
// SUN
// ----------------------------------------------------------------------------
static void fmtHM(char *o, size_t n, int mins) { if (mins < 0) mins = 0; snprintf(o, n, "%dh %02dm", mins / 60, mins % 60); }

static void pageSun(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "SUN");
  int W = c.W, H = c.H, top = uiBodyTop(), bot = uiBodyBottom(H);
  panel(c, 6, top, W - 12, bot - top, false, 10);
  bool valid = m.wx && m.wx->valid;
  int rise = valid ? m.wx->sunriseMinute : 420, set = valid ? m.wx->sunsetMinute : 1080;
  int now = m.nowMinute;
  bool known = valid && now >= 0 && set > rise;
  bool day = known && now >= rise && now <= set;
  bool land = uiLandscape(W);
  int baseY = top + (land ? 116 : 130);
  float R = fminf((W - 64) * 0.5f, (float)(baseY - top - 20));
  float cx = W * 0.5f;
  // sky dome glow, confined to the half-disc above the horizon
  { ClipScope cs(c, (int)(cx - R - 6), baseY - (int)R - 6, (int)(2 * R + 12), (int)R + 6);
    if (day) glow(c, cx, (float)baseY, 4, R + 4, mk(255, 170, 80), 0.20f);
    else glow(c, cx, (float)baseY, 4, R + 4, mk(90, 110, 230), 0.16f); }
  // horizon
  fillRect(c, (int)(cx - R - 14), baseY, (int)(2 * R + 28), 1, mk(80, 112, 148), 200);
  for (int i = -1; i <= 1; ++i) fillRect(c, (int)(cx + i * R * 0.5f), baseY + 3, 1, 3, mk(70, 100, 134), 160);
  // full path (dashed) and elapsed portion (bright)
  arcStroke(c, cx, (float)baseY, R, 3.14159f, 0.0f, 2.0f, mk(70, 100, 136), mk(70, 100, 136), 150, 3.0f);
  float prog = 0;
  if (known) prog = clamp01((float)(now - rise) / (float)(set - rise));
  if (day || (known && now > set)) {
    float pe = (known && now > set) ? 1.0f : prog;
    float aMid = 3.14159f * 0.5f, aEnd = 3.14159f * (1.0f - pe);
    arcStroke(c, cx, (float)baseY, R, 3.14159f, fmaxf(aEnd, aMid), 3.4f, T_ORANGE, T_YELLOW, 255);
    if (pe > 0.5f) arcStroke(c, cx, (float)baseY, R, aMid, aEnd, 3.4f, T_YELLOW, T_ORANGE, 255);
  }
  // sun / moon marker
  if (day) {
    float a = 3.14159f * (1.0f - prog);
    sunShape(c, cx + cosf(a) * R, baseY - sinf(a) * R, 7.5f, m.phase, 0.9f);
  } else {
    moonShape(c, cx, baseY - R * 0.62f, 9.0f);
  }
  // centre read-out
  char b[32], u[24];
  if (known) {
    int mins; const char *lab;
    if (day) { mins = set - now; lab = "UNTIL SUNSET"; }
    else if (now < rise) { mins = rise - now; lab = "UNTIL SUNRISE"; }
    else { mins = rise + 1440 - now; lab = "UNTIL SUNRISE"; }
    fmtHM(b, sizeof(b), mins);
    text(c, FONT_XL, (int)cx, baseY - 26, b, T_TEXT, AL_CENTER);
    text(c, FONT_XS, (int)cx, baseY - 8, lab, T_MUTED, AL_CENTER, 255, 1);
  } else if (valid) {
    fmtHM(b, sizeof(b), set - rise);
    text(c, FONT_XL, (int)cx, baseY - 26, b, T_TEXT, AL_CENTER);
    text(c, FONT_XS, (int)cx, baseY - 8, "OF DAYLIGHT", T_MUTED, AL_CENTER, 255, 1);
  }
  // sunrise / daylight / sunset columns
  int iy = baseY + (land ? 16 : 22);
  int colL = 22, colR = W - 22;
  if (valid) {
    iconSun(c, colL + 4, iy + 6, T_ORANGE, 2.6f);
    text(c, FONT_XS, colL + 16, iy + 9, "SUNRISE", T_MUTED, AL_LEFT, 255, 1);
    fmt12(u, sizeof(u), m.wx->sunrise[0]); text(c, FONT_MD, colL, iy + 29, u, T_TEXT);
    int lw = textWidthSp(FONT_XS, "SUNSET", 1);
    text(c, FONT_XS, colR, iy + 9, "SUNSET", T_MUTED, AL_RIGHT, 255, 1);
    iconSun(c, colR - lw - 10, iy + 6, T_ORANGE, 2.6f);
    fmt12(u, sizeof(u), m.wx->sunset[0]); text(c, FONT_MD, colR, iy + 29, u, T_TEXT, AL_RIGHT);
    fmtHM(b, sizeof(b), set - rise);
    if (land) {
      text(c, FONT_XS, (int)cx, iy + 9, "DAYLIGHT", T_MUTED, AL_CENTER, 255, 1);
      text(c, FONT_MD, (int)cx, iy + 29, b, T_YELLOW, AL_CENTER);
    } else {
      text(c, FONT_XS, (int)cx, iy + 56, "DAYLIGHT", T_MUTED, AL_CENTER, 255, 1);
      text(c, FONT_LG, (int)cx, iy + 80, b, T_YELLOW, AL_CENTER);
    }
  } else text(c, FONT_SM, (int)cx, iy + 16, "Waiting for weather data", T_MUTED, AL_CENTER);
  uiNav(c, m);
}

// ----------------------------------------------------------------------------
// TIME
// ----------------------------------------------------------------------------
static void pageTime(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "TIME");
  int W = c.W, H = c.H, top = uiBodyTop(), bot = uiBodyBottom(H);
  panel(c, 8, top, W - 16, bot - top, true, 12);
  int cx = W / 2;
  if (!m.timeValid) {
    int cy = (top + bot) / 2;
    arcStroke(c, cx, cy - 22, 14, 3.4f, -0.5f, 2.8f, AURORA_L, AURORA_R, 255);
    text(c, FONT_LG, cx, cy + 20, "Syncing time", T_CYAN, AL_CENTER);
    text(c, FONT_SM, cx, cy + 40, m.wifiOn ? "NTP sync in progress" : "Connect Wi-Fi to sync", T_MUTED, AL_CENTER);
    if (m.tzName && m.tzName[0]) text(c, FONT_XS, cx, cy + 56, m.tzName, T_DIM, AL_CENTER);
    uiNav(c, m); return;
  }
  const struct tm &t = m.tm;
  bool land = uiLandscape(W);
  int h12 = t.tm_hour % 12 == 0 ? 12 : t.tm_hour % 12;
  char tb[12], ap[4], b[48];
  snprintf(tb, sizeof(tb), "%d:%02d", h12, t.tm_min);
  snprintf(ap, sizeof(ap), "%s", t.tm_hour >= 12 ? "PM" : "AM");
  int tw = textWidth(FONT_HUGE, tb), aw = textWidth(FONT_LG, ap), gap = 6;
  int total = tw + gap + aw, x0 = cx - total / 2;
  int base = top + (land ? 66 : 80);
  glow(c, (float)cx, (float)(base - 20), 10, 130, mk(60, 150, 220), 0.12f);
  textGrad(c, FONT_HUGE, x0, base, tb, mk(255, 255, 255), mk(196, 226, 255));
  text(c, FONT_LG, x0 + tw + gap, base, ap, T_CYAN);
  // divider
  gradH(c, cx - 70, base + 12, 140, 1, mk(20, 60, 90), mk(20, 60, 90));
  gradH(c, cx - 70, base + 12, 70, 1, mk(20, 50, 80), AURORA_M);
  gradH(c, cx, base + 12, 70, 1, AURORA_M, mk(20, 50, 80));
  static const char *WD[7] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
  snprintf(b, sizeof(b), "%s", WD[(t.tm_wday >= 0 && t.tm_wday < 7) ? t.tm_wday : 0]);
  text(c, FONT_XL, cx, base + 46, b, T_TEXT, AL_CENTER);
  static const char *MON[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
  snprintf(b, sizeof(b), "%s %d, %d", MON[(t.tm_mon >= 0 && t.tm_mon < 12) ? t.tm_mon : 0], t.tm_mday, t.tm_year + 1900);
  text(c, FONT_MD, cx, base + 68, b, T_MUTED, AL_CENTER);
  // location + zone
  char z[64];
  const char *abbr = (m.tzAbbr && m.tzAbbr[0]) ? m.tzAbbr : "";
  snprintf(z, sizeof(z), "%s%s%s", m.location, abbr[0] ? "  " S_DOT "  " : "", abbr);
  text(c, FONT_XS, cx, base + 86, z, T_DIM, AL_CENTER, 255, 0);
  // day progress bar: night dim, daylight warm, now marker
  if (m.wx && m.wx->valid) {
    int bx = 28, bw = W - 56, by = bot - 13;
    fillRRect(c, bx, by, bw, 5, 2.5f, mk(26, 44, 72));
    float x0f = bx + bw * (m.wx->sunriseMinute / 1440.0f), x1f = bx + bw * (m.wx->sunsetMinute / 1440.0f);
    rrect(c, x0f, (float)by, x1f - x0f, 5, 2.5f, RStyle{mk(255, 170, 70), mk(255, 170, 70), 255, mk(255, 170, 70), mk(255, 170, 70), 0, 0});
    for (int px = (int)x0f; px < (int)x1f; ++px) fillRect(c, px, by + 1, 1, 3, lerpCol(T_ORANGE, T_YELLOW, 1.0f - fabsf((px - x0f) / (x1f - x0f) - 0.5f) * 2.0f));
    float nx = bx + bw * ((t.tm_hour * 60 + t.tm_min) / 1440.0f);
    glow(c, nx, by + 2.5f, 2, 9, T_TEXT, 0.4f);
    disc(c, nx, by + 2.5f, 3.6f, mk(10, 22, 40)); disc(c, nx, by + 2.5f, 2.6f, T_TEXT);
  }
  uiNav(c, m);
}

// ----------------------------------------------------------------------------
// PHOTOS
// ----------------------------------------------------------------------------
// Shown when the PIC tab has no photo to display (no SD card, empty folder, or
// nothing decodable). When photos exist the sketch decodes the JPEG itself and
// overlays only the navigation bar.
static void pagePhoto(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "PHOTOS");
  int W = c.W, H = c.H, top = uiBodyTop(), bot = uiBodyBottom(H);
  panel(c, 8, top, W - 16, bot - top, true, 12);
  Col st = (m.sdReady && !m.photoFailed) ? T_TEAL : T_ORANGE;
  disc(c, 30, top + 22, 12, st, 36);
  iconSD(c, 30, top + 22, st, mk(16, 36, 58));
  const char *head = !m.sdReady ? "SD card not found" : (m.photoFailed ? "Photos can't be displayed" : "SD card ready");
  text(c, FONT_SMB, 50, top + 20, head, st);
  char b[56];
  if (!m.sdReady) snprintf(b, sizeof(b), "Insert a FAT32 card, then Rescan SD");
  else if (m.photoCount == 0) snprintf(b, sizeof(b), "No JPEG files found in /photos");
  else snprintf(b, sizeof(b), "%d JPEG photo%s in /photos", m.photoCount, m.photoCount == 1 ? "" : "s");
  textFit(c, FONT_SM, 50, top + 36, b, T_MUTED, W - 70);
  gradH(c, 20, top + 50, W - 40, 1, mk(50, 80, 112), mk(50, 80, 112));
  int gx = 20, gw = (W - 40 - 8) / 2, gy = top + 58, gh = 30;
  struct Cell { const char *l; char v[20]; Col col; } cells[4];
  cells[0] = {"PHOTO TAB", "", m.photoEnabled ? T_TEAL : T_MUTED}; snprintf(cells[0].v, 20, "%s", m.photoEnabled ? "In cycle" : "Hidden");
  cells[1] = {"SHOWN FOR", "", T_TEXT}; snprintf(cells[1].v, 20, "%d sec", m.cycleSec);
  cells[2] = {"ORDER", "", T_TEXT}; snprintf(cells[2].v, 20, "A to Z");
  cells[3] = {"NEXT PHOTO", "", T_TEXT}; snprintf(cells[3].v, 20, "Each visit");
  for (int i = 0; i < 4; ++i) {
    int x = gx + (i % 2) * (gw + 8), y = gy + (i / 2) * (gh + 6);
    fillRRect(c, x, y, gw, gh, 7, mk(12, 26, 46), 200);
    strokeRRect(c, x, y, gw, gh, 7, mk(40, 68, 98), 255, 1.0f);
    text(c, FONT_XXS, x + 10, y + 12, cells[i].l, T_DIM, AL_LEFT, 255, 1);
    text(c, FONT_SMB, x + 10, y + 25, cells[i].v, cells[i].col);
  }
  const char *hint = m.photoFailed ? "Use baseline JPEGs up to about 2500 px wide"
                   : (!m.sdReady ? "Card needs a /photos folder with .jpg files" : (m.photoCount == 0 ? "Copy .jpg files to the /photos folder" : "Photos appear here automatically"));
  text(c, FONT_SM, W / 2, bot - 14, hint, T_MUTED, AL_CENTER);
  uiNav(c, m);
}

// ----------------------------------------------------------------------------
// SETTINGS
// ----------------------------------------------------------------------------
static void pageSettingsMain(Canvas &c, const UiModel &m) {
  uiBackground(c);
  uiHeader(c, m, (m.status && m.status[0]) ? m.status : "SETTINGS");
  int W = c.W, H = c.H; SettingsLayout L = settingsLayout(W, H);
  char b[32];
  bool wide = L.wifi.w >= 130;
  uiButton(c, L.wifi, wide ? (m.wifiOn ? "WI-FI  CONNECTED" : "WI-FI SETUP") : (m.wifiOn ? "WI-FI ON" : "WI-FI"), m.wifiOn ? BTN_ACTIVE : BTN_NORMAL);
  uiButton(c, L.loc, "LOCATION");
  uiLabel(c, L.rotLabel.x, L.rotLabel.y + L.rotLabel.h / 2, "Rotation");
  { // segmented control
    int x = L.rot[0].x, y = L.rot[0].y, w = L.rot[3].x + L.rot[3].w - x, h = L.rot[0].h;
    fillRRect(c, x, y, w, h, 7, mk(12, 26, 46));
    strokeRRect(c, x, y, w, h, 7, mk(50, 82, 114), 255, 1.0f);
    for (int i = 0; i < 4; ++i) {
      const Rect &r = L.rot[i];
      if (m.rotation == i) {
        rrect(c, r.x + 2, r.y + 2, r.w - 4, r.h - 4, 5, RStyle{mk(30, 140, 170), mk(20, 96, 130), 255, mk(90, 210, 235), mk(40, 130, 160), 255, 1.0f});
      } else if (i > 0 && m.rotation != i - 1) fillRect(c, r.x, r.y + 6, 1, r.h - 12, mk(50, 82, 114));
      snprintf(b, sizeof(b), "%d" S_DEG, i * 90);
      textMid(c, FONT_SMB, r.x + r.w / 2, r.y + r.h / 2, b, m.rotation == i ? T_TEXT : T_MUTED);
    }
  }
  uiLabel(c, 8, L.brTrack.y + L.brTrack.h / 2, "Brightness");
  uiSlider(c, L.brTrack.x + 8, L.brTrack.y + L.brTrack.h / 2, L.brTrack.w - 16, (m.brightness - 10) / 90.0f, T_YELLOW, T_ORANGE);
  snprintf(b, sizeof(b), "%d%%", m.brightness);
  text(c, FONT_SMB, L.brValue.x + L.brValue.w, L.brValue.y + L.brValue.h / 2 + 5, b, T_TEXT, AL_RIGHT);
  uiToggle(c, L.photos, wide ? "Photo tab in cycle" : "Photo tab", m.photoEnabled);
  uiButton(c, L.rescan, "RESCAN SD");
  uiButton(c, L.mouse, wide ? "MOUSE WIGGLER" : "MOUSE", m.mouseEnabled ? BTN_ACTIVE : BTN_NORMAL);
  uiButton(c, L.cal, wide ? "CALIBRATE TOUCH" : "CALIBRATE");
  uiNav(c, m);
}

static void spinnerArc(Canvas &c, float cx, float cy, float r, float phase) {
  arcStroke(c, cx, cy, r, 0.4f + phase, 0.4f + phase + 4.2f, 3.0f, AURORA_L, AURORA_R, 255);
  ring(c, cx, cy, r, mk(30, 56, 86), 120, 1.5f);
}

static void pageWifiScanning(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "WI-FI SCAN");
  int W = c.W, H = c.H, cy = H / 2 - 6;
  glow(c, (float)(W / 2), (float)(cy - 12), 6, 70, mk(60, 190, 200), 0.18f);
  spinnerArc(c, (float)(W / 2), (float)(cy - 16), 17, m.phase * 0.0f);
  iconWifi(c, (float)(W / 2), (float)(cy - 24), T_TEXT);
  text(c, FONT_MD, W / 2, cy + 28, "Scanning for networks", T_TEXT, AL_CENTER);
  text(c, FONT_SM, W / 2, cy + 46, "Passive scan - this takes a few seconds", T_MUTED, AL_CENTER);
  uiButton(c, wifiListLayout(W, H).back, "BACK");
}

static void sigBars(Canvas &c, int x, int y, int level) {         // level 0..4, drawn bottom-aligned at y
  for (int i = 0; i < 4; ++i) {
    int h = 4 + i * 3;
    fillRRect(c, x + i * 5, y - h, 3, h, 1.2f, i < level ? T_TEAL : mk(44, 68, 96));
  }
}
static int rssiLevel(int r) { return r > -55 ? 4 : (r > -67 ? 3 : (r > -75 ? 2 : (r > -85 ? 1 : 0))); }

static void pageWifiList(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "SELECT WI-FI");
  int W = c.W, H = c.H; ListLayout L = wifiListLayout(W, H);
  int rows = m.scanCount < L.maxRows ? m.scanCount : L.maxRows;
  if (rows == 0) {
    text(c, FONT_MD, W / 2, H / 2 - 4, "No networks found", T_ORANGE, AL_CENTER);
    text(c, FONT_SM, W / 2, H / 2 + 14, "Move closer to the router and rescan", T_MUTED, AL_CENTER);
  }
  char b[40];
  for (int i = 0; i < rows; ++i) {
    Rect r = wifiRowRect(L, W, i);
    if (!c.hitsY(r.y, r.y + r.h)) continue;
    panel(c, r.x, r.y, r.w, r.h, false, 8);
    sigBars(c, r.x + 12, r.y + r.h - 6, rssiLevel(m.rssi[i]));
    const char *nm = m.ssids[i][0] ? m.ssids[i] : "<hidden network>";
    textFit(c, FONT_SMB, r.x + 40, r.y + r.h / 2 + 5, nm, T_TEXT, r.w - 40 - 64);
    snprintf(b, sizeof(b), "%d dBm", m.rssi[i]);
    text(c, FONT_XS, r.x + r.w - 10, r.y + r.h / 2 + 4, b, T_DIM, AL_RIGHT);
  }
  uiButton(c, L.back, "BACK");
  uiButton(c, L.rescan, "RESCAN", BTN_ACTIVE);
}

static void pageKeyboard(Canvas &c, const UiModel &m) {
  int W = c.W, H = c.H; KbLayout K = kbLayout(W, H);
  uiBackground(c);
  gradV(c, 0, 0, W, 30, mk(24, 48, 78), mk(16, 34, 58));
  gradH(c, 0, 29, W, 1, AURORA_L, AURORA_R);
  text(c, FONT_SMB, 10, 19, m.kbTitle, T_TEXT);
  uiButton(c, Rect{K.cancel.x + 6, 3, K.cancel.w - 10, 23}, "CANCEL", BTN_GHOST, FONT_XS);
  textFit(c, FONT_SM, 8, 42, m.kbSub, T_MUTED, W - 16);
  // text field (shows the tail of long input), unmasked on purpose so typos are visible
  rrect(c, K.field.x, K.field.y, K.field.w, K.field.h, 6, RStyle{mk(9, 20, 38), mk(12, 26, 46), 255, mk(70, 190, 225), mk(40, 110, 150), 255, 1.0f});
  const char *s = m.kbText; int n = (int)strlen(s), st = 0, maxW = K.field.w - 22;
  while (st < n && textWidth(FONT_MD, s + st) > maxW) ++st;
  text(c, FONT_MD, K.field.x + 9, K.field.y + 17, s + st, T_TEXT);
  int cw = textWidth(FONT_MD, s + st);
  fillRect(c, K.field.x + 10 + cw, K.field.y + 5, 2, K.field.h - 10, T_CYAN);
  // keys
  char kb[2] = {0, 0};
  for (int row = 0; row < 4; ++row) {
    const char *keys = kbRows(row, m.kbUpper, m.kbSym);
    int y = K.keyTop + row * K.rowH;
    if (!c.hitsY(y, y + K.rowH)) continue;
    for (int i = 0; i < K.cols; ++i) {
      kb[0] = keys[i];
      uiButton(c, Rect{i * K.kw + 2, y + 1, K.kw - 4, K.rowH - 3}, kb, BTN_NORMAL, FONT_MD);
    }
  }
  uiButton(c, K.mode, m.kbSym ? "ABC" : "123", m.kbSym ? BTN_ACTIVE : BTN_NORMAL);
  uiButton(c, K.shift, "SHIFT", m.kbUpper ? BTN_ACTIVE : BTN_NORMAL);
  uiButton(c, K.space, "SPACE");
  uiButton(c, K.del, "DEL");
  uiButton(c, K.ok, "OK", BTN_PRIMARY);
}

static void pageLocation(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "LOCATION");
  int W = c.W, H = c.H; LocLayout L = locLayout(W, H);
  uiLabel(c, 10, L.name.y + L.name.h / 2, "Name");
  uiLabel(c, 10, L.lat.y + L.lat.h / 2, "Latitude");
  uiLabel(c, 10, L.lon.y + L.lon.h / 2, "Longitude");
  uiButton(c, L.name, m.locName[0] ? m.locName : "Tap to enter", BTN_GHOST);
  uiButton(c, L.lat, m.locLat, BTN_GHOST);
  uiButton(c, L.lon, m.locLon, BTN_GHOST);
  uiButton(c, L.back, "BACK");
  uiButton(c, L.save, "SAVE", BTN_PRIMARY);
  if (m.status && m.status[0]) text(c, FONT_SM, W / 2, L.back.y + 54, m.status, T_ORANGE, AL_CENTER);
  text(c, FONT_XS, W / 2, H - 14, "Example: 32.48  -96.99", T_DIM, AL_CENTER);
}

static void pageMouse(Canvas &c, const UiModel &m) {
  uiBackground(c); uiHeader(c, m, "MOUSE WIGGLER");
  int W = c.W, H = c.H; MouseLayout L = mouseLayout(W, H);
  uiToggle(c, L.toggle, m.mouseEnabled ? "JIGGLER ON" : "JIGGLER OFF", m.mouseEnabled);
  Col bc = m.bleConnected ? T_TEAL : T_MUTED;
  disc(c, L.toggle.x + L.toggle.w + 18, L.toggle.y + 15, 4, bc);
  text(c, FONT_SMB, L.toggle.x + L.toggle.w + 30, L.toggle.y + 20, m.bleConnected ? "BLE connected" : "BLE waiting", bc);
  char b[24];
  uiLabel(c, 10, L.minMinus.y + 14, "Min interval");
  snprintf(b, sizeof(b), "%ds", m.mouseMin); uiStepper(c, L.minMinus, L.minPlus, Rect{L.minPlus.x + L.minPlus.w + 6, L.minPlus.y, 50, 28}, b);
  uiLabel(c, 10, L.maxMinus.y + 14, "Max interval");
  snprintf(b, sizeof(b), "%ds", m.mouseMax); uiStepper(c, L.maxMinus, L.maxPlus, Rect{L.maxPlus.x + L.maxPlus.w + 6, L.maxPlus.y, 50, 28}, b);
  uiLabel(c, 10, L.movMinus.y + 14, "Movement");
  snprintf(b, sizeof(b), "1-%dpx", m.mouseMove); uiStepper(c, L.movMinus, L.movPlus, Rect{L.movPlus.x + L.movPlus.w + 6, L.movPlus.y, 50, 28}, b);
  uiButton(c, L.back, "BACK");
  text(c, FONT_XS, W / 2, H - 8, "BLE name: Aurora Weather Mouse", T_DIM, AL_CENTER);
}

// ----------------------------------------------------------------------------
// Dispatcher
// ----------------------------------------------------------------------------
static void uiDrawPage(Canvas &c, void *ctx) {
  const UiModel &m = *(const UiModel *)ctx;
  switch (m.page) {
    case PAGE_NOW: pageNow(c, m); break;
    case PAGE_HOURLY: pageHourly(c, m); break;
    case PAGE_DAILY: pageDaily(c, m); break;
    case PAGE_SUN: pageSun(c, m); break;
    case PAGE_TIME: pageTime(c, m); break;
    case PAGE_PHOTO: pagePhoto(c, m); break;
    case PAGE_SETTINGS:
      switch (m.sview) {
        case SETTINGS_MAIN: pageSettingsMain(c, m); break;
        case SETTINGS_WIFI_SCANNING: pageWifiScanning(c, m); break;
        case SETTINGS_WIFI_LIST: pageWifiList(c, m); break;
        case SETTINGS_KEYBOARD: case SETTINGS_LOCATION_KEYBOARD: pageKeyboard(c, m); break;
        case SETTINGS_LOCATION: pageLocation(c, m); break;
        case SETTINGS_MOUSE: pageMouse(c, m); break;
      }
      break;
  }
}
static bool uiRenderPage(int W, int H, const UiModel &m) { return auroraRender(W, H, 0, 0, W, H, uiDrawPage, (void *)&m); }
// Re-render only a rectangle (used for the animated weather icon).
static bool uiRenderRegion(int W, int H, const UiModel &m, const Rect &r) { return auroraRender(W, H, r.x, r.y, r.w, r.h, uiDrawPage, (void *)&m); }

// ----------------------------------------------------------------------------
// Stand-alone screens
// ----------------------------------------------------------------------------
struct StatusCtx { const char *title, *l1, *l2, *l3; Col accent; int icon; float phase; };
static void drawStatus(Canvas &c, void *p) {
  const StatusCtx &s = *(const StatusCtx *)p;
  int W = c.W, H = c.H, cy = H / 2;
  gradV(c, 0, 0, W, H, T_BG_TOP, T_BG_BOT);
  glow(c, W * 0.5f, (float)(cy - 40), 8, 110, s.accent, 0.16f);
  spinnerArc(c, W * 0.5f, (float)(cy - 44), 22, s.phase);
  if (s.icon == 1) iconWifi(c, W * 0.5f, (float)(cy - 53), T_TEXT);
  else if (s.icon == 2) iconCheck(c, W * 0.5f, (float)(cy - 44), s.accent);
  text(c, FONT_LG, W / 2, cy + 8, s.title, s.accent, AL_CENTER);
  if (s.l1 && s.l1[0]) textFit(c, FONT_SM, W / 2, cy + 30, s.l1, T_TEXT, W - 24, AL_CENTER);
  if (s.l2 && s.l2[0]) textFit(c, FONT_SM, W / 2, cy + 48, s.l2, T_MUTED, W - 24, AL_CENTER);
  if (s.l3 && s.l3[0]) textFit(c, FONT_SM, W / 2, cy + 66, s.l3, T_MUTED, W - 24, AL_CENTER);
}
// icon: 0 none, 1 wifi, 2 check
static bool uiStatusScreen(int W, int H, const char *title, const char *l1, const char *l2, Col accent, int icon = 0, const char *l3 = "", float phase = 0) {
  StatusCtx s{title, l1, l2, l3, accent, icon, phase};
  return auroraRender(W, H, 0, 0, W, H, drawStatus, &s);
}

struct CalCtx { int x, y, step; const char *label; };
static void drawCal(Canvas &c, void *p) {
  const CalCtx &k = *(const CalCtx *)p;
  int W = c.W, H = c.H;
  gradV(c, 0, 0, W, H, T_BG_TOP, T_BG_BOT);
  text(c, FONT_LG, W / 2, H / 2 - 18, "Touch calibration", T_TEXT, AL_CENTER);
  text(c, FONT_MD, W / 2, H / 2 + 6, k.label, T_CYAN, AL_CENTER);
  text(c, FONT_SM, W / 2, H / 2 + 26, "Press the centre of the target firmly", T_MUTED, AL_CENTER);
  for (int i = 0; i < 4; ++i) {                        // progress dots
    float dx = W / 2 - 27 + i * 18.0f, dy = (float)(H / 2 + 50);
    if (i < k.step) disc(c, dx, dy, 4, T_TEAL);
    else if (i == k.step) { disc(c, dx, dy, 5, T_CYAN); }
    else disc(c, dx, dy, 3.5f, mk(44, 68, 96));
  }
  float x = (float)k.x, y = (float)k.y;
  glow(c, x, y, 4, 30, T_CYAN, 0.30f);
  ring(c, x, y, 13, T_CYAN, 255, 1.6f);
  ring(c, x, y, 6, T_CYAN, 160, 1.2f);
  capsule(c, x - 22, y, x - 8, y, 1.6f, T_CYAN); capsule(c, x + 8, y, x + 22, y, 1.6f, T_CYAN);
  capsule(c, x, y - 22, x, y - 8, 1.6f, T_CYAN); capsule(c, x, y + 8, x, y + 22, 1.6f, T_CYAN);
  disc(c, x, y, 2.2f, T_TEXT);
}
static bool uiCalibrationScreen(int W, int H, int x, int y, int step, const char *label) {
  CalCtx k{x, y, step, label};
  return auroraRender(W, H, 0, 0, W, H, drawCal, &k);
}

// Splash footer (drawn over the bottom of the embedded JPEG) and progress bar.
struct SplashCtx { const char *fw; float prog; bool full; };
static void drawSplashFooter(Canvas &c, void *p) {
  const SplashCtx &s = *(const SplashCtx *)p;
  int W = c.W, H = c.H;
  fillRect(c, 0, H - 36, W, 36, mk(7, 17, 31));
  if (s.full) {
    text(c, FONT_XS, W / 2, H - 17, "AURORA WEATHER", T_TEXT, AL_CENTER, 255, 2);
    char b[40]; snprintf(b, sizeof(b), "Firmware %s", s.fw);
    text(c, FONT_XXS, W / 2, H - 5, b, T_DIM, AL_CENTER);
  }
  int bw = 120, bx = (W - bw) / 2, by = H - 33;
  fillRRect(c, bx, by, bw, 3, 1.5f, mk(26, 46, 74));
  float fw2 = bw * clamp01(s.prog);
  if (fw2 > 1) rrect(c, bx, (float)by, fw2, 3, 1.5f, RStyle{AURORA_L, AURORA_R, 255, AURORA_L, AURORA_R, 0, 0});
}
static bool uiSplashFooter(int W, int H, const char *fw, float prog, bool full) {
  SplashCtx s{fw, prog, full};
  return auroraRender(W, H, 0, H - 36, W, 36, drawSplashFooter, &s);
}

// Only the thin progress bar (cheap enough to animate while the splash is held).
static bool uiSplashProgress(int W, int H, const char *fw, float prog) {
  SplashCtx s{fw, prog, true};
  int bw = 120, bx = (W - bw) / 2, by = H - 33;
  return auroraRender(W, H, bx - 2, by - 2, bw + 4, 7, drawSplashFooter, &s);
}
