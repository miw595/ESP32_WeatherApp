#pragma once
#include <Arduino.h>

// Kept in a header so Arduino's automatic function-prototype generator
// knows this type before it emits prototypes for functions using TouchPoint.
struct TouchPoint {
  bool touched = false;
  int16_t x = 0;
  int16_t y = 0;
  int16_t rawX = 0;
  int16_t rawY = 0;
};
