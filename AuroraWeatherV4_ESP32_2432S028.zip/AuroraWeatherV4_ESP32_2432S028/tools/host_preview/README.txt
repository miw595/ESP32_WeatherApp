Host preview renderer
---------------------
sim.cpp compiles AuroraUI.h / AuroraGfx.h / AuroraIcons.h (the exact drawing code that runs on the
ESP32) on a PC and writes each screen to a PNG with sample weather data. Use it to try colour,
layout or font changes in seconds without flashing the board.   sh build_preview.sh
