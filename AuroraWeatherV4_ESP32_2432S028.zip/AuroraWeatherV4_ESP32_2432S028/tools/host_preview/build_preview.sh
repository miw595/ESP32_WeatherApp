#!/bin/sh
# Renders every V4 screen on your PC using the *same* drawing code the ESP32 runs.
# Needs: g++ and Python 3 with Pillow.   Usage:  sh build_preview.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
SKETCH="$HERE/../.."
OUT="$HERE/out"; mkdir -p "$OUT"
g++ -std=c++17 -O2 -w -I"$SKETCH" "$HERE/sim.cpp" -o "$HERE/sim"
python3 - "$SKETCH" "$HERE" <<'PY'
import sys
from PIL import Image
sk,h=sys.argv[1],sys.argv[2]
im=Image.new("RGB",(320,240),(7,17,31)); j=Image.open(sk+"/aurora_splash.jpg").convert("RGB")
im.paste(j,((320-j.width)//2,max(0,(240-j.height)//2-10))); im.save(h+"/splash_base.ppm")
ph=Image.new("RGB",(320,240),(0,0,0)); ph.paste(j,((320-j.width)//2,(210-j.height)//2)); ph.save(h+"/photo_base.ppm")
PY
"$HERE/sim" "$OUT" "$HERE/splash_base.ppm" "$HERE/photo_base.ppm"
python3 - "$OUT" <<'PY'
import sys,glob
from PIL import Image
for f in glob.glob(sys.argv[1]+"/*.ppm"): Image.open(f).save(f[:-4]+".png")
print("PNG frames written to", sys.argv[1])
PY
