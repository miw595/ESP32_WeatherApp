// Host-side renderer: compiles the real AuroraUI code and dumps PPM frames.
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <vector>
#include <string>
static int FBW = 320, FBH = 240;
static std::vector<uint16_t> fb;
static void flush_block(int x, int y, int w, int h, uint16_t *p) {
  for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) {
    int X = x + i, Y = y + j; if (X < 0 || Y < 0 || X >= FBW || Y >= FBH) continue;
    fb[Y * FBW + X] = p[j * w + i];
  }
}
#define AURORA_FLUSH(x, y, w, h, p) flush_block(x, y, w, h, p)
#include "AuroraUI.h"

static void savePPM(const std::string &path) {
  FILE *f = fopen(path.c_str(), "wb"); fprintf(f, "P6\n%d %d\n255\n", FBW, FBH);
  for (int i = 0; i < FBW * FBH; ++i) { int r, g, b; expand565(fb[i], r, g, b); fputc(r, f); fputc(g, f); fputc(b, f); }
  fclose(f);
}
static void setSize(int w, int h) { FBW = w; FBH = h; fb.assign(w * h, 0); }

static Weather makeWeather(int code, bool day) {
  Weather w; w.valid = true; strcpy(w.updated, "14:05");
  w.temp = 22.2f; w.apparent = 22.0f; w.humidity = 48; w.wind = 12.9f; w.pressure = 1015; w.dewpoint = 11;
  w.precipProb = 10; w.uv = 4.2f; w.code = code; w.windDir = 315; w.isDay = day; w.currentMinuteAtFetch = 14 * 60 + 5;
  w.sunriseMinute = 7 * 60 + 42; w.sunsetMinute = 17 * 60 + 36;
  float tf[24] = {72, 74, 76, 75, 73, 70, 67, 64, 62, 60, 59, 58, 58, 57, 58, 60, 63, 66, 69, 72, 74, 75, 76, 74};
  int rain[24] = {0,0,0,5,5,10,10,15,20,30,35,35,25,20,10,5,0,0,0,0,5,10,10,0};
  for (int i = 0; i < 24; ++i) { w.hourlyTemp[i] = (tf[i] - 32) / 1.8f; w.hourlyHour[i] = (14 + i) % 24; w.hourlyRainProb[i] = rain[i]; w.hourlyCode[i] = 2; }
  const char *dn[7] = {"TODAY", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};
  float mx[7] = {76, 78, 80, 79, 75, 73, 77}, mn[7] = {58, 60, 62, 61, 57, 55, 58};
  int dc[7] = {2, 1, 0, 3, 61, 95, 0}; int dr[7] = {10, 5, 0, 15, 70, 90, 10};
  for (int i = 0; i < 7; ++i) { strcpy(w.dayName[i], dn[i]); w.dayMax[i] = (mx[i] - 32) / 1.8f; w.dayMin[i] = (mn[i] - 32) / 1.8f; w.dayCode[i] = dc[i]; w.dayRain[i] = dr[i]; w.dayUv[i] = 5;
    strcpy(w.sunrise[i], "07:42"); strcpy(w.sunset[i], "17:36"); }
  return w;
}

static const char SS[10][33] = {"Home_n300", "ORBI07", "ATTt2nM2VS", "xfinitywifi", "NETGEAR-5G-Guest", "Linksys_2.4G", "", "", "", ""};
static const int RS[10] = {-52, -66, -78, -88, -91, -84, 0, 0, 0, 0};

static UiModel baseModel(const Weather *w) {
  UiModel m; m.wx = w; m.wifiOn = true; m.location = "Midlothian, TX"; m.timeValid = true;
  m.tm.tm_hour = 14; m.tm.tm_min = 24; m.tm.tm_mday = 2; m.tm.tm_mon = 10; m.tm.tm_year = 126; m.tm.tm_wday = 1;
  m.tzAbbr = "CST"; m.tzName = "America/Chicago"; m.nowMinute = 14 * 60 + 24; m.sdReady = true; m.photoCount = 12;
  m.scanCount = 6; m.ssids = SS; m.rssi = RS; m.fw = "4.1.0"; m.phase = 0; return m;
}

int main(int argc, char **argv) {
  std::string out = argc > 1 ? argv[1] : "out";
  Weather wDay = makeWeather(2, true), wNight = makeWeather(0, false), wRain = makeWeather(63, true), wStorm = makeWeather(95, true), wSnow = makeWeather(73, true), wFog = makeWeather(45, true);
  wNight.isDay = 0;
  struct Job { const char *name; int w, h; };
  auto page = [&](const char *name, UiModel m, int W = 320, int H = 240) { setSize(W, H); uiRenderPage(W, H, m); savePPM(out + "/" + name + ".ppm"); };

  UiModel m = baseModel(&wDay);
  m.page = PAGE_NOW; page("01_now", m);
  m.wx = &wNight; m.nowMinute = 21 * 60; m.page = PAGE_NOW; page("01b_now_night", m);
  m.wx = &wRain; page("01c_now_rain", m);
  m.wx = &wStorm; page("01d_now_storm", m);
  m.wx = &wSnow; page("01e_now_snow", m);
  m.wx = &wFog; page("01f_now_fog", m);
  m = baseModel(&wDay);
  m.page = PAGE_HOURLY; page("02_24h", m);
  m.page = PAGE_DAILY; page("03_7day", m);
  m.page = PAGE_SUN; page("04_sun", m);
  m.nowMinute = 21 * 60; page("04b_sun_night", m); m.nowMinute = 14 * 60 + 24;
  m.page = PAGE_TIME; page("05_time", m);
  m.timeValid = false; page("05b_time_sync", m); m.timeValid = true;
  m.page = PAGE_PHOTO; page("06_photos_info_nocard", [&]{ UiModel q = m; q.sdReady = false; q.photoCount = 0; return q; }());
  page("06b_photos_info_failed", [&]{ UiModel q = m; q.photoFailed = true; return q; }());
  m.page = PAGE_PHOTO; page("06_photos", m);
  m.page = PAGE_SETTINGS; m.sview = SETTINGS_MAIN; page("07_settings", m);
  m.sview = SETTINGS_WIFI_SCANNING; page("08_wifi_scan", m);
  m.sview = SETTINGS_WIFI_LIST; page("09_wifi_list", m);
  m.sview = SETTINGS_LOCATION; m.locName = "Midlothian, TX"; m.locLat = "32.48290"; m.locLon = "-96.99440"; page("10_location", m);
  m.sview = SETTINGS_KEYBOARD; m.kbTitle = "WI-FI PASSWORD"; m.kbSub = "Network: Home_n300"; m.kbText = "example-password"; page("11_keyboard", m);
  m.sview = SETTINGS_MOUSE; page("12_mouse", m);

  // portrait variants
  UiModel p = baseModel(&wDay);
  p.page = PAGE_NOW; page("20_p_now", p, 240, 320);
  p.page = PAGE_HOURLY; page("21_p_24h", p, 240, 320);
  p.page = PAGE_DAILY; page("22_p_7day", p, 240, 320);
  p.page = PAGE_SUN; page("23_p_sun", p, 240, 320);
  p.page = PAGE_TIME; page("24_p_time", p, 240, 320);
  p.page = PAGE_SETTINGS; p.sview = SETTINGS_MAIN; page("25_p_settings", p, 240, 320);
  p.sview = SETTINGS_KEYBOARD; p.kbTitle = "WI-FI PASSWORD"; p.kbSub = "Network: Home_n300"; p.kbText = "example-password"; page("26_p_keyboard", p, 240, 320);

  // stand-alone screens
  setSize(320, 240); uiStatusScreen(320, 240, "WI-FI CONNECTED", "Home_n300", "192.168.1.42", T_TEAL, 2, "Loading weather..."); savePPM(out + "/30_status_connected.ppm");
  setSize(320, 240); uiStatusScreen(320, 240, "CONNECTING WI-FI", "Home_n300", "", T_CYAN, 1); savePPM(out + "/31_status_connecting.ppm");
  setSize(320, 240); uiCalibrationScreen(320, 240, 28, 28, 0, "Touch TOP LEFT"); savePPM(out + "/32_calibration.ppm");

  // photo tab: JPEG region comes from python (argv[3]); only the nav bar is composed by the UI
  if (argc > 3) { FILE *f = fopen(argv[3], "rb"); if (f) { int w, h, mx; if (fscanf(f, "P6 %d %d %d", &w, &h, &mx) == 3) { fgetc(f); setSize(w, h);
      for (int i = 0; i < w * h; ++i) { int r = fgetc(f), g = fgetc(f), b = fgetc(f); fb[i] = to565(mk(r, g, b)); }
      UiModel q = baseModel(&wDay); q.page = PAGE_PHOTO; uiRenderRegion(w, h, q, Rect{0, uiNavTop(h), w, UI_NAV_H}); savePPM(out + "/06c_photo_tab.ppm"); } fclose(f); } }
  // animation frames (NOW page at different clock values)
  { UiModel a = baseModel(&wDay); a.page = PAGE_NOW; float ts[3] = {0.0f, 1.3f, 2.9f};
    const Weather *ws[4] = {&wDay, &wRain, &wSnow, &wStorm};
    for (int k = 0; k < 4; ++k) for (int j = 0; j < 3; ++j) { a.wx = ws[k]; a.phase = ts[j]; char nm[64]; snprintf(nm, sizeof(nm), "50_anim_%d_%d", k, j); page(nm, a); } }
  // icon gallery
  { setSize(320, 240);
    struct G { int code; bool day; } gal[] = {{0,1},{0,0},{1,1},{2,1},{2,0},{3,1},{45,1},{53,1},{63,1},{81,1},{73,1},{95,1}};
    struct Ctx { G *g; int n; } ctx{gal, 12};
    auto fn = [](Canvas &c, void *p) { Ctx *x = (Ctx *)p; gradV(c, 0, 0, c.W, c.H, T_BG_TOP, T_BG_BOT);
      for (int i = 0; i < x->n; ++i) { int cx = 40 + (i % 4) * 80, cy = 40 + (i / 4) * 78; fillRRect(c, cx - 36, cy - 36, 72, 72, 10, mk(22, 42, 68)); weatherIcon(c, x->g[i].code, x->g[i].day, cx, cy, 60, 0.0f); } };
    auroraRender(320, 240, 0, 0, 320, 240, fn, &ctx); savePPM(out + "/40_icon_gallery.ppm"); }
  // splash footer: base image comes from python
  if (argc > 2) { FILE *f = fopen(argv[2], "rb"); if (f) { int w, h, mx; if (fscanf(f, "P6 %d %d %d", &w, &h, &mx) == 3) { fgetc(f); setSize(w, h);
      for (int i = 0; i < w * h; ++i) { int r = fgetc(f), g = fgetc(f), b = fgetc(f); fb[i] = to565(mk(r, g, b)); }
      uiSplashFooter(w, h, "4.1.0", 0.65f, true); savePPM(out + "/00_splash.ppm"); } fclose(f); } }
  printf("done\n"); return 0;
}
