# Aurora Weather V4.2.1 - ESP32-2432S028 / "CYD" 2.8" 320x240

V4 is a **graphics and UX release** of V3.18.x. Everything hardware-critical from V3 is carried over
untouched (software-SPI TFT and touch, clean-boot Wi-Fi flow, BLE coexistence, the low-memory
streaming weather parser, I/O recovery, per-rotation touch calibration). What changed is how the
screen is drawn and what it looks like. See `preview/CONTACT_SHEET_V4.png` and `preview/BEFORE_AFTER.png`.

## V4.2.0 - NimBLE Bluetooth stack
The Bluetooth mouse now runs on **NimBLE** instead of the ESP32 core's Bluedroid BLE, which uses roughly 100 KB less RAM. In V4.1.2 the
mouse left only ~4.5 KB free; this is what lets weather (HTTPS), SD and the mouse coexist.

**Install first:** Arduino IDE -> Library Manager -> **NimBLE-Arduino** by h2zero, version **2.x** (written against 2.5.2).

**Re-pair once.** The old pairing keys were stored by the other stack and cannot be reused. On the computer: remove/forget
"Aurora Weather Mouse" in Bluetooth settings, then turn the jiggler on and pair again. If it still refuses to connect, erase the
board's flash once (Arduino IDE: Tools -> Erase All Flash Before Sketch Upload -> Enabled; this also clears Wi-Fi/location, so re-enter them).

**HID report fix.** The old wrapper put the Report ID inside the notification payload; for HID-over-GATT the ID belongs to the
descriptor, so hosts could read the first byte as "left button held" and shift the axes. The payload is now the 4-byte report body
(buttons, x, y, wheel). If your jiggler previously made odd clicks or only moved vertically, that is the reason.

**Not verified on hardware.** I compiled the wrapper against stubs built from the NimBLE 2.5.2 headers and checked the API calls
against its source, but have not run it on a board. Please send the Serial log lines `BLE mouse: HID started; heap after=... largest=...`.
Optional: in the NimBLE library folder, `src/nimconfig.h`, uncomment and set `CONFIG_BT_NIMBLE_MAX_CONNECTIONS 1` to save a little more RAM.

The V4.1.2 memory guards (below) are kept as a safety net; RESCAN SD is now blocked only if free memory is genuinely low.

## V4.1.2 - memory safety with the Bluetooth mouse
A field log showed the real constraint: starting the BLE mouse (Bluedroid + Wi-Fi coexistence) takes ~120 KB, leaving **~4.5 KB of free heap**
(127,020 -> 4,508 bytes). That is why the SD card used to "disappear" (mounting needs several KB) and why a second RESCAN SD crashed
(`abort()` - on this core a failed allocation reboots the board). V4.1.2 makes every path memory-aware:
- Renderer band size is capped to 1/3 of the largest free block, so drawing keeps working (and stays pixel-identical) down to ~2 KB.
- SD (re)mount, `/photos` rescan and the photo tab never allocate when too little memory is free; the mount made *before* BLE starts is kept.
- **RESCAN SD while the mouse is on** shows "Mouse on: restart to rescan" instead of crashing.
- **Weather refresh is skipped while the mouse is on** if there is not enough memory for HTTPS (needs ~24 KB; logged on Serial). Weather already
  loaded keeps showing, but it will not update until the mouse is turned off.
- **Turning the mouse OFF restarts the board** (the BLE stack cannot be released safely at run time), which returns the memory.
- Fixed a latent drawing bug found by rendering in tiny bands: the header's glow line could vanish depending on band boundaries.

Thresholds live at the top of the sketch (`SD_MIN_BLOCK_BLE`, `SCAN_MIN_BLOCK`, `WEATHER_MIN_BLOCK`).
The structural fix for "mouse + weather + SD at the same time" was a lighter BLE stack - done in V4.2.0 above.

## V4.1.1 - SD card vs. the Bluetooth mouse
With the mouse on, the SD card could go "missing". BLE takes ~100 KB of heap, its radio bursts load the CYD's weak 3.3 V
rail, and every SD access used to *tear down* a working mount and remount it from scratch (20 MHz first). Now:
- A healthy mount is **never torn down**. SET -> RESCAN SD (and the PIC tab) just re-read `/photos`.
- The card is **mounted before BLE starts**, while heap is plentiful and the radio is quiet.
- If a fresh mount is needed while BLE is running it starts at 10 MHz and falls back 4 MHz -> 1 MHz -> 400 kHz, with longer settling delays.
- The photo tab checks the mount before each photo and remounts once if the card was lost.
- Serial now logs heap and the largest free block at each mount, e.g. `SD: mounting; BLE=1 heap=... largest=...`.

If it still fails with the mouse on, it is most likely **power**: use a good 5 V / 1 A+ supply and cable, lower the backlight
a little, and try a 100 uF capacitor across 3V3-GND near the SD slot. Some cheap cards also tolerate only low clocks.
Send me the Serial lines starting with `SD` if it persists.

## V4.1 - photo tab in the page cycle
The old slideshow only ran while you sat on the PIC page (and the SD card was not even mounted until you
visited it), so it effectively never started. In V4.1 the **PIC tab is a normal page of the auto-cycle**:

    NOW -> 24H -> 7D -> SUN -> TIME -> PIC -> NOW ...      (15 s per tab, same as every other page)

- Every time the cycle lands on PIC it shows the **next photo, in alphabetical order**, wrapping around.
- **SET -> "Photo tab in cycle"** switches PIC in or out of the rotation. (You can still tap the PIC tab by hand.)
- The photo fills the screen above the nav bar, so the tab bar stays visible and tappable. **Tap the photo to skip to the next one.**
- The SD card is mounted the first time the cycle is about to reach PIC (boot stays SD-free, as in V3.8).
  If no card is found the tab is skipped and the mount is retried every 5 minutes; SET -> RESCAN SD retries immediately.
- Unreadable photos are skipped and logged on Serial (`Photo: ...`). If none can be displayed, PIC leaves the cycle.
  The decoder can shrink by 8x at most, so photos larger than about 2500x1900 are skipped (resize them to ~1280x960 or smaller).
  A 320x240 photo is placed at the top and the 30 px nav bar covers its bottom edge; smaller photos are centred above the bar.
- Removed: the interval / duration / shuffle settings and the full-screen "SHOW PHOTO" mode. Old saved values are ignored harmlessly.

## What's new in V4

**Rendering**
- **Band compositor** (`AuroraGfx.h`). Each page is composed in a ~12 KB RAM band and pushed to the LCD once.
  No `fillScreen()` + overdraw, so page changes no longer flash, and still no full framebuffer
  (the board has no PSRAM). The band shrinks automatically if heap is tight.
- **Anti-aliased text** (`AuroraFonts.h`): Inter in 7 sizes/weights, 4-bit alpha, ~57 KB of flash.
- **Dithered gradients**: ordered dithering removes the banding RGB565 normally shows on dark gradients.
- **Vector weather icons** (`AuroraIcons.h`): sun, crescent moon, clouds, rain, snow, fog, thunder -
  drawn from signed-distance shapes, anti-aliased, resolution independent. Weather-code coverage is
  finer than V3 (mostly clear / partly cloudy / overcast / drizzle / showers / freezing rain / hail ...).
- **Animated NOW icon**: rays turn, clouds drift, rain and snow fall. Only the ~108x110 px icon area
  is re-composed (about 8 fps). Disable with `#define AURORA_ANIMATE_ICONS 0`.

**Pages**
- **NOW**: condition-tinted hero card (clear/cloud/rain/snow/storm/night), big temperature with unit, feels-like and today's H/L,
  five metric tiles (humidity ring, wind arrow that points downwind, pressure, colour-coded UV, rain %).
- **24H**: smooth Catmull-Rom curve with gradient area, "nice" axis ticks, temperature-coloured line,
  NOW / high / low markers, time labels on real clock hours, per-hour rain-chance bars.
- **7-DAY**: icon, rain %, and a temperature range bar scaled across the whole week with a "now" marker on today.
- **SUN**: gradient sun path with live sun/moon position, countdown to sunset/sunrise, daylight length, dome glow.
- **TIME**: gradient clock, day/date, zone, and a 24 h daylight bar with a now marker.
- **Settings**: segmented rotation control, toggle switches, steppers, slider with knob glow.
- Wi-Fi list shows signal-strength bars; keyboard keys are larger and styled; calibration, status and splash screens redesigned.
- **Portrait** (rotation 0/180) has its own layouts instead of stretched landscape ones.

**Code and behaviour fixes**
- Touch hit-boxes and drawing now share one layout (`AuroraUI.h`). In V3 the bottom Settings row overlapped the nav bar
  and the nav hit-zone (25 px) did not match the drawn bar (27 px).
- The nav bar only reacts where it is visible; sub-screens use their BACK buttons (V3 let taps near the bottom edge
  hit invisible tabs from the keyboard/Wi-Fi list).
- A JPEG that fails to decode is skipped and logged instead of leaving a black screen or retrying every loop pass.
- Photos are sorted alphabetically and macOS `._*.jpg` files are ignored.
- Weather model uses fixed `char[]` fields instead of `String` (less heap fragmentation); UI drawing performs no heap allocation except one transient band buffer.
- Perceptual (gamma 1.6) backlight curve so the brightness slider feels even; 100 % is still full duty.
- Status messages in the header clear themselves after a few seconds.
- Fixed a stray literal `\n` in the mouse-jiggle serial log; explicit forward declarations so the sketch no longer depends on the IDE auto-prototyper.
- Splash holds 3 s with a thin aurora progress bar instead of a blank `delay(3000)`.

## Upgrading from V3
Settings (Wi-Fi, location, calibration, photo and mouse options) are kept: the NVS namespace is unchanged.
The sketch folder is renamed `AuroraWeatherV4_ESP32_2432S028` - Arduino requires the folder and main `.ino` to match, so open the V4 folder.

## Target hardware
ESP32-WROOM-32 (4 MB, no PSRAM) / ILI9341 240x320 / XPT2046 touch (software SPI) / microSD / PWM backlight GPIO21.

| LCD | Touch | SD |
|---|---|---|
| MISO 12, MOSI 13, CLK 14, CS 15, DC 2, BL 21 | CLK 25, MOSI 32, MISO 39, CS 33, IRQ 36 | CLK 18, MISO 19, MOSI 23, CS 5 |

## Arduino IDE setup
- Board: ESP32 Dev Module, ESP32 core 3.x, Flash 4 MB, Partition Default 4 MB, upload 460800/921600.
- Libraries: GFX Library for Arduino, ArduinoJson 7.x, JPEGDEC, **NimBLE-Arduino 2.x** (see `LIBRARIES.txt`).
- First boot runs a 4-point touch calibration, then **SET -> WI-FI** to pick a network and enter the password.

## Files
| File | Purpose |
|---|---|
| `AuroraWeatherV4_ESP32_2432S028.ino` | Application: hardware, Wi-Fi, weather, SD, BLE, touch, loop |
| `AuroraUI.h` | Theme, layout (shared with touch) and every page |
| `AuroraGfx.h` | Band compositor, AA shapes, gradients, text engine |
| `AuroraIcons.h` | Weather and UI vector icons |
| `AuroraFonts.h` | Generated Inter bitmap fonts (`tools/gen_fonts.py`) |
| `AuroraTypes.h` | Weather struct, enums, `UiModel` |
| `TouchTypes.h`, `AuroraBleMouse.h`, `AuroraSplash.h` | Unchanged from V3 |
| `tools/host_preview/` | Render all screens on a PC with the real UI code |
| `preview/` | Renders of every screen |

## Tuning
- Colours: the `T_*` constants at the top of `AuroraUI.h`.
- Fonts/sizes: edit the table in `tools/gen_fonts.py`, run it, replace `AuroraFonts.h`.
- Band size (RAM vs speed): `AURORA_BAND_BYTES` (default 12288).
- Preview a change without flashing: `sh tools/host_preview/build_preview.sh`.

## Notes and limits
- The previews are produced by compiling the real UI code on a PC. The full sketch was type-checked against stub headers, but
  **has not been run on real hardware** - please report anything that looks different on your panel
  (colour inversion, SPI speed, animation smoothness).
- Colour handling is unchanged: the panel is driven with `invertDisplay(true)` as in V3, and the renderer writes native RGB565 through the same
  path as the V3 fills.
- The animation runs only on the NOW page when idle. If you ever see touch lag on your unit, set `AURORA_ANIMATE_ICONS` to 0.

## Troubleshooting
Same as V3: blank display -> verify the board is the ILI9341/XPT2046 variant; touch offset -> SET -> CALIBRATE TOUCH; SD not detected ->
FAT32 + `/photos`, then SET -> RESCAN SD; wrong JPEG colours -> see `showJpeg()`.

Fonts: Inter (SIL OFL 1.1, `tools/Inter-OFL.txt`).
