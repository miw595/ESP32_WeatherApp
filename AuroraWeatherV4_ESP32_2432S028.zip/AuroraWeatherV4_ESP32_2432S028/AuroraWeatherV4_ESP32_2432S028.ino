/*
 * Aurora Weather V4.2.1 - ESP32-2432S028 / TPM408 2.8" Touch
 *
 * V4 is a graphics/UX release of V3.18.x.  All of the hard-won hardware
 * behaviour (software-SPI TFT + touch, clean-boot Wi-Fi flow, BLE coexistence,
 * low-memory weather parser, I/O recovery) is carried over unchanged.  What is
 * new is how the screen is produced and what it looks like:
 *
 *   - Band compositing renderer (AuroraGfx.h): every page is composed in a small
 *     RAM band and pushed to the LCD once -> no flashing, no overdraw.
 *   - Anti-aliased Inter fonts (AuroraFonts.h), dithered gradients (no RGB565
 *     banding), SDF vector weather icons, smooth 24 h chart, range bars.
 *   - Layout shared by drawing and touch code (AuroraUI.h) - what you see is
 *     what you can tap; Settings no longer collides with the nav bar.
 *   - Fixed-size char buffers instead of heap Strings in the weather model.
 *   - V4.1: the PIC tab is part of the normal page cycle. Each time the cycle lands
 *     on it, the next photo (alphabetical order) is shown for the same dwell time
 *     as every other tab. Settings > "Photo tab" decides whether PIC is in the cycle.
 *
 * Target hardware (common ESP32-2432S028R / CYD 2.8):
 *   ESP32-WROOM-32, 4 MB flash, no PSRAM
 *   ILI9341 240x320 TFT
 *   XPT2046 resistive touch (software SPI in this sketch)
 *   microSD card
 *   PWM backlight on GPIO21
 *
 * Required Arduino libraries:
 *   - GFX Library for Arduino (moononournation)
 *   - ArduinoJson (Benoit Blanchon) 7.x
 *   - JPEGDEC (Larry Bank / bitbank2)
 *
 * ESP32 Arduino core: 3.x recommended.
 * Board selection: "ESP32 Dev Module", Flash 4 MB, Default 4 MB partition scheme.
 *
 * IMPORTANT:
 *   CYD/ESP32-2432S028 variants exist. This package targets the common ILI9341 +
 *   XPT2046 wiring listed below. If the display is blank or touch axes are wrong,
 *   verify your PCB.
 */

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <Arduino_GFX_Library.h>
#include <SPI.h>
#include <SD.h>
#include <JPEGDEC.h>
#include "AuroraBleMouse.h"
#include <math.h>
#include <esp_system.h>
#include <time.h>
#include "TouchTypes.h"
#include "AuroraTypes.h"
#include "AuroraSplash.h"

// -----------------------------------------------------------------------------
// Board pin map - common ESP32-2432S028R / 2.8" CYD
// -----------------------------------------------------------------------------

// ILI9341 display (HSPI-style wiring)
static constexpr int TFT_MISO = 12;
static constexpr int TFT_MOSI = 13;
static constexpr int TFT_SCLK = 14;
static constexpr int TFT_CS   = 15;
static constexpr int TFT_DC   = 2;
static constexpr int TFT_RST  = GFX_NOT_DEFINED; // normally tied to board reset
static constexpr int TFT_BL   = 21;

// XPT2046 touch - separate pins, driven with software SPI here so the SD card
// can keep the ESP32's second hardware SPI peripheral.
static constexpr int TOUCH_CLK  = 25;
static constexpr int TOUCH_MOSI = 32;
static constexpr int TOUCH_MISO = 39; // input only
static constexpr int TOUCH_CS   = 33;
static constexpr int TOUCH_IRQ  = 36; // input only, active LOW

// microSD card - VSPI-style wiring
static constexpr int SD_SCLK = 18;
static constexpr int SD_MISO = 19;
static constexpr int SD_MOSI = 23;
static constexpr int SD_CS   = 5;

// -----------------------------------------------------------------------------
// Display and storage objects
// -----------------------------------------------------------------------------

// V3.11: Use software SPI for the TFT. On this ESP32-WROOM board the
// hardware-SPI display bus consistently stopped accepting the first graphics
// write immediately after Wi-Fi.scanNetworks(). Bit-banged SPI keeps the TFT
// completely independent of the ESP32 hardware SPI controllers.
Arduino_DataBus *displayBus = new Arduino_SWSPI(
  TFT_DC, TFT_CS, TFT_SCLK, TFT_MOSI, TFT_MISO);
Arduino_GFX *gfx = new Arduino_ILI9341(displayBus, TFT_RST, 1, false);
SPIClass sdSPI(VSPI);
Preferences prefs;

// Aurora V4 renderer. AURORA_FLUSH pushes one composed band to the panel; the
// UI headers are hardware independent and are included after `gfx` exists.
#define AURORA_FLUSH(x, y, w, h, p) gfx->draw16bitRGBBitmap((x), (y), (p), (w), (h))
#define AURORA_MAX_ALLOC() ((size_t)ESP.getMaxAllocHeap())
#include "AuroraUI.h"

// Forward declarations
void setBrightness(uint8_t pct);
void savePendingWiFiScanForReboot();

// -----------------------------------------------------------------------------
// Configuration defaults
// -----------------------------------------------------------------------------

static constexpr char APP_NAMESPACE[] = "aurora3";
static constexpr char FW_VERSION[] = "4.2.1";
static constexpr float DEFAULT_LAT = 32.4829f;
static constexpr float DEFAULT_LON = -96.9944f;
static constexpr char DEFAULT_LOCATION[] = "Midlothian, TX";
static constexpr uint8_t DEFAULT_ROTATION = 1;  // landscape 320x240
static constexpr uint8_t DEFAULT_BRIGHTNESS = 65;
static constexpr uint16_t DEFAULT_PHOTO_INTERVAL_MIN = 10;
static constexpr uint16_t DEFAULT_PHOTO_DURATION_SEC = 20;
static constexpr bool DEFAULT_PHOTO_ENABLED = true;
static constexpr bool DEFAULT_MOUSE_ENABLED = false;
static constexpr uint16_t DEFAULT_MOUSE_MIN_SEC = 10;
static constexpr uint16_t DEFAULT_MOUSE_MAX_SEC = 120;
static constexpr uint8_t DEFAULT_MOUSE_MOVE_MAX = 3;
static constexpr uint32_t WEATHER_REFRESH_MS = 15UL * 60UL * 1000UL;
static constexpr uint32_t WEATHER_RETRY_MS = 60UL * 1000UL;
static constexpr uint32_t WEATHER_PAGE_CYCLE_MS = 15UL * 1000UL;
static constexpr uint32_t WIFI_RETRY_MS = 30UL * 1000UL;

// The NOW page icon (sun rays, drifting clouds, falling rain/snow) animates by
// re-rendering only the ~108x110 px icon area ~8 times a second. Set to 0 for a
// completely static display.
#ifndef AURORA_ANIMATE_ICONS
#define AURORA_ANIMATE_ICONS 1
#endif
static constexpr uint32_t ICON_ANIM_MS = 120;

// Memory budget. V4.2 uses NimBLE (about 100 KB lighter than the stock Bluedroid BLE
// stack, which left only ~4.5 KB free). These guards stay as a safety net. Anything that allocates must check first,
// because a failed allocation on this core is an abort() (reboot), not an error.
static constexpr uint32_t SD_MIN_BLOCK_BLE   = 12288;   // largest free block needed to (re)mount while BLE runs
static constexpr uint32_t SCAN_MIN_BLOCK     = 6144;    // directory scan needs file handles + Strings
static constexpr uint32_t WEATHER_MIN_BLOCK  = 24576;   // HTTPS/TLS cannot start below this

String wifiSsid;
String wifiPass;
String locationName = DEFAULT_LOCATION;
float latitude = DEFAULT_LAT;
float longitude = DEFAULT_LON;
String timezoneName;
String timezoneAbbr;
int32_t timezoneOffsetSec = 0;
bool timeSyncConfigured = false;
uint32_t timezoneResolveNotBefore = 0;
static constexpr uint32_t TIMEZONE_RETRY_MS = 60000UL;
int lastClockMinute = -1;
bool fahrenheit = true;
bool mph = true;
uint8_t displayRotation = DEFAULT_ROTATION;
uint8_t brightness = DEFAULT_BRIGHTNESS;
bool photoEnabled = DEFAULT_PHOTO_ENABLED;
// V4.1: the PIC tab is part of the normal page cycle, so the three values below
// (interval/duration/shuffle) are legacy. They are still stored so older saved
// settings and downgrades keep working, but nothing reads them any more.
uint16_t photoIntervalMin = DEFAULT_PHOTO_INTERVAL_MIN;
uint16_t photoDurationSec = DEFAULT_PHOTO_DURATION_SEC;
bool photoShuffle = true;
bool mouseEnabled = DEFAULT_MOUSE_ENABLED;
uint16_t mouseMinSec = DEFAULT_MOUSE_MIN_SEC;
uint16_t mouseMaxSec = DEFAULT_MOUSE_MAX_SEC;
uint8_t mouseMoveMax = DEFAULT_MOUSE_MOVE_MAX;
uint32_t nextMouseMoveMs = 0;
bool bleStartPending = false;
uint32_t bleStartNotBefore = 0;
// BLE can briefly drop the ESP32 STA association when the controller starts.
// V3.18.0 restores Wi-Fi after BLE is running without cycling the radio OFF.
bool bleWifiRestorePending = false;
bool bleWifiRestoreInProgress = false;
uint32_t bleWifiRestoreNotBefore = 0;
uint32_t bleWifiRestoreStarted = 0;
uint32_t bleWifiLastCheck = 0;
AuroraBleMouse bleMouse("Aurora Weather Mouse", "Aurora", 100);

// V3.16.2: defer the first HTTPS weather request after credential-driven
// Wi-Fi connection so the LCD can show a stable connected/status screen first.
bool weatherFetchPending = false;
uint32_t weatherFetchNotBefore = 0;
uint32_t weatherRetryNotBefore = 0;
// Cached connection state for UI rendering. Never query the Wi-Fi driver from
// draw functions; on this CYD/Arduino-ESP32 combination that can stall immediately
// after the TFT has been cleared, leaving an apparently blank screen.
bool wifiConnectedCached = false;

// -----------------------------------------------------------------------------
// Palette (the full V4 theme lives in AuroraUI.h; only the splash/clear colour
// is needed here)
// -----------------------------------------------------------------------------

static inline uint16_t C(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}
const uint16_t BG0 = C(7, 17, 31);          // #07111F - splash/JPEG margin colour

// -----------------------------------------------------------------------------
// Touch calibration
// -----------------------------------------------------------------------------

struct TouchCalibration {
  bool valid = false;
  // Affine transform from raw XPT2046 coordinates to screen pixels:
  // screenX = ax*rawX + bx*rawY + cx
  // screenY = ay*rawX + by*rawY + cy
  float ax = 0.0f, bx = 0.0f, cx = 0.0f;
  float ay = 0.0f, by = 0.0f, cy = 0.0f;
};
TouchCalibration touchCal;

// Slow software SPI is deliberate: XPT2046 is reliable well below 2 MHz.
static inline void touchClockPulse() {
  digitalWrite(TOUCH_CLK, HIGH);
  delayMicroseconds(1);
  digitalWrite(TOUCH_CLK, LOW);
  delayMicroseconds(1);
}

uint16_t touchTransfer12(uint8_t command) {
  for (int i = 7; i >= 0; --i) {
    digitalWrite(TOUCH_MOSI, (command >> i) & 1);
    touchClockPulse();
  }
  uint16_t v = 0;
  for (int i = 0; i < 16; ++i) {
    digitalWrite(TOUCH_CLK, HIGH);
    delayMicroseconds(1);
    v = (v << 1) | (digitalRead(TOUCH_MISO) ? 1 : 0);
    digitalWrite(TOUCH_CLK, LOW);
    delayMicroseconds(1);
  }
  return (v >> 3) & 0x0FFF;
}

static void sortTouchSamples(uint16_t *v, int n) {
  for (int i=1;i<n;i++) {
    uint16_t x=v[i]; int j=i-1;
    while (j>=0 && v[j]>x) { v[j+1]=v[j]; --j; }
    v[j+1]=x;
  }
}

bool readTouchRaw(int16_t &rx, int16_t &ry) {
  if (digitalRead(TOUCH_IRQ) != LOW) return false;

  // Median-filtered sampling makes the resistive panel much less jumpy.
  // Nine samples are collected and the middle five are averaged, rejecting
  // the two highest and two lowest readings on each axis.
  constexpr int N = 9;
  uint16_t xs[N], ys[N];
  digitalWrite(TOUCH_CS, LOW);
  delayMicroseconds(2);
  // Discard one conversion after CS assertion to let the ADC settle.
  (void)touchTransfer12(0xD0);
  (void)touchTransfer12(0x90);
  for (int i=0;i<N;i++) {
    xs[i]=touchTransfer12(0xD0);
    ys[i]=touchTransfer12(0x90);
  }
  digitalWrite(TOUCH_CS, HIGH);

  sortTouchSamples(xs,N); sortTouchSamples(ys,N);
  uint32_t sx=0, sy=0;
  for (int i=2;i<=6;i++) { sx+=xs[i]; sy+=ys[i]; }
  rx = sx/5; ry = sy/5;
  return true;
}

TouchPoint readTouch() {
  TouchPoint p;
  int16_t rx, ry;
  if (!readTouchRaw(rx, ry) || !touchCal.valid) return p;
  p.rawX = rx; p.rawY = ry;

  float fx = touchCal.ax*rx + touchCal.bx*ry + touchCal.cx;
  float fy = touchCal.ay*rx + touchCal.by*ry + touchCal.cy;
  p.x = constrain((int)lroundf(fx), 0, gfx->width()-1);
  p.y = constrain((int)lroundf(fy), 0, gfx->height()-1);
  p.touched = true;
  return p;
}

void waitTouchRelease() {
  uint32_t timeout = millis() + 1500;
  while (digitalRead(TOUCH_IRQ) == LOW && millis() < timeout) delay(10);
  // Small release debounce prevents one press becoming two keys.
  delay(35);
}

// V3.16.7: restore both independent software-SPI interfaces after Wi-Fi/TLS.
// On this CYD variant the ESP32 remains alive, but display writes can disappear
// and XPT2046 MISO can read all zeroes after network activity. Reasserting the
// GPIO directions/idles and reinitializing the ILI9341 restores both devices.
void recoverDisplayAndTouch(const char *reason) {
  Serial.printf("I/O recovery: %s; heap=%u\n", reason, ESP.getFreeHeap());

  // Put XPT2046 software-SPI pins back into a known idle state first.
  pinMode(TOUCH_CLK, OUTPUT);
  pinMode(TOUCH_MOSI, OUTPUT);
  pinMode(TOUCH_MISO, INPUT);
  pinMode(TOUCH_CS, OUTPUT);
  pinMode(TOUCH_IRQ, INPUT);
  digitalWrite(TOUCH_CS, HIGH);
  digitalWrite(TOUCH_CLK, LOW);
  digitalWrite(TOUCH_MOSI, LOW);
  delayMicroseconds(25);

  // Reinitialize the software-SPI TFT bus/controller. This was the operation
  // that reliably restored visible output in V3.16.4.
  gfx->begin(40000000);
  gfx->setRotation(displayRotation);
  gfx->invertDisplay(true); // V3.17.9: this CYD/ILI9341 panel requires inversion ON for correct colors

  // Reassert touch pins again in case TFT initialization changed GPIO state,
  // then clock two harmless power-down conversions through the XPT2046.
  pinMode(TOUCH_CLK, OUTPUT);
  pinMode(TOUCH_MOSI, OUTPUT);
  pinMode(TOUCH_MISO, INPUT);
  pinMode(TOUCH_CS, OUTPUT);
  pinMode(TOUCH_IRQ, INPUT);
  digitalWrite(TOUCH_CS, HIGH);
  digitalWrite(TOUCH_CLK, LOW);
  digitalWrite(TOUCH_MOSI, LOW);
  delayMicroseconds(25);
  digitalWrite(TOUCH_CS, LOW);
  delayMicroseconds(2);
  (void)touchTransfer12(0xD0);
  (void)touchTransfer12(0x90);
  digitalWrite(TOUCH_CS, HIGH);

  setBrightness(brightness);
  Serial.printf("I/O recovery complete: irq=%d MISO=%d heap=%u\n",
                digitalRead(TOUCH_IRQ), digitalRead(TOUCH_MISO), ESP.getFreeHeap());
}

String touchKey(const char *base) {
  return String(base) + String(displayRotation & 3);
}

void saveTouchCalibration() {
  prefs.begin(APP_NAMESPACE, false);
  prefs.putUChar("tcalver", 4);
  String k;
  k=touchKey("tv"); prefs.putBool(k.c_str(), touchCal.valid);
  k=touchKey("tax"); prefs.putFloat(k.c_str(), touchCal.ax);
  k=touchKey("tbx"); prefs.putFloat(k.c_str(), touchCal.bx);
  k=touchKey("tcx"); prefs.putFloat(k.c_str(), touchCal.cx);
  k=touchKey("tay"); prefs.putFloat(k.c_str(), touchCal.ay);
  k=touchKey("tby"); prefs.putFloat(k.c_str(), touchCal.by);
  k=touchKey("tcy"); prefs.putFloat(k.c_str(), touchCal.cy);
  prefs.end();
}

void loadTouchCalibration() {
  prefs.begin(APP_NAMESPACE, true);
  uint8_t ver = prefs.getUChar("tcalver", 0);
  if (ver != 3 && ver != 4) {
    touchCal = TouchCalibration();
    prefs.end();
    return;
  }
  // V3.17.2 migration: portrait profiles from the older calibration generation
  // are discarded once. Landscape profiles are preserved because they are known-good.
  if (ver == 3 && ((displayRotation & 1) == 0)) {
    touchCal = TouchCalibration();
    prefs.end();
    return;
  }
  String k;
  k=touchKey("tv"); touchCal.valid=prefs.getBool(k.c_str(),false);
  k=touchKey("tax"); touchCal.ax=prefs.getFloat(k.c_str(),0.0f);
  k=touchKey("tbx"); touchCal.bx=prefs.getFloat(k.c_str(),0.0f);
  k=touchKey("tcx"); touchCal.cx=prefs.getFloat(k.c_str(),0.0f);
  k=touchKey("tay"); touchCal.ay=prefs.getFloat(k.c_str(),0.0f);
  k=touchKey("tby"); touchCal.by=prefs.getFloat(k.c_str(),0.0f);
  k=touchKey("tcy"); touchCal.cy=prefs.getFloat(k.c_str(),0.0f);
  prefs.end();
}

bool captureCalibrationPoint(int x, int y, int16_t &rx, int16_t &ry, const char *label, int step) {
  uiCalibrationScreen(gfx->width(), gfx->height(), x, y, step, label);

  uint32_t started = millis();
  while (millis() - started < 30000UL) {
    if (readTouchRaw(rx, ry)) {
      delay(80);
      waitTouchRelease();
      return true;
    }
    delay(10);
  }
  return false;
}

static bool solve3x3(float a[3][4], float out[3]) {
  for (int col=0; col<3; col++) {
    int pivot=col;
    for (int r=col+1;r<3;r++) if (fabsf(a[r][col])>fabsf(a[pivot][col])) pivot=r;
    if (fabsf(a[pivot][col]) < 1e-9f) return false;
    if (pivot!=col) for (int c=col;c<4;c++) { float t=a[col][c]; a[col][c]=a[pivot][c]; a[pivot][c]=t; }
    float d=a[col][col];
    for (int c=col;c<4;c++) a[col][c]/=d;
    for (int r=0;r<3;r++) if (r!=col) {
      float f=a[r][col];
      for (int c=col;c<4;c++) a[r][c]-=f*a[col][c];
    }
  }
  for (int i=0;i<3;i++) out[i]=a[i][3];
  return true;
}

static bool fitAffine4(const int16_t rx[4], const int16_t ry[4], const float target[4], float &a, float &b, float &c) {
  // Least-squares solution of target = a*rx + b*ry + c using all four points.
  float sxx=0, syy=0, sxy=0, sx=0, sy=0;
  float sxt=0, syt=0, st=0;
  for (int i=0;i<4;i++) {
    float x=rx[i], y=ry[i], t=target[i];
    sxx+=x*x; syy+=y*y; sxy+=x*y; sx+=x; sy+=y;
    sxt+=x*t; syt+=y*t; st+=t;
  }
  float m[3][4]={{sxx,sxy,sx,sxt},{sxy,syy,sy,syt},{sx,sy,4.0f,st}};
  float o[3];
  if (!solve3x3(m,o)) return false;
  a=o[0]; b=o[1]; c=o[2]; return true;
}

void calibrateTouch() {
  gfx->setRotation(displayRotation);
  delay(100);

  // Keep targets away from the extreme resistive-panel edges, where accuracy
  // is poorest. The affine fit then extrapolates to the full display.
  const int mx = max(28, gfx->width()/12);
  const int my = max(28, gfx->height()/10);
  int16_t rx[4], ry[4];
  const int sx[4]={mx, gfx->width()-1-mx, mx, gfx->width()-1-mx};
  const int sy[4]={my, my, gfx->height()-1-my, gfx->height()-1-my};
  const char *lab[4]={"Touch TOP LEFT","Touch TOP RIGHT","Touch BOTTOM LEFT","Touch BOTTOM RIGHT"};
  for (int i=0;i<4;i++) if (!captureCalibrationPoint(sx[i],sy[i],rx[i],ry[i],lab[i],i)) goto done;

  {
    float tx[4],ty[4]; for(int i=0;i<4;i++){tx[i]=sx[i];ty[i]=sy[i];}
    if (fitAffine4(rx,ry,tx,touchCal.ax,touchCal.bx,touchCal.cx) &&
        fitAffine4(rx,ry,ty,touchCal.ay,touchCal.by,touchCal.cy)) {
      touchCal.valid=true;
      saveTouchCalibration();
      Serial.printf("Touch affine cal rot=%u X=[%.6f %.6f %.2f] Y=[%.6f %.6f %.2f]\n",
                    displayRotation,touchCal.ax,touchCal.bx,touchCal.cx,
                    touchCal.ay,touchCal.by,touchCal.cy);
    }
  }

done:
  gfx->fillScreen(BG0);
}

void saveNetworkConfig() {
  // V3.18.1: keep Wi-Fi credentials in their own NVS namespace so temporary
  // scan/reboot flags and other application settings cannot disturb them.
  Preferences netPrefs;
  netPrefs.begin("aurora_net", false);
  netPrefs.putString("ssid", wifiSsid);
  netPrefs.putString("pass", wifiPass);
  netPrefs.putString("ssid_bak", wifiSsid);
  netPrefs.putString("pass_bak", wifiPass);
  String verifySsid = netPrefs.getString("ssid", "");
  String verifyPass = netPrefs.getString("pass", "");
  netPrefs.end();
  Serial.printf("NVS network save: SSID='%s' passLen=%u verify=%s\n",
                wifiSsid.c_str(), (unsigned)wifiPass.length(),
                (verifySsid == wifiSsid && verifyPass == wifiPass) ? "OK" : "FAILED");
}

void loadNetworkConfig() {
  Preferences netPrefs;
  netPrefs.begin("aurora_net", true);
  String ns = netPrefs.getString("ssid", "");
  String np = netPrefs.getString("pass", "");
  if (!ns.length()) {
    ns = netPrefs.getString("ssid_bak", "");
    np = netPrefs.getString("pass_bak", "");
  }
  netPrefs.end();
  if (ns.length()) {
    wifiSsid = ns;
    wifiPass = np;
  }
  Serial.printf("NVS network load: SSID='%s' passLen=%u\n",
                wifiSsid.c_str(), (unsigned)wifiPass.length());
}

void saveLocationConfig() {
  // V3.18.2: keep location data in a dedicated NVS namespace so it survives
  // power cycles independently of SD storage and other application settings.
  Preferences locPrefs;
  locPrefs.begin("aurora_loc", false);
  locPrefs.putString("name", locationName);
  locPrefs.putFloat("lat", latitude);
  locPrefs.putFloat("lon", longitude);
  locPrefs.putString("tz", timezoneName);
  locPrefs.putString("tzabbr", timezoneAbbr);
  locPrefs.putInt("tzoff", timezoneOffsetSec);
  locPrefs.putString("name_bak", locationName);
  locPrefs.putFloat("lat_bak", latitude);
  locPrefs.putFloat("lon_bak", longitude);
  locPrefs.putString("tz_bak", timezoneName);
  locPrefs.putString("tzabbr_bak", timezoneAbbr);
  locPrefs.putInt("tzoff_bak", timezoneOffsetSec);
  String verifyName = locPrefs.getString("name", "");
  float verifyLat = locPrefs.getFloat("lat", 999.0f);
  float verifyLon = locPrefs.getFloat("lon", 999.0f);
  locPrefs.end();
  bool ok = (verifyName == locationName) &&
            (fabsf(verifyLat - latitude) < 0.0001f) &&
            (fabsf(verifyLon - longitude) < 0.0001f);
  Serial.printf("NVS location save: '%s' %.5f %.5f verify=%s\n",
                locationName.c_str(), latitude, longitude, ok ? "OK" : "FAILED");
}

void loadLocationConfig() {
  Preferences locPrefs;
  locPrefs.begin("aurora_loc", true);
  bool hasPrimary = locPrefs.isKey("name") && locPrefs.isKey("lat") && locPrefs.isKey("lon");
  bool hasBackup = locPrefs.isKey("name_bak") && locPrefs.isKey("lat_bak") && locPrefs.isKey("lon_bak");
  if (hasPrimary) {
    locationName = locPrefs.getString("name", locationName);
    latitude = locPrefs.getFloat("lat", latitude);
    longitude = locPrefs.getFloat("lon", longitude);
    timezoneName = locPrefs.getString("tz", timezoneName);
    timezoneAbbr = locPrefs.getString("tzabbr", timezoneAbbr);
    timezoneOffsetSec = locPrefs.getInt("tzoff", timezoneOffsetSec);
  } else if (hasBackup) {
    locationName = locPrefs.getString("name_bak", locationName);
    latitude = locPrefs.getFloat("lat_bak", latitude);
    longitude = locPrefs.getFloat("lon_bak", longitude);
    timezoneName = locPrefs.getString("tz_bak", timezoneName);
    timezoneAbbr = locPrefs.getString("tzabbr_bak", timezoneAbbr);
    timezoneOffsetSec = locPrefs.getInt("tzoff_bak", timezoneOffsetSec);
  }
  locPrefs.end();

  // Validate before use. If the dedicated namespace is empty or invalid, the
  // values already loaded from the legacy aurora3 namespace remain in place.
  bool valid = locationName.length() && latitude >= -90.0f && latitude <= 90.0f &&
               longitude >= -180.0f && longitude <= 180.0f;
  if (!valid) {
    locationName = DEFAULT_LOCATION;
    latitude = DEFAULT_LAT;
    longitude = DEFAULT_LON;
  }

  Serial.printf("NVS location load: '%s' %.5f %.5f source=%s\n",
                locationName.c_str(), latitude, longitude,
                (hasPrimary || hasBackup) ? "aurora_loc" : "legacy/default");

  // First boot on V3.18.2 migrates the legacy/default values into aurora_loc.
  if (!hasPrimary && !hasBackup) saveLocationConfig();
}

void saveConfig() {
  prefs.begin(APP_NAMESPACE, false);
  prefs.putString("ssid", wifiSsid);
  prefs.putString("pass", wifiPass);
  prefs.putUChar("rot", displayRotation);
  prefs.putUChar("bright", brightness);
  prefs.putBool("photo", photoEnabled);
  prefs.putUShort("pint", photoIntervalMin);
  prefs.putUShort("pdur", photoDurationSec);
  prefs.putBool("pshuf", photoShuffle);
  prefs.putBool("fahr", fahrenheit);
  prefs.putBool("mph", mph);
  prefs.putString("loc", locationName);
  prefs.putFloat("lat", latitude);
  prefs.putFloat("lon", longitude);
  prefs.putBool("mouse", mouseEnabled);
  prefs.putUShort("mmin", mouseMinSec);
  prefs.putUShort("mmax", mouseMaxSec);
  prefs.putUChar("mmove", mouseMoveMax);
  prefs.end();
  saveNetworkConfig();
  saveLocationConfig();
}

void loadConfig() {
  prefs.begin(APP_NAMESPACE, true);
  wifiSsid = prefs.getString("ssid", "");
  wifiPass = prefs.getString("pass", "");
  displayRotation = prefs.getUChar("rot", DEFAULT_ROTATION) & 3;
  brightness = constrain((int)prefs.getUChar("bright", DEFAULT_BRIGHTNESS), 10, 100);
  photoEnabled = prefs.getBool("photo", DEFAULT_PHOTO_ENABLED);
  photoIntervalMin = constrain((int)prefs.getUShort("pint", DEFAULT_PHOTO_INTERVAL_MIN), 1, 120);
  photoDurationSec = constrain((int)prefs.getUShort("pdur", DEFAULT_PHOTO_DURATION_SEC), 5, 300);
  photoShuffle = prefs.getBool("pshuf", true);
  fahrenheit = prefs.getBool("fahr", true);
  mph = prefs.getBool("mph", true);
  locationName = prefs.getString("loc", DEFAULT_LOCATION);
  latitude = prefs.getFloat("lat", DEFAULT_LAT);
  longitude = prefs.getFloat("lon", DEFAULT_LON);
  mouseEnabled = prefs.getBool("mouse", DEFAULT_MOUSE_ENABLED);
  mouseMinSec = constrain((int)prefs.getUShort("mmin", DEFAULT_MOUSE_MIN_SEC), 5, 600);
  mouseMaxSec = constrain((int)prefs.getUShort("mmax", DEFAULT_MOUSE_MAX_SEC), (int)mouseMinSec, 900);
  mouseMoveMax = constrain((int)prefs.getUChar("mmove", DEFAULT_MOUSE_MOVE_MAX), 1, 10);
  prefs.end();
  loadNetworkConfig();
  loadLocationConfig();
}

void setBrightness(uint8_t pct) {
  static bool pwmAttached = false;
  brightness = constrain((int)pct, 10, 100);
  if (!pwmAttached) {
    pwmAttached = ledcAttach(TFT_BL, 4000, 8);
    Serial.printf("Backlight PWM attach: %s\n", pwmAttached ? "OK" : "FAILED");
  }
  if (pwmAttached) {
    // V4: eyes respond roughly logarithmically, so a linear PWM duty makes the
    // slider feel "all at the top". Apply a gentle gamma so each slider step
    // looks like an equal change in brightness. 100% is still full duty.
    float f = (float)brightness / 100.0f;
    uint32_t duty = (uint32_t)(255.0f * powf(f, 1.6f) + 0.5f);
    if (duty < 6) duty = 6;
    ledcWrite(TFT_BL, duty);
  } else {
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);
  }
}

void setRotation(uint8_t r) {
  displayRotation = r & 3;
  gfx->setRotation(displayRotation);
  saveConfig();
  loadTouchCalibration();
  if (!touchCal.valid) calibrateTouch();
}

// -----------------------------------------------------------------------------
// Weather data
// -----------------------------------------------------------------------------

Weather wx;

String shortTime(const String &iso) {
  return iso.length() >= 16 ? iso.substring(11, 16) : "--:--";
}

int clockMinutes(const String &hhmm) {
  if (hhmm.length() < 5) return -1;
  return hhmm.substring(0,2).toInt()*60 + hhmm.substring(3,5).toInt();
}

String dayLabel(const String &iso, int index) {
  if (index == 0) return "TODAY";
  int y = iso.substring(0,4).toInt();
  int m = iso.substring(5,7).toInt();
  int d = iso.substring(8,10).toInt();
  struct tm t = {};
  t.tm_year = y-1900; t.tm_mon = m-1; t.tm_mday = d;
  mktime(&t);
  static const char *names[] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};
  return names[t.tm_wday];
}

bool connectWiFi(uint32_t timeoutMs = 12000) {
  if (wifiSsid.length() == 0) return false;

  Serial.printf("WiFi: connect start; free heap=%u\n", ESP.getFreeHeap());

  // Always start from a known-idle radio state. Aurora owns reconnection;
  // disable the core auto-reconnect path to avoid overlapping STA attempts.
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, false);
  WiFi.mode(WIFI_OFF);
  delay(250);
  yield();
  WiFi.mode(WIFI_STA);
  delay(100);
  yield();

  Serial.printf("WiFi: clean connect to '%s' (pass length=%u)\n",
                wifiSsid.c_str(), (unsigned)wifiPass.length());
  Serial.printf("WiFi: heap before begin=%u\n", ESP.getFreeHeap());
  WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());

  uint32_t start = millis();
  uint32_t lastReport = start;
  while (WiFi.status() != WL_CONNECTED && millis()-start < timeoutMs) {
    delay(100);
    yield();
    if (millis()-lastReport >= 3000) {
      lastReport = millis();
      Serial.printf("WiFi: waiting status=%d elapsed=%lu ms heap=%u\n",
                    (int)WiFi.status(), (unsigned long)(millis()-start), ESP.getFreeHeap());
    }
  }

  Serial.printf("WiFi: routine finished status=%d heap=%u\n",
                (int)WiFi.status(), ESP.getFreeHeap());

  if (WiFi.status() == WL_CONNECTED) {
    wifiConnectedCached = true;
    Serial.printf("WiFi: connected, IP=%s RSSI=%d\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
    return true;
  }

  Serial.printf("WiFi: connection timeout/status=%d; stopping STA\n", (int)WiFi.status());
  wifiConnectedCached = false;
  WiFi.disconnect(false, false);
  WiFi.mode(WIFI_OFF);
  delay(100);
  yield();
  return false;
}

bool fetchWeather() {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (ESP.getMaxAllocHeap() < WEATHER_MIN_BLOCK) {
    Serial.printf("Weather: refresh skipped - not enough free memory for HTTPS (largest block %u, need %u). "
                  "This happens while the BLE mouse is running; turn it off to refresh.\n",
                  ESP.getMaxAllocHeap(), (unsigned)WEATHER_MIN_BLOCK);
    return false;
  }
  Serial.printf("Weather: fetch start; heap=%u\n", ESP.getFreeHeap());
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  // V3.18.6: ArduinoJson parses directly from HTTPClient::getStream().
  // Force HTTP/1.0 so the server does not use chunked transfer encoding,
  // which getStream() does not decode.
  http.useHTTP10(true);
  String url =
    "https://api.open-meteo.com/v1/forecast?latitude=" + String(latitude,5) +
    "&longitude=" + String(longitude,5) +
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,dew_point_2m,is_day" +
    "&hourly=temperature_2m,precipitation_probability,weather_code" +
    "&daily=weather_code,temperature_2m_max,temperature_2m_min,uv_index_max,sunrise,sunset,precipitation_probability_max" +
    "&forecast_days=7&forecast_hours=24&timezone=auto";
  http.setConnectTimeout(9000);
  http.setTimeout(14000);
  if (!http.begin(client, url)) return false;
  int rc = http.GET();
  if (rc != HTTP_CODE_OK) {
    Serial.printf("Weather: HTTP failed rc=%d heap=%u\n", rc, ESP.getFreeHeap());
    http.end();
    return false;
  }

  // V3.18.3: parse directly from the HTTP stream and keep only fields the UI uses.
  // The previous getString()+full JsonDocument path held the complete payload twice,
  // which exhausted heap after BLE HID reduced free RAM to ~27 KB.
  JsonDocument filter;
  filter["current"]["temperature_2m"] = true;
  filter["current"]["relative_humidity_2m"] = true;
  filter["current"]["apparent_temperature"] = true;
  filter["current"]["weather_code"] = true;
  filter["current"]["wind_speed_10m"] = true;
  filter["current"]["wind_direction_10m"] = true;
  filter["current"]["pressure_msl"] = true;
  filter["current"]["dew_point_2m"] = true;
  filter["current"]["is_day"] = true;
  filter["current"]["time"] = true;

  filter["hourly"]["time"] = true;
  filter["hourly"]["temperature_2m"] = true;
  filter["hourly"]["precipitation_probability"] = true;
  filter["hourly"]["weather_code"] = true;

  filter["daily"]["time"] = true;
  filter["daily"]["temperature_2m_max"] = true;
  filter["daily"]["temperature_2m_min"] = true;
  filter["daily"]["uv_index_max"] = true;
  filter["daily"]["weather_code"] = true;
  filter["daily"]["precipitation_probability_max"] = true;
  filter["daily"]["sunrise"] = true;
  filter["daily"]["sunset"] = true;

  JsonDocument doc;
  DeserializationError jsonErr = deserializeJson(
      doc, http.getStream(), DeserializationOption::Filter(filter));
  http.end();
  if (jsonErr) {
    Serial.printf("Weather: JSON parse failed: %s heap=%u\n", jsonErr.c_str(), ESP.getFreeHeap());
    return false;
  }
  JsonObject cur = doc["current"];
  JsonObject hourly = doc["hourly"];
  JsonObject daily = doc["daily"];
  if (cur.isNull() || hourly.isNull() || daily.isNull()) {
    Serial.printf("Weather: parsed response missing sections current=%d hourly=%d daily=%d\n",
                  !cur.isNull(), !hourly.isNull(), !daily.isNull());
    return false;
  }

  wx.temp = cur["temperature_2m"] | 0.0f;
  wx.apparent = cur["apparent_temperature"] | wx.temp;
  wx.humidity = cur["relative_humidity_2m"] | 0.0f;
  wx.wind = cur["wind_speed_10m"] | 0.0f;
  wx.pressure = cur["pressure_msl"] | 0.0f;
  wx.dewpoint = cur["dew_point_2m"] | wx.temp;
  wx.windDir = cur["wind_direction_10m"] | 0;
  wx.code = cur["weather_code"] | 0;
  wx.isDay = cur["is_day"] | 1;
  strlcpy(wx.updated, shortTime(cur["time"] | String("")).c_str(), sizeof(wx.updated));
  wx.currentMinuteAtFetch = clockMinutes(wx.updated);

  JsonArray ht = hourly["time"];
  JsonArray htemp = hourly["temperature_2m"];
  JsonArray hprob = hourly["precipitation_probability"];
  JsonArray hcode = hourly["weather_code"];
  for (int i=0; i<HOURS; ++i) {
    wx.hourlyTemp[i] = htemp[i] | wx.temp;
    wx.hourlyRainProb[i] = hprob[i] | 0;
    wx.hourlyCode[i] = hcode[i] | wx.code;
    String ts = ht[i] | String("");
    wx.hourlyHour[i] = ts.length() >= 13 ? ts.substring(11,13).toInt() : i;
  }

  JsonArray dates = daily["time"];
  JsonArray dmax = daily["temperature_2m_max"];
  JsonArray dmin = daily["temperature_2m_min"];
  JsonArray duv = daily["uv_index_max"];
  JsonArray dcode = daily["weather_code"];
  JsonArray dprob = daily["precipitation_probability_max"];
  JsonArray dsunrise = daily["sunrise"];
  JsonArray dsunset = daily["sunset"];
  for (int i=0; i<DAYS; ++i) {
    String date = dates[i] | String("");
    strlcpy(wx.dayName[i], dayLabel(date, i).c_str(), sizeof(wx.dayName[i]));
    wx.dayMax[i] = dmax[i] | wx.temp;
    wx.dayMin[i] = dmin[i] | wx.temp;
    wx.dayUv[i] = duv[i] | 0.0f;
    wx.dayCode[i] = dcode[i] | wx.code;
    wx.dayRain[i] = dprob[i] | 0;
    strlcpy(wx.sunrise[i], shortTime(dsunrise[i] | String("")).c_str(), sizeof(wx.sunrise[i]));
    strlcpy(wx.sunset[i], shortTime(dsunset[i] | String("")).c_str(), sizeof(wx.sunset[i]));
    if (i == 0) {
      wx.sunriseMinute = clockMinutes(wx.sunrise[i]);
      wx.sunsetMinute = clockMinutes(wx.sunset[i]);
    }
  }
  wx.precipProb = wx.dayRain[0];
  wx.uv = wx.dayUv[0];
  wx.valid = true;
  return true;
}

// V3.18.5: timezone resolution is deliberately separate from fetchWeather().
// This keeps the proven low-memory V3.18.3 weather parser unchanged.
bool resolveTimezoneAndStartClock() {
  if (WiFi.status() != WL_CONNECTED) return false;
  Serial.printf("Time: timezone resolve start; heap=%u\n", ESP.getFreeHeap());

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  // V3.18.6: see fetchWeather(); direct stream parsing requires non-chunked body.
  http.useHTTP10(true);
  String url =
    "https://api.open-meteo.com/v1/forecast?latitude=" + String(latitude,5) +
    "&longitude=" + String(longitude,5) +
    "&current=temperature_2m&forecast_days=1&timezone=auto";
  http.setConnectTimeout(7000);
  http.setTimeout(10000);
  if (!http.begin(client, url)) {
    Serial.println("Time: timezone HTTP begin failed");
    return false;
  }
  int rc=http.GET();
  if(rc!=HTTP_CODE_OK){
    Serial.printf("Time: timezone HTTP failed rc=%d\n",rc);
    http.end();
    return false;
  }

  JsonDocument filter;
  filter["timezone"] = true;
  filter["timezone_abbreviation"] = true;
  filter["utc_offset_seconds"] = true;
  JsonDocument doc;
  DeserializationError err=deserializeJson(doc,http.getStream(),DeserializationOption::Filter(filter));
  http.end();
  if(err){
    Serial.printf("Time: timezone JSON failed: %s\n",err.c_str());
    return false;
  }

  String tz=doc["timezone"] | String("");
  if(!tz.length()){
    Serial.println("Time: timezone response missing timezone");
    return false;
  }
  timezoneName=tz;
  timezoneAbbr=doc["timezone_abbreviation"] | String("");
  timezoneOffsetSec=doc["utc_offset_seconds"] | 0;
  saveLocationConfig();

  configTime(timezoneOffsetSec,0,"pool.ntp.org","time.nist.gov");
  timeSyncConfigured=true;
  Serial.printf("Time: timezone=%s abbr=%s offset=%ld; SNTP started\n",
                timezoneName.c_str(),timezoneAbbr.c_str(),(long)timezoneOffsetSec);
  return true;
}

void startClockFromCachedTimezone() {
  if(timeSyncConfigured || WiFi.status()!=WL_CONNECTED) return;
  if(timezoneName.length()) {
    configTime(timezoneOffsetSec,0,"pool.ntp.org","time.nist.gov");
    Serial.printf("Time: SNTP started from cached timezone %s offset=%ld\n",
                  timezoneName.c_str(),(long)timezoneOffsetSec);
  } else {
    // Start SNTP immediately in UTC so the RTC can synchronize even before
    // location->timezone resolution succeeds. Once resolved, configTime()
    // below is called again with the local offset.
    configTime(0,0,"pool.ntp.org","time.nist.gov");
    Serial.println("Time: SNTP started in UTC pending timezone resolution");
  }
  timeSyncConfigured=true;
}

// -----------------------------------------------------------------------------
// SD card and JPEG photos
// -----------------------------------------------------------------------------

static constexpr int MAX_PHOTOS = 32;
String photoFiles[MAX_PHOTOS];
int photoCount = 0;
int photoIndex = -1;
bool sdReady = false;
JPEGDEC jpeg;
File jpegFile;

void *jpegOpen(const char *filename, int32_t *size) {
  jpegFile = SD.open(filename, FILE_READ);
  if (!jpegFile) { *size = 0; return nullptr; }
  *size = jpegFile.size();
  return &jpegFile;
}
void jpegClose(void *handle) { if (jpegFile) jpegFile.close(); }
int32_t jpegRead(JPEGFILE *handle, uint8_t *buffer, int32_t length) {
  return jpegFile ? jpegFile.read(buffer, length) : 0;
}
int32_t jpegSeek(JPEGFILE *handle, int32_t position) {
  return jpegFile ? jpegFile.seek(position) : 0;
}
int jpegDraw(JPEGDRAW *pDraw) {
  // V3.17.9: panel inversion is handled globally by the ILI9341 controller.
  // Draw JPEGDEC's RGB565 data unchanged using the supported big-endian path.
  gfx->draw16bitBeRGBBitmap(pDraw->x, pDraw->y, pDraw->pPixels, pDraw->iWidth, pDraw->iHeight);
  return 1;
}

bool isJpegName(String name) {
  name.toLowerCase();
  return name.endsWith(".jpg") || name.endsWith(".jpeg");
}

// Alphabetical order makes "In sequence" mode predictable.
static void sortPhotos() {
  for (int i = 1; i < photoCount; ++i) {
    String key = photoFiles[i];
    int j = i - 1;
    while (j >= 0 && photoFiles[j].compareTo(key) > 0) { photoFiles[j + 1] = photoFiles[j]; --j; }
    photoFiles[j + 1] = key;
  }
}

void scanPhotos() {
  if (!sdReady) { photoCount = 0; return; }
  if (ESP.getMaxAllocHeap() < SCAN_MIN_BLOCK) {
    // Keep the list from before BLE started rather than risk an out-of-memory abort.
    Serial.printf("SD photo scan skipped: low memory (largest block %u); keeping %d photo(s)\n", ESP.getMaxAllocHeap(), photoCount);
    return;
  }
  photoCount = 0;
  File dir = SD.open("/photos");
  if (!dir || !dir.isDirectory()) return;
  File f = dir.openNextFile();
  while (f && photoCount < MAX_PHOTOS) {
    if (!f.isDirectory()) {
      String n = f.name();
      // V4: skip macOS resource-fork files ("._IMG_0001.jpg") that look like JPEGs but are not.
      int slash = n.lastIndexOf('/');
      String base = (slash >= 0) ? n.substring(slash + 1) : n;
      if (isJpegName(n) && !base.startsWith(".")) {
        if (!n.startsWith("/")) n = String("/photos/") + n;
        photoFiles[photoCount++] = n;
      }
    }
    f.close();
    f = dir.openNextFile();
  }
  dir.close();
  sortPhotos();
  Serial.printf("SD photo scan: %d JPEG(s)\n", photoCount);
}

// Cheap health check of an existing mount (opens the root directory).
static bool sdStillGood() {
  if (!sdReady) return false;
  if (SD.cardType() == CARD_NONE) return false;
  File root = SD.open("/");
  bool ok = (bool)root;
  if (root) root.close();
  return ok;
}

// V4.1.1: the Bluetooth mouse makes SD mounting fragile (BLE takes ~100 KB of heap,
// the radio draws current bursts that sag the CYD's weak 3.3 V rail, and 20 MHz
// SPI is the first thing to fail). So:
//   * a mount that is still healthy is NEVER torn down - RESCAN just re-reads /photos;
//   * a fresh mount uses a slower clock while BLE is running;
//   * the card is mounted *before* BLE starts (see serviceBleMouseStart).
bool initSD() {
  if (bleMouse.isStarted() && ESP.getMaxAllocHeap() < SD_MIN_BLOCK_BLE) {
    // After BLE starts there is no room to mount or rescan; the card was mounted
    // and scanned before BLE init. Never tear that mount down.
    Serial.printf("SD: not enough memory to (re)mount while the BLE mouse runs (largest block %u); keeping current state\n", ESP.getMaxAllocHeap());
    return sdReady;
  }
  if (sdStillGood()) {
    Serial.printf("SD: mount healthy, rescanning /photos only; heap=%u\n", ESP.getFreeHeap());
    scanPhotos();
    return true;
  }

  const bool ble = bleMouse.isStarted();
  Serial.printf("SD: mounting; BLE=%d heap=%u largest=%u\n", ble ? 1 : 0, ESP.getFreeHeap(), ESP.getMaxAllocHeap());
  sdReady = false;
  SD.end();
  sdSPI.end();
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
  delay(ble ? 120 : 30);

  const uint32_t clocksNormal[] = {20000000, 10000000, 4000000, 1000000};
  const uint32_t clocksBle[]    = {10000000, 4000000, 1000000, 400000};
  const uint32_t *clocks = ble ? clocksBle : clocksNormal;
  for (uint8_t attempt=0; attempt<4 && !sdReady; ++attempt) {
    Serial.printf("SD mount attempt %u at %lu Hz\n", attempt+1, (unsigned long)clocks[attempt]);
    sdSPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
    delay(ble ? 60 : 20);
    sdReady = SD.begin(SD_CS, sdSPI, clocks[attempt], "/sd", 3);   // 3 open files is plenty here
    if (!sdReady) {
      SD.end();
      sdSPI.end();
      digitalWrite(SD_CS, HIGH);
      delay(ble ? 200 : 75);
    }
  }

  if (sdReady) {
    uint8_t cardType = SD.cardType();
    uint64_t cardMB = SD.cardSize() / (1024ULL * 1024ULL);
    Serial.printf("SD mounted: type=%u size=%llu MB\n", cardType, cardMB);
    scanPhotos();
  } else {
    photoCount = 0;
    Serial.printf("SD card mount failed after 4 attempts; BLE=%d heap=%u. "
                  "If this only happens with the mouse on: check USB power / add a 100uF cap on 3V3.\n",
                  ble ? 1 : 0, ESP.getFreeHeap());
  }
  return sdReady;
}

// Draws a photo into the area above the navigation bar (areaH rows). Photos that
// fit the whole screen are centred in the area; a photo taller than the area but
// within the screen is top-aligned and the nav bar overlays its bottom edge.
// Every failure is logged so a "missing" photo can be diagnosed from Serial.
bool showJpegFit(const String &pathIn, int areaH) {
  String path = pathIn;                       // copy: a remount below rewrites photoFiles[]
  if (!sdStillGood()) {
    if (bleMouse.isStarted() && ESP.getMaxAllocHeap() < SD_MIN_BLOCK_BLE) {
      Serial.println("Photo: SD mount lost and there is no memory to remount while the mouse is on");
      return false;
    }
    Serial.println("Photo: SD mount lost (radio activity or power dip?) - remounting");
    initSD();
    if (!sdReady) { Serial.println("Photo: SD not ready"); return false; }
    if (photoCount > 0 && photoIndex >= photoCount) photoIndex = 0;
  }
  if (!SD.exists(path)) { Serial.printf("Photo: missing file %s\n", path.c_str()); return false; }
  gfx->invertDisplay(true);
  char filename[128];
  path.toCharArray(filename, sizeof(filename));
  if (!jpeg.open(filename, jpegOpen, jpegClose, jpegRead, jpegSeek, jpegDraw)) {
    Serial.printf("Photo: JPEG open failed (not a valid baseline JPEG?) %s\n", filename);
    return false;
  }
  jpeg.setPixelType(RGB565_BIG_ENDIAN);
  int iw = jpeg.getWidth(), ih = jpeg.getHeight();
  int sw = gfx->width(), sh = gfx->height();
  int options = 0, scale = 1;
  if (iw > sw || ih > sh) { options = JPEG_SCALE_HALF; scale = 2; }
  if ((iw/scale) > sw || (ih/scale) > sh) { options = JPEG_SCALE_QUARTER; scale = 4; }
  if ((iw/scale) > sw || (ih/scale) > sh) { options = JPEG_SCALE_EIGHTH; scale = 8; }
  if ((iw/scale) > sw || (ih/scale) > sh) {
    // The decoder can only shrink by 8x; drawing this would show a cropped corner.
    Serial.printf("Photo: %dx%d is too large (max about %dx%d); skipping %s\n", iw, ih, sw*8, sh*8, filename);
    jpeg.close();
    return false;
  }
  int dw = iw/scale, dh = ih/scale;
  int x = max(0, (sw-dw)/2);
  int y = (dh <= areaH) ? (areaH-dh)/2 : 0;
  gfx->fillRect(0, 0, sw, areaH, RGB565_BLACK);
  int ok = jpeg.decode(x, y, options);
  jpeg.close();
  Serial.printf("Photo: %s %dx%d scale 1/%d -> %s\n", filename, iw, ih, scale, ok==1 ? "OK" : "DECODE FAILED");
  return ok == 1;
}

bool showStartupSplash() {
  gfx->invertDisplay(true);
  gfx->fillScreen(BG0);
  if (!jpeg.openFLASH((uint8_t *)AURORA_SPLASH_JPG, AURORA_SPLASH_JPG_LEN, jpegDraw)) {
    return false;
  }
  jpeg.setPixelType(RGB565_BIG_ENDIAN);
  int iw=jpeg.getWidth(), ih=jpeg.getHeight();
  int x=max(0,(gfx->width()-iw)/2);
  int y=max(0,(gfx->height()-ih)/2-10);
  int ok=jpeg.decode(x,y,0);
  jpeg.close();
  if(ok==1) uiSplashFooter(gfx->width(), gfx->height(), FW_VERSION, 0.0f, true);
  return ok==1;
}

// -----------------------------------------------------------------------------
// Page state (all drawing lives in AuroraUI.h)
// -----------------------------------------------------------------------------

Page page = PAGE_NOW;
Page lastRenderedPage = PAGE_NOW;
uint32_t weatherLast=0, lastWifiAttempt=0, lastRender=0;
uint32_t lastWeatherPageCycle=0;
uint32_t loopHeartbeatLast=0;
uint32_t loopHeartbeatCount=0;
int lastTouchIrqState=HIGH;
// Photo tab state: PIC is one of the auto-cycle pages. Each time the tab is
// entered it shows the next photo (alphabetical order, wrapping).
bool photoShowing=false;        // a photo is currently on screen
bool photoAllFailed=false;      // every file failed to decode (tab is left out of the cycle)
uint32_t sdProbeNotBefore=0;    // retry gate for the lazy SD mount
bool pageDirty=true;
uint32_t lastIconAnim=0;

// -----------------------------------------------------------------------------
// Settings and Wi-Fi configuration pages
// -----------------------------------------------------------------------------

SettingsView settingsView=SETTINGS_MAIN;
char scannedSsids[10][33] = {};
int scannedRssi[10];
int scanCount=0;
String pendingSsid;
String keyboardText;
bool keyboardUpper=false;
bool keyboardSymbols=false;
LocationField locationField=LOC_FIELD_NAME;
String locationEditName;
String locationEditLat;
String locationEditLon;
String settingsStatus="";
uint32_t settingsStatusUntil=0;
// Status text appears in the header for a few seconds, then clears itself.
void setStatus(const char *msg, uint32_t ms = 4000) {
  settingsStatus = msg;
  settingsStatusUntil = millis() + ms;
}
bool wifiScanActive=false;
bool wifiScanPending=false;
uint32_t wifiScanStarted=0;

void scanNetworks() {
  // IMPORTANT for ESP32 Arduino core 3.3.x:
  // Do not start the Wi-Fi scan from the touch handler. First switch to the
  // scanning page and allow that page to be physically drawn. The scan is
  // started on a later loop pass by serviceWiFiScan().
  scanCount=0;
  settingsStatus="Scanning...";
  settingsView=SETTINGS_WIFI_SCANNING;
  wifiScanPending=true;
  wifiScanActive=false;
  wifiScanStarted=millis();
  Serial.println("WiFi scan requested - drawing status screen first");
  pageDirty=true;
}

void serviceWiFiScan() {
  if(!wifiScanPending || settingsView!=SETTINGS_WIFI_SCANNING) return;

  // Wait until render() has completed the Scanning page and leave a short
  // settling interval. pageDirty remains true until that render is complete.
  if(pageDirty || millis()-wifiScanStarted < 120) return;

  wifiScanPending=false;
  wifiScanActive=true;

  Serial.printf("WiFi scan: free heap before=%u bytes\n", ESP.getFreeHeap());
  Serial.println("WiFi scan: preparing station radio (no external IRQ pin is used)");

  // V3.6: do not alter backlight PWM during Wi-Fi scanning. The radio scan has
  // been proven stable on this board, and changing LEDC state around the scan
  // can make the display appear blank even though the TFT is still drawing.

  // Follow Espressif's scan setup sequence: station mode, disconnect, short
  // settle delay. Do not erase saved credentials here.
  WiFi.scanDelete();
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, false);
  delay(120);

  Serial.println("WiFi scan: starting low-power passive scan");

  // Passive scan avoids active probe transmissions and lowers instantaneous RF
  // load. 150 ms/channel is long enough to catch normal AP beacon intervals.
  int n=WiFi.scanNetworks(false, false, true, 150, 0);

  Serial.printf("WiFi scan: returned %d, free heap after=%u bytes\n", n, ESP.getFreeHeap());
  wifiScanActive=false;
  scanCount=0;
  if(n>=0) {
    scanCount=min(n,10);
    for(int i=0;i<scanCount;i++) {
      String ssid = WiFi.SSID(i);
      strlcpy(scannedSsids[i], ssid.c_str(), sizeof(scannedSsids[i]));
      scannedRssi[i]=WiFi.RSSI(i);
    }
    settingsStatus = scanCount ? String(scanCount)+" network(s)" : "No networks found";
    Serial.printf("WiFi scan complete: %d found, displaying %d\n", n, scanCount);
  } else {
    settingsStatus="Scan failed";
    Serial.printf("WiFi scan failed rc=%d\n", n);
  }
  WiFi.scanDelete();

  // V3.12 diagnostic/workaround: after copying all scan results into our own
  // fixed RAM buffers, completely stop the Wi-Fi driver before touching the
  // TFT again. The network list itself does not require the radio to remain on.
  // connectWiFi() explicitly restores WIFI_STA when the user chooses a network.
  Serial.println("WiFi scan: copied results; saving list and rebooting before TFT draw");
  Serial.flush();
  savePendingWiFiScanForReboot();
  WiFi.disconnect(true, false);
  WiFi.mode(WIFI_OFF);
  delay(150);
  Serial.println("WiFi scan: restarting ESP32 into network-list mode");
  Serial.flush();
  delay(50);
  ESP.restart();
}


void savePendingWiFiScanForReboot() {
  prefs.begin(APP_NAMESPACE, false);
  prefs.putBool("scanboot", true);
  prefs.putUChar("scann", (uint8_t)scanCount);
  for (int i=0; i<10; i++) {
    char ks[8], kr[8];
    snprintf(ks, sizeof(ks), "ss%u", i);
    snprintf(kr, sizeof(kr), "sr%u", i);
    if (i < scanCount) {
      prefs.putString(ks, scannedSsids[i]);
      prefs.putInt(kr, scannedRssi[i]);
    } else {
      prefs.remove(ks);
      prefs.remove(kr);
    }
  }
  prefs.end();
}

bool loadPendingWiFiScanAfterReboot() {
  prefs.begin(APP_NAMESPACE, false);
  bool pending = prefs.getBool("scanboot", false);
  if (!pending) {
    prefs.end();
    return false;
  }
  scanCount = min((int)prefs.getUChar("scann", 0), 10);
  for (int i=0; i<scanCount; i++) {
    char ks[8], kr[8];
    snprintf(ks, sizeof(ks), "ss%u", i);
    snprintf(kr, sizeof(kr), "sr%u", i);
    String ss = prefs.getString(ks, "");
    strlcpy(scannedSsids[i], ss.c_str(), sizeof(scannedSsids[i]));
    scannedRssi[i] = prefs.getInt(kr, -127);
  }
  prefs.putBool("scanboot", false);   // one-shot boot mode
  prefs.end();
  return true;
}

void savePendingWiFiConnectForReboot() {
  prefs.begin(APP_NAMESPACE, false);
  prefs.putBool("connboot", true);
  prefs.end();
}

bool takePendingWiFiConnectAfterReboot() {
  prefs.begin(APP_NAMESPACE, false);
  bool pending = prefs.getBool("connboot", false);
  if (pending) prefs.putBool("connboot", false);  // one-shot boot mode
  prefs.end();
  return pending;
}

void saveWiFiFailureForCleanBoot() {
  prefs.begin(APP_NAMESPACE, false);
  prefs.putBool("wififail", true);
  prefs.end();
}

bool takeWiFiFailureAfterReboot() {
  prefs.begin(APP_NAMESPACE, false);
  bool failed = prefs.getBool("wififail", false);
  if (failed) prefs.putBool("wififail", false);
  prefs.end();
  return failed;
}


// -----------------------------------------------------------------------------
// Touch handling
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Touch handling (hit rectangles come from AuroraUI.h, the same layout functions
// that position the drawing, so taps always line up with what is on screen)
// -----------------------------------------------------------------------------

static inline bool hitRect(const TouchPoint &p, const Rect &r, int pad = 3) {
  return rectHit(r, p.x, p.y, pad);
}

void handleKeyboardTouch(const TouchPoint &p) {
  int w=gfx->width(), h=gfx->height();
  KbLayout K=kbLayout(w,h);
  // Large CANCEL target in the title bar.
  if (hitRect(p,K.cancel,0)) {
    settingsView=(settingsView==SETTINGS_LOCATION_KEYBOARD)?SETTINGS_LOCATION:SETTINGS_WIFI_LIST;
    pageDirty=true; return;
  }

  if (p.y>=K.keyTop && p.y<K.keyTop+4*K.rowH) {
    int row=constrain((p.y-K.keyTop)/K.rowH,0,3);
    int col=constrain(p.x/K.kw,0,K.cols-1);
    const char *keys=kbRows(row,keyboardUpper,keyboardSymbols);
    if(keyboardText.length()<63) keyboardText += keys[col];
    pageDirty=true; return;
  }

  // Hitboxes deliberately extend a couple of pixels beyond the drawn controls.
  if(hitRect(p,K.mode,2)) keyboardSymbols=!keyboardSymbols;
  else if(hitRect(p,K.shift,2)) keyboardUpper=!keyboardUpper;
  else if(hitRect(p,K.space,2)) { if(keyboardText.length()<63) keyboardText+=' '; }
  else if(hitRect(p,K.del,2)) { if(keyboardText.length()) keyboardText.remove(keyboardText.length()-1); }
  else if(hitRect(p,K.ok,2)) {
    if(settingsView==SETTINGS_LOCATION_KEYBOARD) {
      if(locationField==LOC_FIELD_NAME) locationEditName=keyboardText;
      else if(locationField==LOC_FIELD_LAT) locationEditLat=keyboardText;
      else locationEditLon=keyboardText;
      settingsView=SETTINGS_LOCATION;
    } else {
      wifiSsid=pendingSsid;
      wifiPass=keyboardText;
      Serial.println("\n===== WIFI PASSWORD ACCEPTED =====");
      Serial.printf("SSID: %s\n", wifiSsid.c_str());
      Serial.printf("Password length: %u\n", (unsigned)wifiPass.length());
      Serial.printf("[1] Heap before save: %u\n", ESP.getFreeHeap());
      saveConfig();
      Serial.println("[2] Configuration saved");
      savePendingWiFiConnectForReboot();
      Serial.println("[3] Clean-boot WiFi connect flag saved");
      settingsStatus="Saved - restarting";
      setBrightness(brightness);
      uiStatusScreen(w,h,"WI-FI SAVED","Restarting to connect...","",T_CYAN,2);
      Serial.println("[DISPLAY] Wi-Fi saved screen drawn");
      Serial.flush();
      delay(450);
      ESP.restart();
    }
  }
  pageDirty=true;
}

void handleSettingsTouch(const TouchPoint &p) {
  int w=gfx->width(), h=gfx->height();
  if(settingsView==SETTINGS_KEYBOARD || settingsView==SETTINGS_LOCATION_KEYBOARD){ handleKeyboardTouch(p); return; }
  if(settingsView==SETTINGS_MOUSE){
    MouseLayout L=mouseLayout(w,h);
    if(hitRect(p,L.toggle,2)){
      mouseEnabled=!mouseEnabled;
      if(mouseEnabled){
        // Never initialize BLE from inside the touch handler. If BLE was
        // previously started, simply re-enable the jiggler and make sure Wi-Fi
        // is restored; do not try to initialize the controller a second time.
        if(bleMouse.isStarted()) {
          bleStartPending=false;
          bleWifiRestorePending=true;
          bleWifiRestoreInProgress=false;
          bleWifiRestoreNotBefore=millis()+250;
          Serial.println("BLE mouse: jiggler re-enabled; Wi-Fi coexistence check queued");
        } else {
          bleStartPending=true;
          bleStartNotBefore=millis()+750;
          Serial.printf("BLE mouse: enable requested; deferred start; heap=%u\n", ESP.getFreeHeap());
        }
        nextMouseMoveMs=0;
      } else {
        bleStartPending=false;
        bleWifiRestorePending=false;
        bleWifiRestoreInProgress=false;
        nextMouseMoveMs=0;
        Serial.println("BLE mouse: jiggler disabled");
        if(bleMouse.isStarted()) {
          // The BLE stack is not released at run time (Wi-Fi coexistence); the only reliable way
          // to give its ~120 KB back (weather refresh, SD rescan) is a clean restart.
          saveConfig();
          Serial.printf("BLE mouse: disabled while running; restarting to free memory (heap=%u)\n", ESP.getFreeHeap());
          uiStatusScreen(w,h,"MOUSE OFF","Restarting to free memory...","",T_CYAN,2);
          Serial.flush();
          delay(500);
          ESP.restart();
        }
      }
      saveConfig();
      pageDirty=true;
      return;
    }
    if(hitRect(p,L.minMinus,2)){ mouseMinSec=max(5,(int)mouseMinSec-5); if(mouseMaxSec<mouseMinSec) mouseMaxSec=mouseMinSec; saveConfig(); pageDirty=true; return; }
    if(hitRect(p,L.minPlus,2)){ mouseMinSec=min(600,(int)mouseMinSec+5); if(mouseMaxSec<mouseMinSec) mouseMaxSec=mouseMinSec; saveConfig(); pageDirty=true; return; }
    if(hitRect(p,L.maxMinus,2)){ mouseMaxSec=max((int)mouseMinSec,(int)mouseMaxSec-5); saveConfig(); pageDirty=true; return; }
    if(hitRect(p,L.maxPlus,2)){ mouseMaxSec=min(900,(int)mouseMaxSec+5); saveConfig(); pageDirty=true; return; }
    if(hitRect(p,L.movMinus,2)){ mouseMoveMax=max(1,(int)mouseMoveMax-1); saveConfig(); pageDirty=true; return; }
    if(hitRect(p,L.movPlus,2)){ mouseMoveMax=min(10,(int)mouseMoveMax+1); saveConfig(); pageDirty=true; return; }
    if(hitRect(p,L.back,2)){ settingsView=SETTINGS_MAIN; pageDirty=true; return; }
    return;
  }
  if(settingsView==SETTINGS_LOCATION){
    LocLayout L=locLayout(w,h);
    if(hitRect(p,L.name,3)){ locationField=LOC_FIELD_NAME; keyboardText=locationEditName; keyboardUpper=false; keyboardSymbols=false; settingsView=SETTINGS_LOCATION_KEYBOARD; pageDirty=true; return; }
    if(hitRect(p,L.lat,3)){ locationField=LOC_FIELD_LAT; keyboardText=locationEditLat; keyboardUpper=false; keyboardSymbols=true; settingsView=SETTINGS_LOCATION_KEYBOARD; pageDirty=true; return; }
    if(hitRect(p,L.lon,3)){ locationField=LOC_FIELD_LON; keyboardText=locationEditLon; keyboardUpper=false; keyboardSymbols=true; settingsView=SETTINGS_LOCATION_KEYBOARD; pageDirty=true; return; }
    if(hitRect(p,L.back,2)){ settingsView=SETTINGS_MAIN; pageDirty=true; return; }
    if(hitRect(p,L.save,2)){
      float la=locationEditLat.toFloat();
      float lo=locationEditLon.toFloat();
      if(locationEditName.length()==0){ setStatus("Location name required"); pageDirty=true; return; }
      if(locationEditLat.length()==0 || locationEditLon.length()==0){ setStatus("Coordinates required"); pageDirty=true; return; }
      if(la < -90.0f || la > 90.0f || lo < -180.0f || lo > 180.0f){ setStatus("Invalid coordinates"); pageDirty=true; return; }
      locationName=locationEditName; latitude=la; longitude=lo;
      timezoneName=""; timezoneAbbr=""; timezoneOffsetSec=0; timeSyncConfigured=false;
      timezoneResolveNotBefore=millis()+500;
      saveConfig();
      setStatus("Location saved");
      wx.valid=false; weatherLast=0;
      if(wifiConnectedCached){ weatherFetchPending=true; weatherFetchNotBefore=millis()+250; }
      settingsView=SETTINGS_MAIN; pageDirty=true;
      Serial.printf("Location saved: %s %.5f %.5f\n",locationName.c_str(),latitude,longitude);
      return;
    }
    return;
  }
  if(settingsView==SETTINGS_WIFI_SCANNING){
    if(hitRect(p,wifiListLayout(w,h).back,2)){
      WiFi.scanDelete(); wifiScanActive=false; wifiScanPending=false; settingsView=SETTINGS_MAIN; pageDirty=true;
    }
    return;
  }
  if(settingsView==SETTINGS_WIFI_LIST){
    ListLayout L=wifiListLayout(w,h);
    int maxRows=min(scanCount,L.maxRows);
    for(int i=0;i<maxRows;i++) if(hitRect(p,wifiRowRect(L,w,i),0)) {
      pendingSsid=String(scannedSsids[i]); keyboardText=""; keyboardUpper=false; keyboardSymbols=false; settingsView=SETTINGS_KEYBOARD; pageDirty=true; return;
    }
    if(hitRect(p,L.back,2)){settingsView=SETTINGS_MAIN;pageDirty=true;return;}
    if(hitRect(p,L.rescan,2)){scanNetworks();return;}
    return;
  }

  // ---- Settings main
  SettingsLayout L=settingsLayout(w,h);
  if(hitRect(p,L.wifi,2)){
    Serial.printf("WiFi settings tapped x=%d y=%d\n", p.x, p.y);
    scanNetworks();
    return;
  }
  if(hitRect(p,L.loc,2)){
    locationEditName=locationName;
    locationEditLat=String(latitude,5);
    locationEditLon=String(longitude,5);
    settingsView=SETTINGS_LOCATION;
    pageDirty=true;
    return;
  }
  for(int i=0;i<4;i++) if(hitRect(p,L.rot[i],1)){setRotation(i);pageDirty=true;return;}
  if(hitRect(p,L.brTrack,3)){
    int x0=L.brTrack.x+8, sw=max(1,L.brTrack.w-16);
    brightness=constrain(10+(p.x-x0)*90/sw,10,100); setBrightness(brightness); saveConfig(); pageDirty=true; return;
  }
  if(hitRect(p,L.photos,2)){
    photoEnabled=!photoEnabled;
    if(photoEnabled) { photoAllFailed=false; sdProbeNotBefore=0; }   // give the tab a fresh chance
    saveConfig(); pageDirty=true; return;
  }
  if(hitRect(p,L.rescan,2)){
    if(bleMouse.isStarted() && ESP.getMaxAllocHeap() < SD_MIN_BLOCK_BLE) {
      // Safety net: only if the BLE stack really left too little memory to allocate.
      setStatus("Low memory: restart to rescan", 6000);
      pageDirty=true; return;
    }
    sdProbeNotBefore=0; photoAllFailed=false; photoIndex=-1;
    initSD();
    setStatus(sdReady ? "SD rescanned" : "SD not found");
    pageDirty=true; return;
  }
  if(hitRect(p,L.mouse,2)){settingsView=SETTINGS_MOUSE;pageDirty=true;return;}
  if(hitRect(p,L.cal,2)){touchCal.valid=false;calibrateTouch();pageDirty=true;return;}
}

void handleTouch(const TouchPoint &p) {
  if(!p.touched) return;
  int w=gfx->width(), h=gfx->height();

  // V3.16.8: the navigation bar is global on every page that draws it. V4 only
  // honours it where it is visible (Settings sub-screens have their own BACK
  // buttons), which also fixes taps near the bottom edge hitting hidden tabs.
  bool navVisible=(page!=PAGE_SETTINGS || settingsView==SETTINGS_MAIN);
  if(navVisible && p.y>=uiNavTop(h)){
    Page oldPage=page;
    int idx=constrain((int)p.x*7/max(1,w),0,6);
    page=(Page)idx;
    lastWeatherPageCycle=millis();

    // Leaving Settings cancels any scan request that has not started yet and
    // resets its sub-view so returning to Settings always has a sane state.
    if(oldPage==PAGE_SETTINGS && page!=PAGE_SETTINGS){
      wifiScanPending=false;
      wifiScanActive=false;
      settingsView=SETTINGS_MAIN;
    } else if(page==PAGE_SETTINGS) {
      settingsView=SETTINGS_MAIN;
    }

    Serial.printf("Nav: page %d -> %d x=%d y=%d\n",
                  (int)oldPage,(int)page,p.x,p.y);
    pageDirty=true;
    waitTouchRelease();
    return;
  }

  if(page==PAGE_SETTINGS){ handleSettingsTouch(p); waitTouchRelease(); return; }
  // Tap the photo itself to skip to the next one (and restart the dwell timer).
  if(page==PAGE_PHOTO && photoShowing && photoCount>1){
    photoIndex=(photoIndex+1)%photoCount;
    lastWeatherPageCycle=millis();
    pageDirty=true;
    waitTouchRelease();
    return;
  }
}

// -----------------------------------------------------------------------------
// Rendering and slideshow service
// -----------------------------------------------------------------------------

// Gather everything the (hardware-independent) UI needs into one plain struct.
// Pointers refer to Strings/arrays that stay untouched for the duration of the draw.
static char kbSubBuf[80];

void buildModel(UiModel &m) {
  m.wx=&wx;
  m.page=page;
  m.sview=settingsView;
  m.wifiOn=wifiConnectedCached;
  m.location=locationName.c_str();
  m.fahrenheit=fahrenheit;
  m.mph=mph;
  m.rotation=displayRotation;
  m.brightness=brightness;
  m.photoEnabled=photoEnabled;
  m.mouseEnabled=mouseEnabled;
  m.bleConnected=bleMouse.isStarted() && bleMouse.isConnected();
  m.sdReady=sdReady;
  m.photoCount=photoCount;
  m.photoFailed=photoAllFailed;
  m.cycleSec=(int)(WEATHER_PAGE_CYCLE_MS/1000UL);
  m.mouseMin=mouseMinSec;
  m.mouseMax=mouseMaxSec;
  m.mouseMove=mouseMoveMax;

  // Clock: prefer the real NTP-backed time; fall back to the weather fetch time.
  time_t nowUtc=time(nullptr);
  if(nowUtc>=1700000000) {
    m.timeValid=true;
    localtime_r(&nowUtc,&m.tm);
    m.nowMinute=m.tm.tm_hour*60+m.tm.tm_min;
  } else {
    m.timeValid=false;
    int nm=wx.currentMinuteAtFetch;
    if(nm>=0 && weatherLast) nm=(nm+(millis()-weatherLast)/60000UL)%1440;
    m.nowMinute=nm;
  }
  m.tzAbbr=timezoneAbbr.c_str();
  m.tzName=timezoneName.c_str();

  m.scanCount=scanCount;
  m.ssids=scannedSsids;
  m.rssi=scannedRssi;

  if(settingsView==SETTINGS_KEYBOARD) {
    m.kbTitle="WI-FI PASSWORD";
    snprintf(kbSubBuf,sizeof(kbSubBuf),"Network: %s",pendingSsid.c_str());
  } else {
    m.kbTitle=(locationField==LOC_FIELD_NAME)?"LOCATION NAME":((locationField==LOC_FIELD_LAT)?"LATITUDE":"LONGITUDE");
    snprintf(kbSubBuf,sizeof(kbSubBuf),"%s",(locationField==LOC_FIELD_NAME)?"Shown in the header":"Decimal degrees (negative = S or W)");
  }
  m.kbSub=kbSubBuf;
  m.kbText=keyboardText.c_str();
  m.kbUpper=keyboardUpper;
  m.kbSym=keyboardSymbols;
  m.locName=locationEditName.c_str();
  m.locLat=locationEditLat.c_str();
  m.locLon=locationEditLon.c_str();
  m.status=settingsStatusUntil?settingsStatus.c_str():"";
  m.phase=millis()/1000.0f;
  m.fw=FW_VERSION;
  m.wifiSsid=wifiSsid.c_str();
}

// PIC tab: decode the next photo (or the current one on a plain redraw) above the
// nav bar, then re-compose only the nav bar on top. Returns false when nothing
// can be shown so render() falls back to the information page.
bool renderPhotoTab(bool advance) {
  int w=gfx->width(), h=gfx->height();
  int areaH=h-UI_NAV_H;
  if(advance || photoIndex<0) photoIndex=(photoIndex+1)%photoCount;   // ordered, wraps
  for(int tries=0; tries<photoCount; ++tries) {
    if(showJpegFit(photoFiles[photoIndex], areaH)) {
      UiModel m;
      buildModel(m);
      uiRenderRegion(w,h,m,Rect{0,uiNavTop(h),w,UI_NAV_H});
      photoShowing=true;
      lastWeatherPageCycle=millis();          // full dwell time starts when the photo appears
      return true;
    }
    photoIndex=(photoIndex+1)%photoCount;     // skip a bad file
  }
  photoAllFailed=true;
  photoShowing=false;
  Serial.println("Photo: no displayable photos; PIC tab removed from the cycle");
  return false;
}

void render() {
  // V4: the band compositor writes every pixel exactly once, so there is no
  // fillScreen() pre-clear (that was the source of the old page-change flash).
  bool entering=(page!=lastRenderedPage);
  if(page==PAGE_PHOTO && !sdReady && photoCount==0 && !bleMouse.isStarted()) {
    Serial.println("Photos page: initializing SD on demand");
    initSD();
  }
  if(page==PAGE_PHOTO && sdReady && photoCount>0 && !photoAllFailed) {
    if(renderPhotoTab(entering)) {
      lastRenderedPage=page;
      pageDirty=false;
      return;
    }
  }
  photoShowing=false;
  UiModel m;
  buildModel(m);
  if(!uiRenderPage(gfx->width(),gfx->height(),m)) {
    Serial.printf("Render: band buffer allocation failed; heap=%u\n", ESP.getFreeHeap());
  }
  if(page==PAGE_SETTINGS && settingsView==SETTINGS_WIFI_LIST) {
    Serial.println("WiFi list render complete");
  }
  lastRenderedPage=page;
  pageDirty=false;
}

// Animate only the weather icon on the NOW page by re-compositing its small
// rectangle. Nothing else on screen is touched, so there is no flicker.
void serviceIconAnimation(uint32_t now) {
#if AURORA_ANIMATE_ICONS
  if(pageDirty || page!=PAGE_NOW || !wx.valid) return;
  if(now-lastIconAnim<ICON_ANIM_MS) return;
  lastIconAnim=now;
  UiModel m;
  buildModel(m);
  int w=gfx->width(), h=gfx->height();
  NowGeo g=nowGeo(w,h);
  uiRenderRegion(w,h,m,g.icon);
#else
  (void)now;
#endif
}

// -----------------------------------------------------------------------------
// BLE mouse jiggler
// -----------------------------------------------------------------------------

void scheduleNextMouseMove(uint32_t now) {
  uint16_t lo=min(mouseMinSec,mouseMaxSec), hi=max(mouseMinSec,mouseMaxSec);
  uint32_t delaySec = (hi>lo) ? (uint32_t)random(lo, (uint32_t)hi+1) : lo;
  nextMouseMoveMs = now + delaySec*1000UL;
}

void serviceBleMouseStart(uint32_t now) {
  if(!mouseEnabled || !bleStartPending || bleMouse.isStarted()) return;
  if((int32_t)(now-bleStartNotBefore) < 0) return;

  bleStartPending=false;
  Serial.printf("BLE mouse: deferred HID start; heap before=%u\n", ESP.getFreeHeap());

  // Mount the SD card while heap is plentiful and the radio is still quiet; a
  // healthy mount then survives BLE (initSD() will not tear it down again).
  if(!sdReady) {
    Serial.println("BLE mouse: mounting SD before BLE init");
    initSD();
  }

  // Put a visible status frame on screen before BLE initialization.
  gfx->invertDisplay(true);
  uiStatusScreen(gfx->width(), gfx->height(), "STARTING MOUSE", "Restoring display after BLE...", "", T_CYAN);
  setBrightness(brightness);
  delay(40);

  bleMouse.begin();
  Serial.printf("BLE mouse: HID started; heap after=%u largest=%u\n", ESP.getFreeHeap(), ESP.getMaxAllocHeap());

  // V3.18.0: BLE controller startup may briefly break the existing STA
  // association. Do not use connectWiFi() here because that intentionally
  // cycles WIFI_OFF, which can make BLE/Wi-Fi coexistence worse. Instead,
  // schedule a soft STA reassociation after BLE is fully up.
  bleWifiRestorePending = true;
  bleWifiRestoreInProgress = false;
  bleWifiRestoreNotBefore = millis() + 1200;
  bleWifiLastCheck = millis();

  // BLE initialization can disturb the software-driven display/touch GPIO
  // state on this CYD. Restore both peripherals before any normal redraw.
  recoverDisplayAndTouch("after BLE HID start");
  gfx->invertDisplay(true);
  scheduleNextMouseMove(millis());
  pageDirty=true;
}

void serviceBleWiFiRestore(uint32_t now) {
  if(!mouseEnabled || !bleMouse.isStarted() || wifiSsid.length()==0) return;

  // Do not interfere with the special Wi-Fi scan/list/password workflow, which
  // intentionally owns the radio and may reboot with WIFI_OFF for TFT safety.
  if(page==PAGE_SETTINGS &&
     (settingsView==SETTINGS_WIFI_SCANNING || settingsView==SETTINGS_WIFI_LIST || settingsView==SETTINGS_KEYBOARD)) return;

  // Low-rate coexistence check only while BLE is active. We deliberately avoid
  // calling WiFi.status() from rendering code, which was unstable on this CYD.
  if(!bleWifiRestorePending && now-bleWifiLastCheck >= 5000) {
    bleWifiLastCheck = now;
    if(WiFi.status() != WL_CONNECTED) {
      wifiConnectedCached = false;
      bleWifiRestorePending = true;
      bleWifiRestoreInProgress = false;
      bleWifiRestoreNotBefore = now + 250;
      Serial.println("BLE/WiFi: STA drop detected; soft reassociation queued");
    } else {
      wifiConnectedCached = true;
    }
  }

  if(!bleWifiRestorePending) return;
  if((int32_t)(now-bleWifiRestoreNotBefore) < 0) return;

  if(!bleWifiRestoreInProgress) {
    if(WiFi.status() == WL_CONNECTED) {
      wifiConnectedCached = true;
      bleWifiRestorePending = false;
      return;
    }

    Serial.printf("BLE/WiFi: soft reassociation to '%s'; heap=%u\n",
                  wifiSsid.c_str(), ESP.getFreeHeap());
    WiFi.setAutoReconnect(false);
    WiFi.mode(WIFI_STA);           // Never cycle WIFI_OFF while BLE is active.
    WiFi.setSleep(false);          // Improve Wi-Fi/BLE coexistence stability.
    WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
    bleWifiRestoreStarted = now;
    bleWifiRestoreInProgress = true;
    return;
  }

  wl_status_t st = WiFi.status();
  if(st == WL_CONNECTED) {
    bleWifiRestorePending = false;
    bleWifiRestoreInProgress = false;
    wifiConnectedCached = true;
    bleWifiLastCheck = now;
    Serial.printf("BLE/WiFi: coexistence restored, IP=%s RSSI=%d\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
    weatherFetchPending = true;
    weatherFetchNotBefore = now + 750;
    recoverDisplayAndTouch("after BLE WiFi reassociation");
    pageDirty = true;
    return;
  }

  if(now-bleWifiRestoreStarted >= 12000) {
    bleWifiRestoreInProgress = false;
    bleWifiRestoreNotBefore = now + 5000;
    wifiConnectedCached = false;
    Serial.printf("BLE/WiFi: reassociation timeout status=%d; retry scheduled\n", (int)st);
  }
}

// Is the PIC tab part of the rotation right now? The SD card is mounted lazily
// here (V3.8 keeps it out of the boot path); a failed mount is retried every 5 min.
bool photoCycleAvailable() {
  if(!photoEnabled || photoAllFailed) return false;
  if(!sdReady) {
    if(bleMouse.isStarted()) return false;     // no room to mount now; it was tried before BLE started
    uint32_t now=millis();
    if(sdProbeNotBefore && (int32_t)(now-sdProbeNotBefore)<0) return false;
    Serial.println("Photo tab: mounting SD for the auto-cycle");
    initSD();
    if(!sdReady) { sdProbeNotBefore=millis()+300000UL; return false; }
  }
  return photoCount>0;
}

// NOW -> 24H -> 7D -> SUN -> TIME -> [PIC] -> NOW ; every tab dwells the same time.
void serviceWeatherPageCycle(uint32_t now) {
  if(page < PAGE_NOW || page > PAGE_PHOTO) {
    lastWeatherPageCycle = now;
    return;
  }
  if(lastWeatherPageCycle == 0) lastWeatherPageCycle = now;
  if(now-lastWeatherPageCycle < WEATHER_PAGE_CYCLE_MS) return;

  Page next;
  if(page == PAGE_TIME) next = photoCycleAvailable() ? PAGE_PHOTO : PAGE_NOW;
  else if(page == PAGE_PHOTO) next = PAGE_NOW;
  else next = (Page)((int)page + 1);

  page = next;
  lastWeatherPageCycle = millis();
  pageDirty = true;
  Serial.printf("Page auto-cycle -> %d\n", (int)page);
}

void serviceMouseJiggler(uint32_t now) {
  if(!mouseEnabled) return;
  // BLE is lazy-started only by the explicit Settings toggle. Never start it
  // from the background service or from setup().
  if(!bleMouse.isStarted()) return;
  if(nextMouseMoveMs==0) scheduleNextMouseMove(now);
  if((int32_t)(now-nextMouseMoveMs) < 0) return;
  if(bleMouse.isConnected()) {
    int magX=random(1,(int)mouseMoveMax+1);
    int magY=random(1,(int)mouseMoveMax+1);
    int8_t dx=(random(0,2)?magX:-magX);
    int8_t dy=(random(0,2)?magY:-magY);
    bleMouse.move(dx,dy,0,0);
    delay(20);
    bleMouse.move(-dx,-dy,0,0); // return near original pointer position
    Serial.printf("Mouse jiggle: %d,%d next=%u-%us\n",dx,dy,mouseMinSec,mouseMaxSec);
  }
  scheduleNextMouseMove(now);
}

// -----------------------------------------------------------------------------
// Setup / loop
// -----------------------------------------------------------------------------

const char* resetReasonName(esp_reset_reason_t r) {
  switch(r) {
    case ESP_RST_POWERON:   return "POWERON";
    case ESP_RST_EXT:       return "EXTERNAL";
    case ESP_RST_SW:        return "SOFTWARE";
    case ESP_RST_PANIC:     return "PANIC";
    case ESP_RST_INT_WDT:   return "INT_WDT";
    case ESP_RST_TASK_WDT:  return "TASK_WDT";
    case ESP_RST_WDT:       return "WDT";
    case ESP_RST_DEEPSLEEP: return "DEEPSLEEP";
    case ESP_RST_BROWNOUT:  return "BROWNOUT";
    case ESP_RST_SDIO:      return "SDIO";
    default:                return "OTHER";
  }
}

void setup() {
  Serial.begin(115200);
  delay(50);
  Serial.printf("Aurora Weather V%s - ESP32-2432S028\n", FW_VERSION);
  delay(150);
  esp_reset_reason_t rr = esp_reset_reason();
  Serial.println();
  Serial.printf("=== Aurora Weather V%s boot ===\n", FW_VERSION);
  Serial.printf("Reset reason: %s (%d)\n", resetReasonName(rr), (int)rr);
  Serial.printf("Free heap at boot: %u bytes\n", ESP.getFreeHeap());
  randomSeed((uint32_t)micros() ^ (uint32_t)analogRead(34));

  pinMode(TOUCH_CLK,OUTPUT); pinMode(TOUCH_MOSI,OUTPUT); pinMode(TOUCH_MISO,INPUT);
  pinMode(TOUCH_CS,OUTPUT); pinMode(TOUCH_IRQ,INPUT);
  digitalWrite(TOUCH_CS,HIGH); digitalWrite(TOUCH_CLK,LOW);

  loadConfig();
  loadTouchCalibration();

  // V3.17.6: BLE HID is intentionally NOT started during boot.
  // First boot after upgrading from V3.17.5 forces the jiggler OFF once so
  // a previously-saved enabled state cannot recreate the SD/TFT startup issue.
  prefs.begin("aurora", false);
  bool bleLazyMigrated = prefs.getBool("blelazy2", false);
  if(!bleLazyMigrated) {
    mouseEnabled = false;
    prefs.putBool("mouse", false);
    prefs.putBool("blelazy2", true);
    Serial.println("BLE mouse: V3.17.8 migration - jiggler forced OFF for clean boot");
  }
  prefs.end();

  nextMouseMoveMs = 0;

  gfx->begin(40000000);
  gfx->setRotation(displayRotation);
  gfx->invertDisplay(true); // V3.17.9: this CYD/ILI9341 panel requires inversion ON for correct colors
  setBrightness(brightness);
  if(!showStartupSplash()) {
    uiStatusScreen(gfx->width(), gfx->height(), "AURORA WEATHER", "ESP32-2432S028", (String("Firmware ")+FW_VERSION).c_str(), T_CYAN);
  }
  // Hold the splash ~3 s with a thin aurora progress bar (was a bare delay(3000)).
  for(int i=1;i<=30;i++) {
    uiSplashProgress(gfx->width(), gfx->height(), FW_VERSION, i/30.0f);
    delay(100);
  }

  if(!touchCal.valid) calibrateTouch();

  // V3.8: defer SD initialization until the Photos page or explicit RESCAN SD.
  sdReady=false;
  photoCount=0;
  WiFi.persistent(false);
  WiFi.setAutoReconnect(false);

  // V3.15: password entry is followed by a one-shot clean reboot before the
  // connection attempt. This avoids the ESP32 Arduino 3.3.x STA state where a
  // previous/automatic connection attempt prevents applying new credentials.
  if (takeWiFiFailureAfterReboot()) {
    // V3.15: a failed connect can leave this CYD display in a state where the
    // first post-Wi-Fi TFT write hangs. Show failure only after a clean reboot.
    WiFi.setAutoReconnect(false);
    WiFi.mode(WIFI_OFF);
    setStatus("Connect failed", 8000);
    page = PAGE_SETTINGS;
    settingsView = SETTINGS_MAIN;
    pageDirty = true;
    Serial.println("Boot: previous WiFi connection failed; radio OFF, showing Settings");
  }
  else if (takePendingWiFiConnectAfterReboot()) {
    WiFi.setAutoReconnect(false);
    WiFi.mode(WIFI_OFF);
    uiStatusScreen(gfx->width(), gfx->height(), "CONNECTING WI-FI", wifiSsid.c_str(), "", T_CYAN, 1);
    Serial.printf("Boot: clean one-shot WiFi connect requested for '%s'\n", wifiSsid.c_str());
    Serial.flush();
    Serial.printf("Boot: heap before WiFi=%u\n", ESP.getFreeHeap());
    bool ok = connectWiFi(15000);
    Serial.printf("Boot: WiFi routine returned %s; heap=%u\n", ok ? "OK" : "FAIL", ESP.getFreeHeap());
    if (ok) {
      wifiConnectedCached = true;
      setStatus("Connected");

      // V3.16.7: recover both software-SPI peripherals after Wi-Fi association.
      recoverDisplayAndTouch("after WiFi association");

      // V3.16.2: prove the TFT/backlight survived Wi-Fi association before
      // starting TLS/HTTP. If weather networking later stalls, this status
      // screen remains visible instead of appearing as a blank/dead display.
      setBrightness(brightness);
      { String ipStr = WiFi.localIP().toString();
        uiStatusScreen(gfx->width(), gfx->height(), "WI-FI CONNECTED", wifiSsid.c_str(), ipStr.c_str(), T_TEAL, 2, "Loading weather..."); }
      Serial.println("[DISPLAY] Connected/loading screen drawn");

      page=PAGE_NOW;
      pageDirty=false;
      weatherLast=0;
      weatherFetchPending=true;
      weatherFetchNotBefore=millis()+750;
      startClockFromCachedTimezone();
      if(!timeSyncConfigured) timezoneResolveNotBefore=millis()+1000;
    } else {
      wifiConnectedCached = false;
      Serial.println("WiFi: connect failed; rebooting to clean failure screen");
      WiFi.mode(WIFI_OFF);
      saveWiFiFailureForCleanBoot();
      Serial.flush();
      delay(150);
      ESP.restart();
    }
  }
  // V3.13 scan reboot path remains: restore scanned SSIDs with radio OFF.
  else if (loadPendingWiFiScanAfterReboot()) {
    Serial.printf("Boot: restored %d scanned network(s); entering WiFi list with radio OFF\n", scanCount);
    Serial.flush();
    WiFi.mode(WIFI_OFF);
    page = PAGE_SETTINGS;
    settingsView = SETTINGS_WIFI_LIST;
    pageDirty = true;
  } else {
    if(connectWiFi()) {
      wifiConnectedCached=true;

      // V3.18.7: a normal cold/power-cycle boot reaches this path rather than
      // the one-shot credential path above. Wi-Fi association and HTTPS can
      // disturb the CYD TFT/XPT2046 software-SPI state, so use the same proven
      // recovery sequence here as the clean one-shot boot path.
      recoverDisplayAndTouch("after normal-boot WiFi association");
      setBrightness(brightness);
      { String ipStr = WiFi.localIP().toString();
        uiStatusScreen(gfx->width(), gfx->height(), "WI-FI CONNECTED", wifiSsid.c_str(), ipStr.c_str(), T_TEAL, 2, "Loading weather..."); }
      Serial.println("[DISPLAY] Normal-boot connected/loading screen drawn");

      startClockFromCachedTimezone();
      bool initialWeatherOk=fetchWeather();
      if(initialWeatherOk) weatherLast=millis();
      Serial.printf("Weather: normal-boot fetch %s; heap=%u\n",
                    initialWeatherOk ? "OK" : "FAILED", ESP.getFreeHeap());

      recoverDisplayAndTouch("after normal-boot HTTPS fetch");
      if(!timeSyncConfigured) timezoneResolveNotBefore=millis()+750;
    }
    else wifiConnectedCached=false;
    page=PAGE_NOW;
    pageDirty=true;
  }

  lastWeatherPageCycle=millis();

  // If the jiggler was already enabled before reboot, defer BLE until all
  // splash, Wi-Fi, display and touch startup work is complete.
  if(mouseEnabled && !bleMouse.isStarted()) {
    bleStartPending=true;
    bleStartNotBefore=millis()+3000;
    Serial.println("BLE mouse: enabled in saved settings; deferred until post-boot idle");
  }
}

void loop() {
  uint32_t now=millis();

  // V3.17: low-rate production heartbeat plus touch IRQ edge logging.
  // This does not call the Wi-Fi driver; it only samples the XPT2046 IRQ GPIO.
  loopHeartbeatCount++;
  int touchIrqNow=digitalRead(TOUCH_IRQ);
  if(touchIrqNow != lastTouchIrqState) {
    Serial.printf("Touch IRQ -> %d at %u ms\n", touchIrqNow, now);
    lastTouchIrqState=touchIrqNow;
  }
  if(now-loopHeartbeatLast >= 10000) {
    loopHeartbeatLast=now;
    Serial.printf("Loop: alive count=%u page=%d wifiCached=%d irq=%d heap=%u\n",
                  loopHeartbeatCount, (int)page, wifiConnectedCached ? 1 : 0,
                  touchIrqNow, ESP.getFreeHeap());
  }

  TouchPoint p=readTouch();
  if(p.touched) {
    Serial.printf("Touch: x=%d y=%d raw=%d,%d page=%d\n",
                  p.x,p.y,p.rawX,p.rawY,(int)page);
    handleTouch(p);
  }

  serviceWiFiScan();
  serviceBleMouseStart(now);
  serviceBleWiFiRestore(now);
  serviceMouseJiggler(now);
  serviceWeatherPageCycle(now);
  if(page==PAGE_TIME) {
    time_t clockNow=time(nullptr);
    if(clockNow >= 1700000000) {
      struct tm ti; localtime_r(&clockNow,&ti);
      if(ti.tm_min != lastClockMinute) { lastClockMinute=ti.tm_min; pageDirty=true; }
    }
  } else {
    lastClockMinute=-1;
  }

  // V3.15: Suspend background Wi-Fi reconnect/weather network activity while
  // the user is scanning/selecting/typing credentials in Wi-Fi Settings.
  bool wifiUiBusy = (page==PAGE_SETTINGS && settingsView!=SETTINGS_MAIN);

  // V3.18.5: clock sync is independent of weather success.
  if(!wifiUiBusy && wifiConnectedCached && !timeSyncConfigured &&
     (timezoneResolveNotBefore==0 || (int32_t)(now-timezoneResolveNotBefore)>=0)) {
    if(timezoneName.length()) {
      startClockFromCachedTimezone();
    } else {
      bool tzOk=resolveTimezoneAndStartClock();
      if(!tzOk) {
        timezoneResolveNotBefore=millis()+TIMEZONE_RETRY_MS;
        Serial.printf("Time: timezone resolve failed; retry in %lu sec\n", TIMEZONE_RETRY_MS/1000UL);
      } else {
        timezoneResolveNotBefore=0;
      }
    }
  }

  // V3.15: no background Wi-Fi reconnect attempts. Reconfiguration occurs
  // only through the explicit one-shot connect-on-clean-boot path above.
  if(!wifiUiBusy && weatherFetchPending && wifiConnectedCached &&
     (int32_t)(now-weatherFetchNotBefore)>=0) {
    weatherFetchPending=false;
    Serial.println("Weather: starting deferred first fetch");
    bool ok=fetchWeather();
    Serial.printf("Weather: deferred fetch %s; heap=%u\n", ok ? "OK" : "FAILED", ESP.getFreeHeap());
    if(ok) weatherLast=millis();

    // V3.16.7: network/TLS can leave both software-SPI peripherals electrically
    // alive but non-functional (blank TFT and XPT2046 reads of 0,0). Restore the
    // display controller and touch GPIO interface together before page redraw.
    recoverDisplayAndTouch("after first HTTPS fetch");
    pageDirty=true;
  }
  else if(!wifiUiBusy && wifiConnectedCached && weatherLast!=0 &&
          now-weatherLast>WEATHER_REFRESH_MS &&
          (weatherRetryNotBefore==0 || (int32_t)(now-weatherRetryNotBefore)>=0)) {
    Serial.printf("Weather: periodic refresh due; heap=%u\n", ESP.getFreeHeap());
    bool ok = fetchWeather();
    uint32_t finished = millis();
    if(ok) {
      weatherLast = finished;
      weatherRetryNotBefore = 0;
      pageDirty = true;
      Serial.printf("Weather: periodic refresh OK; heap=%u\n", ESP.getFreeHeap());
    } else {
      // Never retry a failed HTTPS request every loop. With BLE active that
      // caused continuous full-screen redraws and visible flashing.
      weatherRetryNotBefore = finished + WEATHER_RETRY_MS;
      Serial.printf("Weather: periodic refresh FAILED; retry in %lu sec; heap=%u\n",
                    WEATHER_RETRY_MS/1000UL, ESP.getFreeHeap());
    }
  }

  // Status text in the header clears itself after a few seconds.
  if(settingsStatusUntil && (int32_t)(now-settingsStatusUntil)>=0) {
    settingsStatusUntil=0;
    settingsStatus="";
    if(page==PAGE_SETTINGS) pageDirty=true;
  }

  // Direct-to-TFT rendering is intentionally event-driven. Redrawing the whole
  // 320x240 screen several times per second causes visible flashing on this
  // no-PSRAM board. Pages redraw only when content or navigation changes.
  if(pageDirty){
    lastRender=now;
    Serial.printf("Render: begin page=%d heap=%u\n", (int)page, ESP.getFreeHeap());
    render();
    // V3.16.5: reassert PWM after the redraw. This is intentionally redundant
    // while isolating a visual-only blank-screen condition.
    setBrightness(brightness);
    Serial.printf("Render: complete page=%d heap=%u backlight=%u%%\n", (int)page, ESP.getFreeHeap(), brightness);
  }
  else serviceIconAnimation(now);
  delay(8);
}
