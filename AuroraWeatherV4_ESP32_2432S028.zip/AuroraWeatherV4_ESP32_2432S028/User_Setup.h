#define USER_SETUP_INFO "CYD ESP32-2432S028 TPM408-2.8 inverted"

#define ILI9341_2_DRIVER     // Most TPM408 / classic CYD boards
// #define ST7789_DRIVER     // Uncomment only if ILI9341_2 fails (white screen)

#define TFT_WIDTH  240
#define TFT_HEIGHT 320

#define TFT_MISO 12
#define TFT_MOSI 13
#define TFT_SCLK 14
#define TFT_CS   15
#define TFT_DC    2
#define TFT_RST  -1          // Many boards have no dedicated RST

#define TFT_BL   21
#define TFT_BACKLIGHT_ON HIGH

#define TFT_RGB_ORDER TFT_BGR
#define TFT_INVERSION_ON       // Required for inverted TPM408-2.8 panels

#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define SMOOTH_FONT

#define SPI_FREQUENCY  40000000
#define SPI_READ_FREQUENCY  16000000
#define SPI_TOUCH_FREQUENCY  2500000

#define USE_HSPI_PORT
