#pragma once
/*
 * AuroraIcons.h - resolution-independent weather and UI icons drawn with
 * signed-distance shapes through AuroraGfx.h.  Nothing is stored as bitmaps.
 */
#include "AuroraGfx.h"

// ----------------------------------------------------------------------------
// Signed-distance helpers (local units, negative inside)
// ----------------------------------------------------------------------------
static inline float sdCircle(float x, float y, float cx, float cy, float r) {
  float dx = x - cx, dy = y - cy; return sqrtf(dx * dx + dy * dy) - r;
}
static inline float sdBox(float x, float y, float cx, float cy, float hx, float hy, float r) {
  float dx = fabsf(x - cx) - (hx - r), dy = fabsf(y - cy) - (hy - r);
  float ax = fmaxf(dx, 0), ay = fmaxf(dy, 0);
  return sqrtf(ax * ax + ay * ay) + fminf(fmaxf(dx, dy), 0) - r;
}
static inline float sminf(float a, float b, float k) {
  float h = fmaxf(k - fabsf(a - b), 0) / k; return fminf(a, b) - h * h * k * 0.25f;
}

// ----------------------------------------------------------------------------
// Shapes
// ----------------------------------------------------------------------------
static inline float cloudSD(float u, float v) {          // local units, ~80 wide
  float d = sdCircle(u, v, -14, 2, 12);
  d = sminf(d, sdCircle(u, v, 4, -6, 16), 5);
  d = sminf(d, sdCircle(u, v, 21, 3, 11), 5);
  d = sminf(d, sdBox(u, v, 0, 9, 27, 7, 7), 5);
  return d;
}

// Cloud with vertical gradient; 'expand' grows the shape (used for soft shadows).
static void cloudShape(Canvas &c, float cx, float cy, float s, Col top, Col bot, uint8_t a = 255, float expand = 0) {
  int xa = (int)floorf(cx - (42 + expand) * s), xb = (int)ceilf(cx + (42 + expand) * s);
  int ya = (int)floorf(cy - (24 + expand) * s), yb = (int)ceilf(cy + (18 + expand) * s);
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  for (int py = ya; py < yb; ++py) {
    float v = ((float)py + 0.5f - cy) / s;
    Col col = lerpCol(top, bot, (v + 20.0f) / 38.0f);
    for (int px = xa; px < xb; ++px) {
      float u = ((float)px + 0.5f - cx) / s;
      float d = cloudSD(u, v) * s - expand;
      float cov = clamp01(0.5f - d);
      if (cov > 0) blendPixD(c, px, py, col.r, col.g, col.b, (int)(cov * a));
    }
  }
}

static void sunShape(Canvas &c, float cx, float cy, float r, float t, float glowK = 1.0f) {
  glow(c, cx, cy, r * 0.8f, r * 2.7f, mk(255, 196, 70), 0.42f * glowK);
  for (int i = 0; i < 8; ++i) {
    float a = t * 0.35f + i * 0.78539816f;
    float r0 = r * 1.32f, r1 = r * ((i & 1) ? 1.62f : 1.86f);
    capsule(c, cx + cosf(a) * r0, cy + sinf(a) * r0, cx + cosf(a) * r1, cy + sinf(a) * r1,
            r * 0.19f, mk(255, 213, 96), 235);
  }
  discV(c, cx, cy, r, mk(255, 232, 130), mk(255, 168, 58));
  disc(c, cx - r * 0.28f, cy - r * 0.32f, r * 0.42f, mk(255, 248, 200), 70);   // soft highlight
}

static void moonShape(Canvas &c, float cx, float cy, float r) {
  glow(c, cx, cy, r * 0.9f, r * 2.4f, mk(150, 175, 255), 0.22f);
  int xa = (int)floorf(cx - r - 2), xb = (int)ceilf(cx + r + 2), ya = (int)floorf(cy - r - 2), yb = (int)ceilf(cy + r + 2);
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  float cx2 = cx + r * 0.50f, cy2 = cy - r * 0.34f, r2 = r * 0.84f;
  for (int py = ya; py < yb; ++py) {
    Col col = lerpCol(mk(244, 248, 255), mk(176, 194, 232), ((float)py - (cy - r)) / (2 * r));
    for (int px = xa; px < xb; ++px) {
      float x = (float)px + 0.5f, y = (float)py + 0.5f;
      float d = fmaxf(sdCircle(x, y, cx, cy, r), -sdCircle(x, y, cx2, cy2, r2));
      float cov = clamp01(0.5f - d);
      if (cov > 0) blendPixD(c, px, py, col.r, col.g, col.b, (int)(cov * 255));
    }
  }
}

static void sparkle(Canvas &c, float x, float y, float r, uint8_t a) {
  capsule(c, x - r, y, x + r, y, 1.0f, mk(220, 232, 255), a);
  capsule(c, x, y - r, x, y + r, 1.0f, mk(220, 232, 255), a);
  disc(c, x, y, 0.9f, mk(255, 255, 255), a);
}

static void rainDrops(Canvas &c, float x0, float y0, int n, float pitch, float len, float s, float t,
                      Col col, uint8_t a) {
  float travel = len * 2.4f;
  for (int i = 0; i < n; ++i) {
    float ph = fmodf(t * 22.0f * s + i * (travel * 0.37f), travel);
    float k = ph / travel;
    float al = (k < 0.15f ? k / 0.15f : (k > 0.8f ? (1.0f - k) / 0.2f : 1.0f));
    float x = x0 + i * pitch - ph * 0.30f, y = y0 + ph + ((i & 1) ? len * 0.5f : 0);
    capsule(c, x, y, x - len * 0.30f, y + len, 1.9f * s + 0.4f, col, (uint8_t)(a * clamp01(al)));
  }
}
static void snowFlakes(Canvas &c, float x0, float y0, int n, float pitch, float s, float t, uint8_t a) {
  float travel = 17.0f * s;
  for (int i = 0; i < n; ++i) {
    float ph = fmodf(t * 8.0f * s + i * 4.3f * s, travel);
    float k = ph / travel;
    float al = (k < 0.15f ? k / 0.15f : (k > 0.8f ? (1.0f - k) / 0.2f : 1.0f));
    float x = x0 + i * pitch + sinf(t * 1.4f + i * 1.7f) * 1.6f * s, y = y0 + ph + ((i & 1) ? 5 * s : 0);
    disc(c, x, y, 2.3f * s + 0.4f, mk(236, 246, 255), (uint8_t)(a * clamp01(al)));
  }
}
static void boltShape(Canvas &c, float cx, float cy, float s, uint8_t a) {
  float A[8] = {cx + 3 * s, cy - 11 * s, cx + 10 * s, cy - 11 * s, cx + 4 * s, cy - 1 * s, cx - 3 * s, cy - 1 * s};
  float B[6] = {cx - 3 * s, cy - 2 * s, cx + 8 * s, cy - 2 * s, cx - 2 * s, cy + 13 * s};
  glow(c, cx + 3 * s, cy, 4 * s, 18 * s, mk(255, 210, 90), 0.30f * a / 255.0f);
  fillPoly(c, A, 4, mk(255, 222, 96), a);
  fillPoly(c, B, 3, mk(255, 214, 80), a);
}

// ----------------------------------------------------------------------------
// Weather icon: WMO weather_code -> composed scene. size = nominal box in px.
// t is an animation clock in seconds (0 => static pose).
// ----------------------------------------------------------------------------
static const Col CLOUD_LT  = mk(250, 252, 255), CLOUD_LB  = mk(176, 198, 228);
static const Col CLOUD_GT  = mk(214, 224, 240), CLOUD_GB  = mk(132, 152, 182);
static const Col CLOUD_ST  = mk(150, 160, 194), CLOUD_SB  = mk(86, 96, 132);
static const Col SHADOW    = mk(8, 16, 34);

static void cloudWithShadow(Canvas &c, float cx, float cy, float s, Col t, Col b) {
  cloudShape(c, cx, cy + 2.0f * s, s, SHADOW, SHADOW, 70, 3.0f * s);
  cloudShape(c, cx, cy, s, t, b, 255);
}

static void weatherIcon(Canvas &c, int code, bool day, float cx, float cy, float size, float t = 0) {
  const float s = size / 64.0f;
  const float drift = sinf(t * 0.7f) * 1.6f * s;
  const bool thunder = code >= 95;
  const bool snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
  const bool rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
  const bool fog = (code == 45 || code == 48);

  if (code == 0) {
    if (day) sunShape(c, cx, cy, 17 * s, t);
    else {
      moonShape(c, cx - 1 * s, cy, 18 * s);
      sparkle(c, cx + 20 * s, cy - 14 * s, 3.6f * s, (uint8_t)(150 + 100 * sinf(t * 2.0f)));
      sparkle(c, cx + 12 * s, cy + 18 * s, 2.4f * s, (uint8_t)(150 + 100 * sinf(t * 2.7f + 1)));
      sparkle(c, cx - 22 * s, cy - 16 * s, 2.2f * s, (uint8_t)(150 + 100 * sinf(t * 1.6f + 2)));
    }
    return;
  }
  if (code == 1) {
    if (day) sunShape(c, cx - 5 * s, cy - 5 * s, 16 * s, t); else moonShape(c, cx - 5 * s, cy - 5 * s, 17 * s);
    cloudWithShadow(c, cx + 13 * s + drift, cy + 12 * s, 0.50f * s, CLOUD_LT, CLOUD_LB);
    return;
  }
  if (code == 2) {
    if (day) sunShape(c, cx - 12 * s, cy - 11 * s, 14 * s, t); else moonShape(c, cx - 14 * s, cy - 13 * s, 14 * s);
    cloudWithShadow(c, cx + 5 * s + drift, cy + 7 * s, 0.80f * s, CLOUD_LT, CLOUD_LB);
    return;
  }
  if (code == 3) {
    cloudWithShadow(c, cx - 13 * s - drift, cy - 8 * s, 0.56f * s, CLOUD_GT, CLOUD_GB);
    cloudWithShadow(c, cx + 3 * s + drift, cy + 5 * s, 0.86f * s, CLOUD_LT, CLOUD_LB);
    return;
  }
  // Everything else sits under a cloud deck.
  Col top = CLOUD_GT, bot = CLOUD_GB;
  if (thunder) { top = CLOUD_ST; bot = CLOUD_SB; }
  if (fog) { top = CLOUD_LT; bot = CLOUD_LB; }
  float ccy = cy - (fog ? 10 : 8) * s;
  if ((code >= 80 && code <= 82) && day) sunShape(c, cx - 14 * s, cy - 18 * s, 10 * s, t, 0.6f);
  cloudWithShadow(c, cx + drift, ccy, 0.88f * s, top, bot);
  float dropY = cy + 11 * s;
  if (fog) {
    float lw[3] = {44, 36, 28};
    for (int i = 0; i < 3; ++i)
      capsule(c, cx - lw[i] * 0.5f * s + sinf(t * 0.8f + i) * 2 * s, cy + (10 + i * 8) * s,
              cx + lw[i] * 0.5f * s + sinf(t * 0.8f + i) * 2 * s, cy + (10 + i * 8) * s, 3.4f * s, mk(188, 204, 228), (uint8_t)(235 - i * 40));
  } else if (thunder) {
    boltShape(c, cx - 2 * s, cy + 15 * s, 1.0f * s, 255);
    if (code >= 96 || true) rainDrops(c, cx - 22 * s, dropY + 2 * s, 2, 6 * s, 7 * s, s, t, mk(110, 184, 255), 200);
  } else if (snow) {
    snowFlakes(c, cx - 20 * s, dropY, 5, 10 * s, s, t, 240);
  } else if (rain) {
    int n = (code == 51 || code == 53 || code == 61 || code == 80) ? 3 : 4;
    float len = (code <= 55) ? 6.0f : 8.5f;
    rainDrops(c, cx - 18 * s, dropY, n, (36.0f / n) * s + 2 * s, len * s, s, t, mk(96, 182, 255), 245);
  }
}

// ----------------------------------------------------------------------------
// Small UI glyphs (single colour, ~12-16 px)
// ----------------------------------------------------------------------------
static void iconWifi(Canvas &c, float cx, float cy, Col col, uint8_t a = 255) {
  const float A0 = 0.7854f, A1 = 2.3562f;    // 45..135 degrees
  for (int i = 0; i < 3; ++i)
    arcStroke(c, cx, cy + 4.5f, 3.4f + i * 3.2f, A1, A0, 1.55f, col, col, a);
  disc(c, cx, cy + 4.5f, 1.25f, col, a);
}
static void iconPin(Canvas &c, float cx, float cy, Col col, Col hole) {
  disc(c, cx, cy - 1.0f, 3.9f, col);
  float tri[6] = {cx - 3.2f, cy + 1.2f, cx + 3.2f, cy + 1.2f, cx, cy + 6.4f};
  fillPoly(c, tri, 3, col);
  disc(c, cx, cy - 1.0f, 1.5f, hole);
}
static void iconDrop(Canvas &c, float cx, float cy, float r, Col col, uint8_t a = 255) {
  float tri[6] = {cx, cy - r * 1.75f, cx - r * 0.93f, cy - r * 0.30f, cx + r * 0.93f, cy - r * 0.30f};
  fillPoly(c, tri, 3, col, a);
  disc(c, cx, cy + r * 0.1f, r, col, a);
}
static void iconWind(Canvas &c, float cx, float cy, Col col) {
  capsule(c, cx - 6, cy - 3.5f, cx + 3, cy - 3.5f, 1.6f, col);
  capsule(c, cx - 6, cy, cx + 6, cy, 1.6f, col);
  capsule(c, cx - 6, cy + 3.5f, cx + 1, cy + 3.5f, 1.6f, col);
  arcStroke(c, cx + 3, cy - 5.5f, 2.0f, 2.8f, -1.6f, 1.5f, col, col);
}
static void iconGauge(Canvas &c, float cx, float cy, Col col) {
  arcStroke(c, cx, cy + 3, 6.2f, 3.4f, -0.26f, 1.6f, col, col);
  capsule(c, cx, cy + 3, cx + 2.8f, cy - 2.2f, 1.5f, col);
  disc(c, cx, cy + 3, 1.3f, col);
}
static void iconSun(Canvas &c, float cx, float cy, Col col, float r = 3.2f) {
  disc(c, cx, cy, r, col);
  for (int i = 0; i < 8; ++i) {
    float a = i * 0.7854f;
    capsule(c, cx + cosf(a) * (r + 1.8f), cy + sinf(a) * (r + 1.8f), cx + cosf(a) * (r + 3.6f), cy + sinf(a) * (r + 3.6f), 1.3f, col);
  }
}
static void iconClock(Canvas &c, float cx, float cy, Col col, float r = 6.0f) {
  ring(c, cx, cy, r, col, 255, 1.5f);
  capsule(c, cx, cy, cx, cy - r * 0.62f, 1.4f, col);
  capsule(c, cx, cy, cx + r * 0.45f, cy + r * 0.2f, 1.4f, col);
}
static void iconArrow(Canvas &c, float cx, float cy, float deg, float len, Col col) {
  // arrow pointing towards compass bearing 'deg' (0 = up/north)
  float a = deg * 0.0174533f, sx = sinf(a), sy = -cosf(a);
  float tx = cx + sx * len, ty = cy + sy * len, bx = cx - sx * len * 0.9f, by = cy - sy * len * 0.9f;
  capsule(c, bx, by, tx, ty, 1.7f, col);
  float px = -sy, py = sx, hl = len * 0.62f;
  float head[6] = {tx + sx * 1.6f, ty + sy * 1.6f, tx - sx * hl + px * hl * 0.62f, ty - sy * hl + py * hl * 0.62f,
                   tx - sx * hl - px * hl * 0.62f, ty - sy * hl - py * hl * 0.62f};
  fillPoly(c, head, 3, col);
}
static void iconCheck(Canvas &c, float cx, float cy, Col col) {
  capsule(c, cx - 4, cy, cx - 1.2f, cy + 3, 1.9f, col);
  capsule(c, cx - 1.2f, cy + 3, cx + 4.4f, cy - 3.2f, 1.9f, col);
}
static void iconSD(Canvas &c, float cx, float cy, Col col, Col hole) {
  // SD card: pentagon with a cut corner and three contact pins
  float a[10] = {cx - 5, cy - 6.5f, cx + 1.5f, cy - 6.5f, cx + 5, cy - 3.0f, cx + 5, cy + 6.5f, cx - 5, cy + 6.5f};
  fillPoly(c, a, 5, col);
  for (int i = 0; i < 3; ++i) fillRect(c, (int)(cx - 2.8f + i * 2.4f), (int)(cy - 5.0f), 1, 3, hole);
}

// Navigation icons: idx 0..6 = NOW 24H 7D SUN TIME PIC SET
static void navIcon(Canvas &c, int idx, float cx, float cy, Col col) {
  switch (idx) {
    case 0: cloudShape(c, cx, cy + 1.5f, 0.205f, col, col, 255); break;
    case 1: {
      float xs[5] = {-6.5f, -3.2f, 0.5f, 3.6f, 6.5f}, ys[5] = {2.5f, 4.0f, -3.0f, -1.0f, -5.0f};
      for (int i = 0; i < 4; ++i) capsule(c, cx + xs[i], cy + ys[i], cx + xs[i + 1], cy + ys[i + 1], 1.7f, col);
      disc(c, cx + xs[4], cy + ys[4], 1.7f, col);
      capsule(c, cx - 7, cy + 7, cx + 7.5f, cy + 7, 1.2f, col, 150);
    } break;
    case 2: {
      for (int i = 0; i < 3; ++i) {
        float h = 5.0f + i * 3.0f;
        fillRRect(c, cx - 7.0f + i * 5.2f, cy + 6.0f - h, 3.8f, h, 1.5f, col);
      }
    } break;
    case 3: {
      arcStroke(c, cx, cy + 3.5f, 5.6f, 3.1416f, 0.0f, 1.7f, col, col);
      capsule(c, cx - 8, cy + 3.5f, cx + 8, cy + 3.5f, 1.5f, col);
      capsule(c, cx, cy - 4.4f, cx, cy - 6.6f, 1.4f, col);
      capsule(c, cx - 5.7f, cy - 2.2f, cx - 7.2f, cy - 3.7f, 1.4f, col);
      capsule(c, cx + 5.7f, cy - 2.2f, cx + 7.2f, cy - 3.7f, 1.4f, col);
    } break;
    case 4: iconClock(c, cx, cy, col, 6.6f); break;
    case 5: {
      strokeRRect(c, cx - 7.5f, cy - 5.5f, 15, 11, 2.2f, col, 255, 1.5f);
      float m[6] = {cx - 5, cy + 3.2f, cx - 1.4f, cy - 1.6f, cx + 1.8f, cy + 3.2f};
      fillPoly(c, m, 3, col);
      float m2[6] = {cx, cy + 3.2f, cx + 3.0f, cy - 0.6f, cx + 6, cy + 3.2f};
      fillPoly(c, m2, 3, col);
      disc(c, cx + 3.6f, cy - 2.6f, 1.3f, col);
    } break;
    case 6: {
      for (int i = 0; i < 3; ++i) {
        float y = cy - 5.0f + i * 5.0f;
        capsule(c, cx - 7, y, cx + 7, y, 1.4f, col);
        disc(c, cx + (i == 0 ? -2.5f : (i == 1 ? 3.0f : -0.5f)), y, 2.2f, col);
      }
    } break;
  }
}
