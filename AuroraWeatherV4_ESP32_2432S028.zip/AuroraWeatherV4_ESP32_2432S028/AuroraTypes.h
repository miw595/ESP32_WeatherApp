#pragma once
// Shared data types. Kept in a header so the Arduino IDE's automatic prototype
// generator (and the UI code) always see them before any function using them.
#include <stdint.h>
#include <time.h>

static constexpr int HOURS = 24;
static constexpr int DAYS = 7;

// All text fields are fixed-size char arrays: no heap churn while rendering and
// no String fragmentation on a board that has ~27 KB free once BLE is running.
struct Weather {
  bool valid = false;
  char updated[8] = "--:--";
  float temp = 0;
  float apparent = 0;
  float humidity = 0;
  float wind = 0;
  float pressure = 0;
  float dewpoint = 0;
  float precipProb = 0;
  float uv = 0;
  int code = 0;
  int windDir = 0;
  int isDay = 1;
  int currentMinuteAtFetch = -1;
  int sunriseMinute = 360;
  int sunsetMinute = 1080;
  float hourlyTemp[HOURS] = {};
  int hourlyCode[HOURS] = {};
  int hourlyRainProb[HOURS] = {};
  int hourlyHour[HOURS] = {};
  char dayName[DAYS][6] = {};
  float dayMax[DAYS] = {};
  float dayMin[DAYS] = {};
  float dayUv[DAYS] = {};
  int dayCode[DAYS] = {};
  int dayRain[DAYS] = {};
  char sunrise[DAYS][8] = {};
  char sunset[DAYS][8] = {};
};

enum Page { PAGE_NOW, PAGE_HOURLY, PAGE_DAILY, PAGE_SUN, PAGE_TIME, PAGE_PHOTO, PAGE_SETTINGS };
enum SettingsView { SETTINGS_MAIN, SETTINGS_WIFI_SCANNING, SETTINGS_WIFI_LIST, SETTINGS_KEYBOARD,
                    SETTINGS_LOCATION, SETTINGS_LOCATION_KEYBOARD, SETTINGS_MOUSE };
enum LocationField { LOC_FIELD_NAME, LOC_FIELD_LAT, LOC_FIELD_LON };

// Everything the renderer needs, gathered by the sketch right before drawing.
// The renderer never touches Wi-Fi, NVS, SD or any Arduino object.
struct UiModel {
  const Weather *wx = nullptr;
  Page page = PAGE_NOW;
  SettingsView sview = SETTINGS_MAIN;
  bool wifiOn = false;
  const char *location = "";
  bool fahrenheit = true, mph = true;
  uint8_t rotation = 1, brightness = 65;
  bool photoEnabled = true;        // PIC tab is part of the auto-cycle
  bool mouseEnabled = false, bleConnected = false, sdReady = false;
  int photoCount = 0;
  bool photoFailed = false;        // every photo failed to decode
  int cycleSec = 15;               // dwell time of every tab in the auto-cycle
  int mouseMin = 10, mouseMax = 120, mouseMove = 3;
  // clock
  bool timeValid = false;
  struct tm tm = {};
  const char *tzAbbr = "", *tzName = "";
  int nowMinute = -1;           // minutes since local midnight (best estimate) or -1
  // Wi-Fi list
  int scanCount = 0;
  const char (*ssids)[33] = nullptr;
  const int *rssi = nullptr;
  // keyboard / location editor
  const char *kbTitle = "", *kbSub = "", *kbText = "";
  bool kbUpper = false, kbSym = false;
  const char *locName = "", *locLat = "", *locLon = "";
  const char *status = "";
  float phase = 0;              // animation clock in seconds
  const char *fw = "";
  const char *wifiSsid = "";
};
