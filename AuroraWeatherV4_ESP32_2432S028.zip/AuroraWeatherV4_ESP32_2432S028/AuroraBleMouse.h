#pragma once

#include <Arduino.h>
#include <NimBLEDevice.h>
#include <NimBLEHIDDevice.h>

// Minimal BLE HID mouse wrapper on NimBLE-Arduino 2.x (h2zero).
//
// Why NimBLE: the stock ESP32 BLE library (Bluedroid) left only ~4.5 KB of heap on
// this no-PSRAM board once the mouse was running, which starved Wi-Fi/HTTPS (weather),
// SD access and everything that allocates. NimBLE needs roughly 100 KB less RAM.
//
// The public interface (begin / isStarted / isConnected / move) is unchanged from the
// Bluedroid version, so the sketch only sees a lighter stack.
//
// Requires: "NimBLE-Arduino" by h2zero, version 2.x (Library Manager).
class AuroraBleMouse {
public:
  AuroraBleMouse(const char *deviceName = "Aurora Weather Mouse",
                 const char *manufacturer = "Aurora",
                 uint8_t batteryLevel = 100)
      : _deviceName(deviceName), _manufacturer(manufacturer), _batteryLevel(batteryLevel) {}

  void begin() {
    if (_started) return;

    if (!NimBLEDevice::init(_deviceName)) {
      Serial.println("BLE mouse: NimBLEDevice::init failed");
      return;
    }

    // "Just Works" pairing with bonding and LE Secure Connections, like a normal BLE mouse.
    // The HID input report is READ_ENC, so the host encrypts the link and pairs on first use.
    NimBLEDevice::setSecurityAuth(true, false, true);
    NimBLEDevice::setSecurityIOCap(BLE_HS_IO_NO_INPUT_OUTPUT);

    _server = NimBLEDevice::createServer();
    if (!_server) {
      Serial.println("BLE mouse: createServer failed");
      return;
    }
    _callbacks.owner = this;
    _server->setCallbacks(&_callbacks, false);     // false: the callbacks are a member, the library must not delete them
    _server->advertiseOnDisconnect(true);          // restart advertising by itself after a disconnect

    _hid = new NimBLEHIDDevice(_server);
    _hid->setManufacturer(_manufacturer);
    _hid->setPnp(0x02, 0x303A, 0x4001, 0x0100);
    _hid->setHidInfo(0x00, 0x01);
    _hid->setReportMap((uint8_t *)_reportMap, sizeof(_reportMap));
    _input = _hid->getInputReport(1);              // report ID 1 (matches the report map)
    _hid->setBatteryLevel(_batteryLevel);

    NimBLEAdvertising *adv = NimBLEDevice::getAdvertising();
    adv->setName(_deviceName);
    adv->setAppearance(HID_MOUSE);
    adv->addServiceUUID(_hid->getHidService()->getUUID());
    adv->enableScanResponse(true);
    adv->setPreferredParams(0x06, 0x12);
    if (!adv->start()) {                           // also starts the GATT server
      Serial.println("BLE mouse: advertising start failed");
      return;
    }

    _started = true;
    Serial.println("BLE mouse: NimBLE HID ready as 'Aurora Weather Mouse'");
  }

  bool isStarted() const { return _started; }
  bool isConnected() const { return _connected; }

  void move(int8_t x, int8_t y, int8_t wheel = 0, int8_t horizontalWheel = 0) {
    (void)horizontalWheel; // Not needed by Aurora's jiggler.
    if (!_started || !_connected || _input == nullptr) return;

    // HID-over-GATT: the Report ID lives in the Report Reference descriptor, so the
    // notification payload is only the report body (buttons, x, y, wheel = 4 bytes).
    MouseReport report = {0, x, y, wheel};
    _input->notify((const uint8_t *)&report, sizeof(report));
  }

private:
  struct __attribute__((packed)) MouseReport {
    uint8_t buttons;
    int8_t x;
    int8_t y;
    int8_t wheel;
  };

  class Callbacks : public NimBLEServerCallbacks {
  public:
    AuroraBleMouse *owner = nullptr;
    void onConnect(NimBLEServer *server, NimBLEConnInfo &connInfo) override {
      (void)server; (void)connInfo;
      if (owner) owner->_connected = true;
      Serial.println("BLE mouse: connected");
    }
    void onDisconnect(NimBLEServer *server, NimBLEConnInfo &connInfo, int reason) override {
      (void)server; (void)connInfo;
      if (owner) owner->_connected = false;
      Serial.printf("BLE mouse: disconnected (reason %d); advertising restarts automatically\n", reason);
    }
  };

  const char *_deviceName;
  const char *_manufacturer;
  uint8_t _batteryLevel;
  bool _started = false;
  volatile bool _connected = false;
  NimBLEServer *_server = nullptr;
  NimBLEHIDDevice *_hid = nullptr;
  NimBLECharacteristic *_input = nullptr;
  Callbacks _callbacks;

  // Relative 3-button mouse: X, Y and vertical wheel.
  inline static const uint8_t _reportMap[] = {
    0x05, 0x01,       // Usage Page (Generic Desktop)
    0x09, 0x02,       // Usage (Mouse)
    0xA1, 0x01,       // Collection (Application)
    0x85, 0x01,       //   Report ID (1)
    0x09, 0x01,       //   Usage (Pointer)
    0xA1, 0x00,       //   Collection (Physical)
    0x05, 0x09,       //     Usage Page (Button)
    0x19, 0x01,       //     Usage Minimum (Button 1)
    0x29, 0x03,       //     Usage Maximum (Button 3)
    0x15, 0x00,       //     Logical Minimum (0)
    0x25, 0x01,       //     Logical Maximum (1)
    0x95, 0x03,       //     Report Count (3)
    0x75, 0x01,       //     Report Size (1)
    0x81, 0x02,       //     Input (Data, Variable, Absolute)
    0x95, 0x01,       //     Report Count (1)
    0x75, 0x05,       //     Report Size (5)
    0x81, 0x03,       //     Input (Constant, Variable, Absolute)
    0x05, 0x01,       //     Usage Page (Generic Desktop)
    0x09, 0x30,       //     Usage (X)
    0x09, 0x31,       //     Usage (Y)
    0x09, 0x38,       //     Usage (Wheel)
    0x15, 0x81,       //     Logical Minimum (-127)
    0x25, 0x7F,       //     Logical Maximum (127)
    0x75, 0x08,       //     Report Size (8)
    0x95, 0x03,       //     Report Count (3)
    0x81, 0x06,       //     Input (Data, Variable, Relative)
    0xC0,             //   End Collection
    0xC0              // End Collection
  };
};
