#pragma once
/*
 * AuroraGfx.h - small anti-aliased 2D renderer for RAM-limited LCDs.
 *
 * Why this exists
 * ---------------
 * The ESP32-2432S028 has no PSRAM, so a full 320x240 framebuffer (150 KB) is
 * not an option, and drawing straight to the panel with fillScreen() + overdraw
 * flashes visibly.  Instead every page is described by a draw function which is
 * executed once per horizontal "band" (typically 16-19 rows).  Each band is
 * composed in a ~12 KB RAM buffer - gradients, anti-aliased shapes, alpha
 * blended text - and pushed to the LCD exactly once.  Every pixel on the panel
 * is written once per page change: no flicker, no tearing, no overdraw cost.
 *
 * The code is hardware independent.  The including file must define
 *     AURORA_FLUSH(x, y, w, h, pixels)   // push native-endian RGB565 block
 * before including this header (the sketch maps it to gfx->draw16bitRGBBitmap).
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "AuroraFonts.h"

#ifndef AURORA_FLUSH
#error "Define AURORA_FLUSH(x,y,w,h,pixels) before including AuroraGfx.h"
#endif
#ifndef AURORA_ALLOC
#define AURORA_ALLOC(n) malloc(n)
#define AURORA_FREE(p)  free(p)
#endif
#ifndef AURORA_BAND_BYTES
#define AURORA_BAND_BYTES 12288      // preferred band buffer size
#endif
// Largest block currently allocatable. The sketch maps this to ESP.getMaxAllocHeap();
// the band never takes more than a third of it, so a nearly full heap (BLE mouse
// running) keeps headroom for Strings, file handles and Wi-Fi.
#ifndef AURORA_MAX_ALLOC
#define AURORA_MAX_ALLOC() ((size_t)0x40000000)
#endif

// -----------------------------------------------------------------------------
// Colour helpers
// -----------------------------------------------------------------------------
struct Col { uint8_t r, g, b; };
static inline constexpr Col mk(uint8_t r, uint8_t g, uint8_t b) { return Col{r, g, b}; }

static inline uint16_t to565(Col c) {
  return (uint16_t)(((c.r & 0xF8) << 8) | ((c.g & 0xFC) << 3) | (c.b >> 3));
}
static inline Col lerpCol(Col a, Col b, float t) {
  if (t < 0) t = 0;
  if (t > 1) t = 1;
  int k = (int)(t * 256.0f);
  return Col{(uint8_t)(a.r + (((int)b.r - a.r) * k >> 8)),
             (uint8_t)(a.g + (((int)b.g - a.g) * k >> 8)),
             (uint8_t)(a.b + (((int)b.b - a.b) * k >> 8))};
}
static inline float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
static inline float smoothstep(float a, float b, float x) {
  float t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
}

// 4x4 ordered dither: removes the banding RGB565 gradients otherwise show.
static const uint8_t AG_BAYER4[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
static inline uint16_t pack565d(int r, int g, int b, int x, int y) {
  int m = AG_BAYER4[((y & 3) << 2) | (x & 3)];
  r += (m >> 1) - 3; g += (m >> 2) - 1; b += (m >> 1) - 3;
  r = r < 0 ? 0 : (r > 255 ? 255 : r);
  g = g < 0 ? 0 : (g > 255 ? 255 : g);
  b = b < 0 ? 0 : (b > 255 ? 255 : b);
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}
static inline void expand565(uint16_t p, int &r, int &g, int &b) {
  r = (p >> 8) & 0xF8; r |= r >> 5;
  g = (p >> 3) & 0xFC; g |= g >> 6;
  b = (p << 3) & 0xF8; b |= b >> 5;
}
// Fast RGB565 blend, a5 = 0..32
static inline uint16_t mix565(uint16_t bg, uint16_t fg, uint32_t a5) {
  uint32_t b = (bg | ((uint32_t)bg << 16)) & 0x07E0F81Fu;
  uint32_t f = (fg | ((uint32_t)fg << 16)) & 0x07E0F81Fu;
  uint32_t r = (((f - b) * a5 >> 5) + b) & 0x07E0F81Fu;
  return (uint16_t)(r | (r >> 16));
}

// -----------------------------------------------------------------------------
// Canvas: the band currently being composed
// -----------------------------------------------------------------------------
struct Canvas {
  uint16_t *buf;       // band pixels, row stride = w
  int ox, w;           // region origin x / width (screen coordinates)
  int y0, y1;          // rows [y0,y1) held in buf
  int W, H;            // full screen size (for layout)
  int kx0, kx1, ky0, ky1;   // active clip rect (defaults to the band; see ClipScope)
  inline uint16_t *at(int x, int y) const { return buf + (size_t)(y - y0) * w + (x - ox); }
  inline bool hitsY(int ya, int yb) const { return yb > ky0 && ya < ky1; }
};
// Temporarily confine drawing to a rectangle (e.g. keep a glow inside its card).
struct ClipScope {
  Canvas &c; int a, b, d, e;
  ClipScope(Canvas &cv, int x, int y, int w, int h) : c(cv), a(cv.kx0), b(cv.kx1), d(cv.ky0), e(cv.ky1) {
    if (x > c.kx0) c.kx0 = x;
    if (x + w < c.kx1) c.kx1 = x + w;
    if (y > c.ky0) c.ky0 = y;
    if (y + h < c.ky1) c.ky1 = y + h;
  }
  ~ClipScope() { c.kx0 = a; c.kx1 = b; c.ky0 = d; c.ky1 = e; }
};

// Blend one RGB888 source into a pixel with 8-bit alpha, optionally dithered.
static inline void blendPixD(Canvas &c, int x, int y, int sr, int sg, int sb, int a8) {
  if (a8 <= 0) return;
  uint16_t *p = c.at(x, y);
  int dr, dg, db; expand565(*p, dr, dg, db);
  int a = a8 + (a8 >> 7);                       // 0..256
  int r = dr + (((sr - dr) * a) >> 8);
  int g = dg + (((sg - dg) * a) >> 8);
  int b = db + (((sb - db) * a) >> 8);
  *p = pack565d(r, g, b, x, y);
}
static inline void blendPix(Canvas &c, int x, int y, uint16_t fg565, int a8) {
  if (a8 <= 0) return;
  uint16_t *p = c.at(x, y);
  if (a8 >= 250) { *p = fg565; return; }
  *p = mix565(*p, fg565, (uint32_t)((a8 + 4) >> 3));
}

// Clip a screen rect against the canvas. Returns false if nothing is visible.
static inline bool clipToCanvas(const Canvas &c, int &xa, int &ya, int &xb, int &yb) {
  if (xa < c.kx0) xa = c.kx0;
  if (xb > c.kx1) xb = c.kx1;
  if (ya < c.ky0) ya = c.ky0;
  if (yb > c.ky1) yb = c.ky1;
  return xa < xb && ya < yb;
}

// -----------------------------------------------------------------------------
// Rectangles and gradients
// -----------------------------------------------------------------------------
static void fillRect(Canvas &c, int x, int y, int w, int h, Col col, uint8_t a = 255) {
  int xa = x, ya = y, xb = x + w, yb = y + h;
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  uint16_t p = to565(col);
  for (int yy = ya; yy < yb; ++yy) {
    uint16_t *d = c.at(xa, yy);
    if (a >= 250) { for (int xx = xa; xx < xb; ++xx) *d++ = p; }
    else {
      uint32_t a5 = (a + 4) >> 3;
      for (int xx = xa; xx < xb; ++xx, ++d) *d = mix565(*d, p, a5);
    }
  }
}

// Bilinear four-corner gradient, ordered-dithered.
static void gradRect(Canvas &c, int x, int y, int w, int h, Col tl, Col tr, Col bl, Col br) {
  int xa = x, ya = y, xb = x + w, yb = y + h;
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  for (int yy = ya; yy < yb; ++yy) {
    float v = h > 1 ? (float)(yy - y) / (float)(h - 1) : 0;
    Col L = lerpCol(tl, bl, v), R = lerpCol(tr, br, v);
    int lr = L.r << 8, lg = L.g << 8, lb = L.b << 8;
    int dr = 0, dg = 0, db = 0;
    if (w > 1) { dr = ((R.r << 8) - lr) / (w - 1); dg = ((R.g << 8) - lg) / (w - 1); db = ((R.b << 8) - lb) / (w - 1); }
    int skip = xa - x; lr += dr * skip; lg += dg * skip; lb += db * skip;
    uint16_t *d = c.at(xa, yy);
    for (int xx = xa; xx < xb; ++xx, ++d) {
      *d = pack565d(lr >> 8, lg >> 8, lb >> 8, xx, yy);
      lr += dr; lg += dg; lb += db;
    }
  }
}
static inline void gradV(Canvas &c, int x, int y, int w, int h, Col top, Col bot) { gradRect(c, x, y, w, h, top, top, bot, bot); }
static inline void gradH(Canvas &c, int x, int y, int w, int h, Col l, Col r) { gradRect(c, x, y, w, h, l, r, l, r); }

// -----------------------------------------------------------------------------
// Rounded rectangle with gradient fill + gradient border, anti-aliased (SDF)
// -----------------------------------------------------------------------------
struct RStyle {
  Col ft, fb; uint8_t fa;          // fill top / bottom colour, alpha
  Col bt, bb; uint8_t ba;          // border top / bottom colour, alpha
  float bw;                        // border width (0 = none)
};

static void rrect(Canvas &c, float x, float y, float w, float h, float r, const RStyle &s) {
  int xa = (int)floorf(x), ya = (int)floorf(y), xb = (int)ceilf(x + w), yb = (int)ceilf(y + h);
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  if (r > w * 0.5f) r = w * 0.5f;
  if (r > h * 0.5f) r = h * 0.5f;
  const float cx = x + w * 0.5f, cy = y + h * 0.5f, ix = w * 0.5f - r, iy = h * 0.5f - r;
  const bool grad = (s.ft.r != s.fb.r || s.ft.g != s.fb.g || s.ft.b != s.fb.b ||
                     s.bt.r != s.bb.r || s.bt.g != s.bb.g || s.bt.b != s.bb.b);
  const uint16_t flat = to565(s.ft);
  for (int py = ya; py < yb; ++py) {
    float t = clamp01(((float)py + 0.5f - y) / h);
    Col fc = lerpCol(s.ft, s.fb, t), bc = lerpCol(s.bt, s.bb, t);
    float dy = fabsf((float)py + 0.5f - cy) - iy;
    for (int px = xa; px < xb; ++px) {
      float dx = fabsf((float)px + 0.5f - cx) - ix;
      float d;
      if (dx <= 0 && dy <= 0) d = fmaxf(dx, dy) - r;
      else { float ax = fmaxf(dx, 0), ay = fmaxf(dy, 0); d = sqrtf(ax * ax + ay * ay) + fminf(fmaxf(dx, dy), 0) - r; }
      float covO = clamp01(0.5f - d);
      if (covO <= 0) continue;
      if (d < -(s.bw + 0.5f) && s.fa >= 250) {            // solid interior
        *c.at(px, py) = grad ? pack565d(fc.r, fc.g, fc.b, px, py) : flat;
        continue;
      }
      float covI = s.bw > 0 ? clamp01(0.5f - (d + s.bw)) : covO;
      float fA = covI * s.fa / 255.0f, bA = (covO - covI) * s.ba / 255.0f, tot = fA + bA;
      if (tot <= 0.002f) continue;
      float k = fA / tot;
      int sr = (int)(fc.r * k + bc.r * (1 - k)), sg = (int)(fc.g * k + bc.g * (1 - k)), sb = (int)(fc.b * k + bc.b * (1 - k));
      blendPixD(c, px, py, sr, sg, sb, (int)(tot * 255.0f + 0.5f));
    }
  }
}
static inline void fillRRect(Canvas &c, float x, float y, float w, float h, float r, Col col, uint8_t a = 255) {
  rrect(c, x, y, w, h, r, RStyle{col, col, a, col, col, 0, 0});
}
static inline void fillRRectV(Canvas &c, float x, float y, float w, float h, float r, Col top, Col bot, uint8_t a = 255) {
  rrect(c, x, y, w, h, r, RStyle{top, bot, a, top, bot, 0, 0});
}
static inline void strokeRRect(Canvas &c, float x, float y, float w, float h, float r, Col col, uint8_t a = 255, float bw = 1.0f) {
  rrect(c, x, y, w, h, r, RStyle{col, col, 0, col, col, a, bw});
}
static inline void card(Canvas &c, float x, float y, float w, float h, float r, Col ft, Col fb, Col bt, Col bb) {
  rrect(c, x, y, w, h, r, RStyle{ft, fb, 255, bt, bb, 255, 1.0f});
}

// -----------------------------------------------------------------------------
// Circles, glows, lines, polygons, arcs
// -----------------------------------------------------------------------------
static inline void disc(Canvas &c, float cx, float cy, float r, Col col, uint8_t a = 255) {
  fillRRect(c, cx - r, cy - r, 2 * r, 2 * r, r, col, a);
}
static inline void discV(Canvas &c, float cx, float cy, float r, Col top, Col bot, uint8_t a = 255) {
  fillRRectV(c, cx - r, cy - r, 2 * r, 2 * r, r, top, bot, a);
}
static inline void ring(Canvas &c, float cx, float cy, float r, Col col, uint8_t a = 255, float bw = 1.0f) {
  strokeRRect(c, cx - r, cy - r, 2 * r, 2 * r, r, col, a, bw);
}

// Soft radial glow: alpha falls off smoothly to zero at radius r1 (dithered).
static void glow(Canvas &c, float cx, float cy, float r0, float r1, Col col, float intensity) {
  int xa = (int)floorf(cx - r1), ya = (int)floorf(cy - r1), xb = (int)ceilf(cx + r1), yb = (int)ceilf(cy + r1);
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  for (int py = ya; py < yb; ++py) {
    float dy = (float)py + 0.5f - cy;
    for (int px = xa; px < xb; ++px) {
      float dx = (float)px + 0.5f - cx;
      float d = sqrtf(dx * dx + dy * dy);
      if (d >= r1) continue;
      float t = 1.0f - smoothstep(r0, r1, d);
      t *= t;
      blendPixD(c, px, py, col.r, col.g, col.b, (int)(t * intensity * 255.0f));
    }
  }
}

// Line segment with round caps, width in px.
static void capsule(Canvas &c, float x0, float y0, float x1, float y1, float width, Col col, uint8_t a = 255) {
  float hw = width * 0.5f;
  int xa = (int)floorf(fminf(x0, x1) - hw - 1), xb = (int)ceilf(fmaxf(x0, x1) + hw + 1);
  int ya = (int)floorf(fminf(y0, y1) - hw - 1), yb = (int)ceilf(fmaxf(y0, y1) + hw + 1);
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  float vx = x1 - x0, vy = y1 - y0, l2 = vx * vx + vy * vy;
  uint16_t p = to565(col);
  for (int py = ya; py < yb; ++py) {
    for (int px = xa; px < xb; ++px) {
      float qx = (float)px + 0.5f - x0, qy = (float)py + 0.5f - y0;
      float h = l2 > 0 ? clamp01((qx * vx + qy * vy) / l2) : 0;
      float ex = qx - vx * h, ey = qy - vy * h;
      float d = sqrtf(ex * ex + ey * ey) - hw;
      int cov = (int)(clamp01(0.5f - d) * a);
      if (cov > 0) blendPix(c, px, py, p, cov);
    }
  }
}

// Convex polygon, anti-aliased (edge-distance approximation).
static void fillPoly(Canvas &c, const float *xy, int n, Col col, uint8_t a = 255) {
  float mnx = xy[0], mxx = xy[0], mny = xy[1], mxy = xy[1];
  for (int i = 1; i < n; ++i) {
    mnx = fminf(mnx, xy[2 * i]); mxx = fmaxf(mxx, xy[2 * i]);
    mny = fminf(mny, xy[2 * i + 1]); mxy = fmaxf(mxy, xy[2 * i + 1]);
  }
  int xa = (int)floorf(mnx) - 1, xb = (int)ceilf(mxx) + 1, ya = (int)floorf(mny) - 1, yb = (int)ceilf(mxy) + 1;
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  // orientation
  float area = 0;
  for (int i = 0; i < n; ++i) { int j = (i + 1) % n; area += xy[2 * i] * xy[2 * j + 1] - xy[2 * j] * xy[2 * i + 1]; }
  float sgn = area >= 0 ? 1.0f : -1.0f;
  uint16_t p = to565(col);
  for (int py = ya; py < yb; ++py) for (int px = xa; px < xb; ++px) {
    float fx = (float)px + 0.5f, fy = (float)py + 0.5f, d = -1e9f;
    for (int i = 0; i < n; ++i) {
      int j = (i + 1) % n;
      float ex = xy[2 * j] - xy[2 * i], ey = xy[2 * j + 1] - xy[2 * i + 1];
      float len = sqrtf(ex * ex + ey * ey); if (len < 1e-6f) continue;
      // outward normal distance (positive outside)
      float dist = -sgn * (ex * (fy - xy[2 * i + 1]) - ey * (fx - xy[2 * i])) / len;   // >0 outside
      if (dist > d) d = dist;
    }
    int cov = (int)(clamp01(0.5f - d) * a);
    if (cov > 0) blendPix(c, px, py, p, cov);
  }
}

// Arc stroke whose colour runs from colA to colB along the sweep.
// Angles in radians, 0 = +x, counter-clockwise on screen (y up). dash>0 => dashed.
static void arcStroke(Canvas &c, float cx, float cy, float r, float a0, float a1, float width,
                      Col colA, Col colB, uint8_t alpha = 255, float dashPx = 0) {
  float hw = width * 0.5f, ext = r + hw + 1;
  int xa = (int)floorf(cx - ext), xb = (int)ceilf(cx + ext), ya = (int)floorf(cy - ext), yb = (int)ceilf(cy + ext);
  if (!clipToCanvas(c, xa, ya, xb, yb)) return;
  float span = a1 - a0;
  for (int py = ya; py < yb; ++py) for (int px = xa; px < xb; ++px) {
    float dx = (float)px + 0.5f - cx, dy = (float)py + 0.5f - cy;
    float rr = sqrtf(dx * dx + dy * dy);
    float dr = fabsf(rr - r) - hw;
    if (dr > 0.5f) continue;
    float ang = atan2f(-dy, dx);
    float dA = ang - a0, mid = span * 0.5f;                 // wrap angle next to the sweep centre
    dA -= 6.2831853f * floorf((dA - mid + 3.14159265f) / 6.2831853f);
    float u = dA / span;                               // 0..1 along sweep
    float over = (u < 0) ? -u : (u > 1 ? u - 1 : 0);   // overshoot past either end
    float d = dr;
    if (over > 0) { float cap = over * fabsf(span) * r; d = sqrtf(dr * dr + cap * cap); }   // round cap
    float cov = clamp01(0.5f - d);
    if (dashPx > 0 && fmodf(fabsf(u) * fabsf(span) * r, dashPx * 2.0f) > dashPx) cov = 0;
    if (cov <= 0) continue;
    Col col = lerpCol(colA, colB, u);
    blendPixD(c, px, py, col.r, col.g, col.b, (int)(cov * alpha));
  }
}

// Fill under a sampled curve (one y per pixel column) with a vertical alpha ramp.
static void curveFill(Canvas &c, const float *ycurve, int xstart, int n, float ybase,
                      Col col, float ygrad0, float ygrad1, uint8_t aTop, uint8_t aBot) {
  for (int i = 0; i < n; ++i) {
    int px = xstart + i;
    if (px < c.kx0 || px >= c.kx1) continue;
    float top = ycurve[i];
    int ya = (int)floorf(top), yb = (int)ceilf(ybase);
    if (ya < c.ky0) ya = c.ky0;
    if (yb > c.ky1) yb = c.ky1;
    for (int py = ya; py < yb; ++py) {
      float cov = clamp01((float)py + 1.0f - top);                 // AA on the curve edge
      float k = clamp01(((float)py + 0.5f - ygrad0) / (ygrad1 - ygrad0));
      float al = (aTop + (aBot - aTop) * k) * cov;
      blendPixD(c, px, py, col.r, col.g, col.b, (int)al);
    }
  }
}

// -----------------------------------------------------------------------------
// Text
// -----------------------------------------------------------------------------
enum { AL_LEFT = 0, AL_CENTER = 1, AL_RIGHT = 2 };

static inline const AGlyph *glyphFor(const AFont &f, unsigned char ch) {
  if (ch < f.first || ch > f.last) ch = '?';
  int i = f.map[ch - f.first];
  if (i < 0) { i = f.map[' ' - f.first]; if (i < 0) return nullptr; }
  return &f.glyphs[i];
}
static int textWidth(const AFont &f, const char *s) {
  int a16 = 0;
  for (; *s; ++s) { const AGlyph *g = glyphFor(f, (unsigned char)*s); if (g) a16 += g->adv16; }
  return (a16 + 8) >> 4;
}
// Letter-spaced width (extra px between glyphs) for small caps headings.
static int textWidthSp(const AFont &f, const char *s, int extra) {
  int n = (int)strlen(s);
  return textWidth(f, s) + (n > 0 ? (n - 1) * extra : 0);
}

static const uint8_t AG_A4TO5[16] = {0, 2, 4, 6, 9, 11, 13, 15, 17, 19, 21, 24, 26, 28, 30, 32};

// Draw text with baseline at ybase. colTop/colBot give an optional vertical
// gradient across the font's ascent; alpha scales the whole run.
static void textGrad(Canvas &c, const AFont &f, int x, int ybase, const char *s,
                     Col colTop, Col colBot, int align = AL_LEFT, uint8_t alpha = 255, int spacing = 0) {
  if (!s || !*s) return;
  if (!c.hitsY(ybase - f.ascent - 1, ybase + f.descent + 1)) return;
  int tw = spacing ? textWidthSp(f, s, spacing) : textWidth(f, s);
  if (align == AL_CENTER) x -= tw / 2; else if (align == AL_RIGHT) x -= tw;
  if (x >= c.kx1 || x + tw < c.kx0) return;
  bool flat = (colTop.r == colBot.r && colTop.g == colBot.g && colTop.b == colBot.b);
  uint16_t p565 = to565(colTop);
  int pen16 = x * 16;
  for (const char *q = s; *q; ++q) {
    const AGlyph *g = glyphFor(f, (unsigned char)*q);
    if (!g) continue;
    if (g->w) {
      int gx = ((pen16 + 8) >> 4) + g->xo, gy = ybase + g->yo;
      if (gx < c.kx1 && gx + g->w > c.kx0 && gy < c.ky1 && gy + g->h > c.ky0) {
        const uint8_t *bits = f.bits + g->off;
        for (int row = 0; row < g->h; ++row) {
          int py = gy + row;
          if (py < c.ky0 || py >= c.ky1) continue;
          uint16_t rowCol = p565;
          if (!flat) rowCol = to565(lerpCol(colTop, colBot, (float)(py - (ybase - f.ascent)) / (float)f.ascent));
          uint16_t *d = c.at(0 + c.ox, py);
          for (int col = 0; col < g->w; ++col) {
            int px = gx + col;
            if (px < c.kx0 || px >= c.kx1) continue;
            int idx = row * g->w + col;
            uint8_t b = bits[idx >> 1];
            uint8_t a4 = (idx & 1) ? (b & 15) : (b >> 4);
            if (!a4) continue;
            uint32_t a5 = AG_A4TO5[a4];
            if (alpha != 255) a5 = (a5 * alpha + 127) / 255;
            uint16_t *dp = d + (px - c.ox);
            *dp = (a5 >= 32) ? rowCol : mix565(*dp, rowCol, a5);
          }
        }
      }
    }
    pen16 += g->adv16 + spacing * 16;
  }
}
static inline void text(Canvas &c, const AFont &f, int x, int ybase, const char *s, Col col,
                        int align = AL_LEFT, uint8_t alpha = 255, int spacing = 0) {
  textGrad(c, f, x, ybase, s, col, col, align, alpha, spacing);
}
// Truncate with ".." so the run fits maxW pixels.
static void textFit(Canvas &c, const AFont &f, int x, int ybase, const char *s, Col col, int maxW,
                    int align = AL_LEFT) {
  if (textWidth(f, s) <= maxW) { text(c, f, x, ybase, s, col, align); return; }
  char buf[64]; int n = (int)strlen(s); if (n > 60) n = 60;
  memcpy(buf, s, n); buf[n] = 0;
  while (n > 1) { buf[--n] = 0; char t[68]; snprintf(t, sizeof(t), "%s..", buf); if (textWidth(f, t) <= maxW) { text(c, f, x, ybase, t, col, align); return; } }
}

// -----------------------------------------------------------------------------
// Band driver
// -----------------------------------------------------------------------------
typedef void (*AuroraDrawFn)(Canvas &, void *);

// Executes fn once per band over the region (rx,ry,rw,rh) and pushes each band.
static bool auroraRender(int W, int H, int rx, int ry, int rw, int rh, AuroraDrawFn fn, void *ctx) {
  if (rx < 0) { rw += rx; rx = 0; }
  if (ry < 0) { rh += ry; ry = 0; }
  if (rx + rw > W) rw = W - rx;
  if (ry + rh > H) rh = H - ry;
  if (rw <= 0 || rh <= 0) return true;
  size_t budget = AURORA_BAND_BYTES, avail = AURORA_MAX_ALLOC();
  if (avail / 3 < budget) budget = avail / 3;
  int rows = (int)(budget / ((size_t)rw * 2));
  if (rows < 1) rows = 1;
  if (rows > rh) rows = rh;
  uint16_t *buf = nullptr;
  while (rows >= 1) {
    buf = (uint16_t *)AURORA_ALLOC((size_t)rw * rows * 2);
    if (buf) break;
    rows >>= 1;
  }
  if (!buf) return false;
  Canvas c; c.buf = buf; c.ox = rx; c.w = rw; c.W = W; c.H = H;
  for (int y = ry; y < ry + rh; y += rows) {
    c.y0 = y; c.y1 = (y + rows < ry + rh) ? y + rows : ry + rh;
    c.kx0 = rx; c.kx1 = rx + rw; c.ky0 = c.y0; c.ky1 = c.y1;
    fn(c, ctx);
    AURORA_FLUSH(rx, y, rw, c.y1 - c.y0, buf);
  }
  AURORA_FREE(buf);
  return true;
}
