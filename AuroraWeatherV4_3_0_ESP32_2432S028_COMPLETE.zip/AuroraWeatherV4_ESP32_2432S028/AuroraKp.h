#pragma once
/*
 * AuroraKp.h - tiny streaming parser for NOAA SWPC's planetary K-index JSON.
 *
 * Why hand-written: the file holds days of 3-hourly rows and we only need the
 * newest eight values. Feeding bytes straight from the TLS socket into this
 * state machine needs ~100 bytes of RAM, never builds a JSON tree and cannot
 * run the heap down while Wi-Fi + TLS are already using most of it.
 *
 * It accepts BOTH layouts NOAA has published for
 *   https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json
 *   old (until 2026-03-31): [["time_tag","Kp","a_running","station_count"],
 *                            ["2026-03-30 21:00:00.000","2.33","9","8"], ...]
 *   new (key/value rows):   [{"time_tag":"2026-03-31T00:00:00","Kp":1.67,
 *                             "a_running":6,"station_count":8}, ...]
 * Numbers may be quoted or bare. Column / key names are matched case-insensitively
 * ("Kp", "kp_index", "estimated_kp"). Pure C++: no Arduino dependency, so the same
 * code is unit-tested on the PC.
 */
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "AuroraTypes.h"

struct KpStream {
  // result (newest value last)
  float kp[KP_HIST] = {};
  int n = 0;
  int rows = 0;                    // data rows seen (diagnostics)

  void feed(const char *p, size_t len) { for (size_t i = 0; i < len; ++i) put(p[i]); }

  void put(char ch) {
    if (inStr) {
      if (esc) { esc = false; add(ch); }
      else if (ch == '\\') esc = true;
      else if (ch == '"') { inStr = false; pending = true; pendStr = true; }
      else add(ch);
      return;
    }
    switch (ch) {
      case '"': inStr = true; tl = 0; tok[0] = 0; pending = false; break;
      case '[': case '{':
        flushIfNeeded();
        ++depth;
        if (depth == 2) beginRow(ch == '{');
        break;
      case ']': case '}':
        if (depth == 2) commit();
        pending = false;
        if (depth == 2) endRow();
        if (depth > 0) --depth;
        break;
      case ',':
        if (depth == 2) { commit(); ++col; }
        pending = false;
        break;
      case ':':
        if (depth == 2 && rowObj && pending && pendStr) { strncpy(key, tok, sizeof(key) - 1); key[sizeof(key) - 1] = 0; }
        pending = false;
        break;
      case ' ': case '\t': case '\r': case '\n': break;
      default:                                  // bare token: number / true / false / null
        if (!pending) { tl = 0; tok[0] = 0; pending = true; pendStr = false; }
        add(ch);
        break;
    }
  }

private:
  int depth = 0;
  bool inStr = false, esc = false, pending = false, pendStr = false;
  char tok[32] = {};
  int tl = 0;
  // row state
  bool rowObj = false, rowHeader = false;
  int col = 0, kpCol = 1;          // defaults match the old layout
  int rowsBegun = 0;               // only the very first row can be a header
  char key[20] = {};
  float rowKp = -1.0f;
  bool rowHasKp = false;

  void add(char ch) { if (tl < (int)sizeof(tok) - 1) { tok[tl++] = ch; tok[tl] = 0; } }
  void flushIfNeeded() { pending = false; }

  static bool isKpName(const char *s) {
    char b[20]; int i = 0;
    for (; s[i] && i < 19; ++i) b[i] = (char)tolower((unsigned char)s[i]);
    b[i] = 0;
    return !strcmp(b, "kp") || !strcmp(b, "kp_index") || !strcmp(b, "estimated_kp");
  }
  void beginRow(bool obj) { ++rowsBegun; rowObj = obj; col = 0; rowHeader = false; rowHasKp = false; rowKp = -1.0f; key[0] = 0; pending = false; }

  void commit() {
    if (!pending) return;
    pending = false;
    if (rowObj) {
      if (isKpName(key)) setKp(tok);
      key[0] = 0;
    } else {
      // A header row starts with a column NAME (letters); data rows start with a date (digits).
      if (rowHeader || (rowsBegun == 1 && col == 0 && pendStr && isalpha((unsigned char)tok[0]))) {
        rowHeader = true;
        if (isKpName(tok)) kpCol = col;
      } else if (col == kpCol) setKp(tok);
    }
  }
  void setKp(const char *s) {
    char *e = nullptr; float v = strtof(s, &e);
    if (e != s && v >= 0.0f && v <= 9.5f) { rowKp = v; rowHasKp = true; }
  }
  void endRow() {
    if (rowHeader || !rowHasKp) return;
    ++rows;
    if (n < KP_HIST) kp[n++] = rowKp;
    else { for (int i = 1; i < KP_HIST; ++i) kp[i - 1] = kp[i]; kp[KP_HIST - 1] = rowKp; }
  }
};
